﻿#include "pch-cpp.hpp"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <limits>



struct Dictionary_2_t21E090827BAF9D0D011CB55C02CA666756BF1AE7;
struct Dictionary_2_t66BDB52E8D3642369029BE471AADC42272504AC6;
struct DynamicArray_1_tA7E05F444A8E75C3FD24B4EA81F57EA44E6D0F09;
struct IEnumerator_1_t5926539DBBB2302C569D0A07AF3A95A874CEBE33;
struct List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73;
struct List_1_t212D7D10D2A8B008F722C657B1D0E8D655B83C77;
struct List_1_t4BB4104675FF18094A5497A56BDC7D7FC0BA0F98;
struct List_1_t87AE23082814D175C791AB0CD6E68302C3E42536;
struct List_1_tF42FEB6C3B18B7E7C8F2DE1FEBA00D2491736317;
struct RenderFunc_1_tAFF473C45BAB6B92BED11F24D63410C61AEDB710;
struct Stack_1_t3197E0F5EA36E611B259A88751D31FC2396FE4B6;
struct DynamicArray_1U5BU5D_t9A04AF8D17DC84C40057E12489B6887F71B1232F;
struct List_1U5BU5D_t37294D7C303231F2FD83B3C398AED0937F4F3206;
struct BooleanU5BU5D_tD317D27C31DB892BE79FAE3AEBC0B3FFB73DE9B4;
struct GraphicsFormatU5BU5D_tF6A3D90C430FA3F548B77E5D58D25D71F154E6C5;
struct IntPtrU5BU5D_tFD177F8C806A6921AD7150264CCC62FA00CAD832;
struct Matrix4x4U5BU5D_t9C51C93425FABC022B506D2DB3A5FA70F9752C4D;
struct RTHandleU5BU5D_tE4B403B060D159B839BF74E8B59F8DCD52CF97DF;
struct RenderBufferStoreActionU5BU5D_tFEA8F5DD460573EA9F35FBEC5727D1804C5DCBF5;
struct RenderTargetIdentifierU5BU5D_t179798C153B7CE381B41C57863F98CB24023C4CE;
struct ShadowSliceDataU5BU5D_t3B41B7A06BAB3677671AEE84FBCF1A23B7DC7D04;
struct StackTraceU5BU5D_t32FBCB20930EAF5BAE3F450FF75228E5450DA0DF;
struct Vector4U5BU5D_tC0F3A7115F85007510F6D173968200CD31BCF7AD;
struct Byte_t94D9231AC217BE4D2E004C4CD32DF6D099EA41A3;
struct Camera_tA92CC927D7439999BC82DBEDC0AA45B470F9E184;
struct CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7;
struct CullingAllocationInfo_tB260F5CD0B290F74E145EB16E54B901CC68D9D5A;
struct Exception_t;
struct IDictionary_t6D03155AF1FA9083817AA5B6AD7DEEACC26AB220;
struct MainLightShadowCasterPass_tC550260377ED69F98337CF963695B7A090B137E3;
struct ProfilingSampler_t420D4672EDB44E0EF980B31ADFD9E5747200FECE;
struct RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B;
struct RTHandleSystem_tAE496B31B56A77B4896E34576C961C3CA073998F;
struct RenderGraph_t5AA201AC80DFD885B4FFB147432366185AE489BB;
struct RenderGraphContext_t230588A81E5222F21FB773FD8D1DB979190E0A08;
struct RenderGraphDebugParams_t71FB41FA59B11FB4B0E81B17F48923224ED4905E;
struct RenderGraphDefaultResources_t9911A2DC8A2C28E3A1F7F2D48B03AFBCEF1F499B;
struct RenderGraphLogger_t340B4BCF805D9B4D9CB9AAE173C1ADFE5F479D17;
struct RenderGraphObjectPool_t266B5D9BA6D695C3E7E1A3919F3304504C5BCC7A;
struct RenderGraphResourceRegistry_t8BCEB5376056E4818FA9B6CC82057B9FE9ACA06C;
struct RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13;
struct RenderTexture_tBA90C4C3AD9EECCFDDCC632D97C29FAB80D60D27;
struct SafeSerializationManager_tCBB85B95DFD1634237140CD892E82D06ECB3F5E6;
struct ScaleFunc_t423F661DAD5C7A18F509C8F1F62C9D6AEA9A9791;
struct ScriptableRenderer_tF15B95BB85F26BE4B4719901D909831B89DC8892;
struct String_t;
struct TaaPersistentData_t7AD3D320FD8FE7195225F0A7C7C676480A6ED775;
struct Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700;
struct Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1;
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915;
struct XRPass_tFC4577E97B88E0EAAAB2EB387AB3A92E9EB9C6DF;
struct U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264;
struct PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A;
struct OnExecutionRegisteredDelegate_t4E612DCD17907BD63A44EEF6E3A0B43FD2A87FEE;
struct OnGraphRegisteredDelegate_t31768B4561FF76800AC9B3D17A837827EC7E0EB9;

IL2CPP_EXTERN_C RuntimeClass* EarlyInitHelpers_tA67F29CEEF85CD33340F1A46E13686C44F97695A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Exception_t_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* RenderingUtils_t4E40200449A82FA3A172A563C490DF11FADA2BE1_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* float4_t89D9A294E7A79BD81BFBDD18654508532958555E_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C RuntimeClass* int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_il2cpp_TypeInfo_var;
IL2CPP_EXTERN_C String_t* _stringLiteralAB69FA1AB6BB831506EFCAD83900FEE751E85F6F;
IL2CPP_EXTERN_C String_t* _stringLiteralEF420ABFDDBDA7B9EE665D85EF62E4A437554003;
IL2CPP_EXTERN_C const RuntimeMethod* ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArraySlice_1_get_Length_m814A8881AF759049A308E6E04BE0451BFDA0076B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* IJobExtensions_EarlyJobInit_TisDrawCallJob_t3EA2ABC822AD5DF50675A5B437DAB927DB95215D_m8175192716D38C9C006D2C98D5B36A7CC75E33AD_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* IJobForExtensions_EarlyJobInit_TisLightMinMaxZJob_tB4FE0854445DAADF46E5511EAAF54EA1E4B611C4_m6D407EF2FD72EE5C26BA1C843C9932ABCB9C16DA_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* IJobForExtensions_EarlyJobInit_TisReflectionProbeMinMaxZJob_tB55272F39D5B8B189F5DF7212CDA3FFF1EC0C71C_mE2595D2099394DF551AC793D9874D90167904DF2_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* IJobForExtensions_EarlyJobInit_TisTileRangeExpansionJob_t8342AD91DCB87CA5DBDB463981EE24D47408C876_m7F3455814736950B257AF91E4AE26136F7D2D588_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* IJobForExtensions_EarlyJobInit_TisTilingJob_t4506E6F62C95A90210A474DE43C83AF5EB8D3352_m4C05E9D5B6CBBFDCFF690B0C60C83CC47D299593_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* IJobForExtensions_EarlyJobInit_TisZBinningJob_t9BC217C31924E66E667568C1B51EA2F44FA0A08E_mA5B015BCBE9BD211FDEFDAE5347DCBE7E91D1970_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* IJobParallelForTransformExtensions_EarlyJobInit_TisUpdateTransformsJob_t7CF957169E8C6560084F48A51BC15A447F3002C7_mA2F79749E27788E6B6B0DA93086B08A0C553480E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_Copy_TisInt32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_m08EAF9EE4BD7B3611121EEBB1CA1AC40D9C29874_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_Copy_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mE623C4A9806A975DC543E10F18CD15CADCD6D02F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_GetEqual_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155_m27B4DE791ADEB1742E19D6628CA333842FC8FC54_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_GetEqual_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375_m00A96EB8B356CCA03D3D724C514C6175681907A8_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_GetEqual_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1_mA2DC9A659A83000A07E39BAAFFA6588DF23C361A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D_mDDE7DE6D079B34BF84F234F97CEF203430E49608_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3_m0A70D6C3B3B43D49B43B90E25921F0935E4F0853_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_GetUpper_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436_mFF87B6D1AF19335BBFCBFC9A88B90165B26C3987_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_InsertionSort_TisDouble_tE150EF3D1D43DEE85D533810AB4C742307EEDE5F_TisXCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B_mD9DFBCA0EC70F5BF558FBC5C79E929BB2316EFB7_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_InsertionSort_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F_m1706B12E442DF1715DFA736CA4077E4896F0F251_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisIntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489_mCEC67F4B9CB4B8CA627B923D2CFC9173F15EC916_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434_mBE4B56307E132AEA84ADF183CC238AA9ED176FA6_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249_mDFFBE16DF5663EFCBC9251F641DD620ACBF7374D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_InsertionSort_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE_mB73DA078075FCD273BA172C5E5D6EEDDBFA8279D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* ModuleHandle_InsertionSort_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_TisDelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B_m18BA196C639121F5500845FA59E90F34DB272028_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_mD7FAFF405DB2912073D4F221E3403DEF24972B52_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_m9322523E8F4F331EE08D7DE23A5F5E48B851AF00_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mB537AB040DF35BD6BE8FEBE48C04901884E592E3_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_m1ACF94B84372AD81EEE7228152F8E1770B09180B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_m2FC0457FE238F347CEF96BDA77BA875179E5704B_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_m38861384F84F1CD89A47D663C29D3ED425C5CCE0_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_m44CBE8EDE8CD7B71350BF815EE8BB232511E7D79_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_m9D682D26EB442C42FBAB528F6F5F90AE5C216E8C_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_mB48AC20750ECFD2702E0F9915B2177D044D15C58_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_Dispose_mE0AE14258D3045288D915F3FD346533D843D7CDB_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_m56963AF6292CEE1271AFDE037CEFD1B70C5050D4_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_m89F748542AF7065DD1BC4780E9A0E4F3D41073ED_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_m9D79AD54D34744D093257128146409873295E2DB_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_mC01F44D62CB455BB4FE045F1FFB6BBD3516CB265_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_mC429670774D3D1F7CB41BBD8C5BD9943404BDF54_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_mCFEB37C6F648F756D9AC2C044D2EE01AE66DBE34_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_mEB7F36BB585F82EDD8F8C88166579082DFA402BF_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_get_IsCreated_m448EBF5E1AF8055E179079DE8883B7F449125BAB_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_get_IsCreated_m5BE85069615B49772C9DB202004FA2FD36F418F2_RuntimeMethod_var;
IL2CPP_EXTERN_C const RuntimeMethod* NativeArray_1_get_IsCreated_mB43459BFDEF78038051D817E8A57FF1DF3C3D738_RuntimeMethod_var;
struct Exception_t_marshaled_com;
struct Exception_t_marshaled_pinvoke;


IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
struct U3CPrivateImplementationDetailsU3E_t16CE31F4DEE6BA0AEFEB3FA0105D58630695B339  : public RuntimeObject
{
};
struct RenderGraph_t5AA201AC80DFD885B4FFB147432366185AE489BB  : public RuntimeObject
{
	RenderGraphResourceRegistry_t8BCEB5376056E4818FA9B6CC82057B9FE9ACA06C* ___m_Resources;
	RenderGraphObjectPool_t266B5D9BA6D695C3E7E1A3919F3304504C5BCC7A* ___m_RenderGraphPool;
	List_1_t4BB4104675FF18094A5497A56BDC7D7FC0BA0F98* ___m_RenderPasses;
	List_1_t87AE23082814D175C791AB0CD6E68302C3E42536* ___m_RendererLists;
	RenderGraphDebugParams_t71FB41FA59B11FB4B0E81B17F48923224ED4905E* ___m_DebugParameters;
	RenderGraphLogger_t340B4BCF805D9B4D9CB9AAE173C1ADFE5F479D17* ___m_FrameInformationLogger;
	RenderGraphDefaultResources_t9911A2DC8A2C28E3A1F7F2D48B03AFBCEF1F499B* ___m_DefaultResources;
	Dictionary_2_t21E090827BAF9D0D011CB55C02CA666756BF1AE7* ___m_DefaultProfilingSamplers;
	bool ___m_ExecutionExceptionWasRaised;
	RenderGraphContext_t230588A81E5222F21FB773FD8D1DB979190E0A08* ___m_RenderGraphContext;
	CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* ___m_PreviousCommandBuffer;
	int32_t ___m_CurrentImmediatePassIndex;
	List_1U5BU5D_t37294D7C303231F2FD83B3C398AED0937F4F3206* ___m_ImmediateModeResourceList;
	DynamicArray_1U5BU5D_t9A04AF8D17DC84C40057E12489B6887F71B1232F* ___m_CompiledResourcesInfos;
	DynamicArray_1_tA7E05F444A8E75C3FD24B4EA81F57EA44E6D0F09* ___m_CompiledPassInfos;
	Stack_1_t3197E0F5EA36E611B259A88751D31FC2396FE4B6* ___m_CullingStack;
	int32_t ___m_ExecutionCount;
	int32_t ___m_CurrentFrameIndex;
	bool ___m_HasRenderGraphBegun;
	String_t* ___m_CurrentExecutionName;
	bool ___m_RendererListCulling;
	Dictionary_2_t66BDB52E8D3642369029BE471AADC42272504AC6* ___m_DebugData;
	String_t* ___U3CnameU3Ek__BackingField;
};
struct String_t  : public RuntimeObject
{
	int32_t ____stringLength;
	Il2CppChar ____firstChar;
};
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F  : public RuntimeObject
{
};
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_pinvoke
{
};
struct ValueType_t6D9B272BD21782F0A9A14F2E41F85A50E97A986F_marshaled_com
{
};
struct __JobReflectionRegistrationOutput__1843744399_t83F5F6BE51653CF7070561516113DF3F5445184E  : public RuntimeObject
{
};
struct U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264  : public RuntimeObject
{
};
struct MainLightShadowConstantBuffer_tDE7E52C397EA5C7066924F7C9DC843321DF0A6E3  : public RuntimeObject
{
};
struct ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 
{
	uint8_t* ___m_Buffer;
	int32_t ___m_Stride;
	int32_t ___m_Length;
};
struct NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_tB723C353A73B34FE57C3B9EA16A02A466B268BC2 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t97EAB41C5774F97823C769B51FBCAC8DE508B75D 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t71485A1E60B31CCAD3E525C907CF172E8B804468 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 
{
	void* ___m_Buffer;
	int32_t ___m_Length;
	int32_t ___m_AllocatorLabel;
};
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22 
{
	bool ___m_value;
};
struct Color_tD001788D726C3A7F1379BEED0260B9591F440C1F 
{
	float ___r;
	float ___g;
	float ___b;
	float ___a;
};
struct DelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B 
{
	union
	{
		struct
		{
		};
		uint8_t DelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B__padding[1];
	};
};
struct Double_tE150EF3D1D43DEE85D533810AB4C742307EEDE5F 
{
	double ___m_value;
};
struct Int32_t680FF22E76F6EFAD4375103CBBFFA0421349384C 
{
	int32_t ___m_value;
};
struct Int64_t092CFB123BE63C28ACDAF65C68F21A526050DBA3 
{
	int64_t ___m_value;
};
struct IntPtr_t 
{
	void* ___m_value;
};
struct LayerMask_t97CB6BDADEDC3D6423C7BCFEA7F86DA2EC6241DB 
{
	int32_t ___m_Mask;
};
struct Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 
{
	float ___m00;
	float ___m10;
	float ___m20;
	float ___m30;
	float ___m01;
	float ___m11;
	float ___m21;
	float ___m31;
	float ___m02;
	float ___m12;
	float ___m22;
	float ___m32;
	float ___m03;
	float ___m13;
	float ___m23;
	float ___m33;
};
struct ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978 
{
	union
	{
		struct
		{
		};
		uint8_t ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978__padding[1];
	};
};
struct PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761 
{
	union
	{
		struct
		{
		};
		uint8_t PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761__padding[1];
	};
};
struct PostProcessingData_tFA75BF22951C600258B2707AF7A113E4EDA49BD4 
{
	int32_t ___gradingMode;
	int32_t ___lutSize;
	bool ___useFastSRGBLinearConversion;
	bool ___supportDataDrivenLensFlare;
};
struct PostProcessingData_tFA75BF22951C600258B2707AF7A113E4EDA49BD4_marshaled_pinvoke
{
	int32_t ___gradingMode;
	int32_t ___lutSize;
	int32_t ___useFastSRGBLinearConversion;
	int32_t ___supportDataDrivenLensFlare;
};
struct PostProcessingData_tFA75BF22951C600258B2707AF7A113E4EDA49BD4_marshaled_com
{
	int32_t ___gradingMode;
	int32_t ___lutSize;
	int32_t ___useFastSRGBLinearConversion;
	int32_t ___supportDataDrivenLensFlare;
};
struct Rect_tA04E0F8A1830E767F40FB27ECD8D309303571F0D 
{
	float ___m_XMin;
	float ___m_YMin;
	float ___m_Width;
	float ___m_Height;
};
struct Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9 
{
	union
	{
		struct
		{
		};
		uint8_t Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9__padding[1];
	};
};
struct RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46 
{
	int32_t ___U3CwidthU3Ek__BackingField;
	int32_t ___U3CheightU3Ek__BackingField;
	int32_t ___U3CmsaaSamplesU3Ek__BackingField;
	int32_t ___U3CvolumeDepthU3Ek__BackingField;
	int32_t ___U3CmipCountU3Ek__BackingField;
	int32_t ____graphicsFormat;
	int32_t ___U3CstencilFormatU3Ek__BackingField;
	int32_t ___U3CdepthStencilFormatU3Ek__BackingField;
	int32_t ___U3CdimensionU3Ek__BackingField;
	int32_t ___U3CshadowSamplingModeU3Ek__BackingField;
	int32_t ___U3CvrUsageU3Ek__BackingField;
	int32_t ____flags;
	int32_t ___U3CmemorylessU3Ek__BackingField;
};
struct ResourceHandle_t0B9B0555328A08152F1EDA2BE4024446D670531A 
{
	uint32_t ___m_Value;
	int32_t ___U3CtypeU3Ek__BackingField;
};
struct ShaderTagId_t453E2085B5EE9448FF75E550CAB111EFF690ECB0 
{
	int32_t ___m_Id;
};
struct Single_t4530F2FF86FCB0DC29F35385CA1BD21BE294761C 
{
	float ___m_value;
};
struct Smoothen_t66451B46E8AA634F6F80536137F061EC45767822 
{
	union
	{
		struct
		{
		};
		uint8_t Smoothen_t66451B46E8AA634F6F80536137F061EC45767822__padding[1];
	};
};
struct TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE 
{
	union
	{
		struct
		{
		};
		uint8_t TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE__padding[1];
	};
};
struct TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434 
{
	union
	{
		struct
		{
		};
		uint8_t TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434__padding[1];
	};
};
struct TessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F 
{
	union
	{
		struct
		{
		};
		uint8_t TessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F__padding[1];
	};
};
struct TessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249 
{
	union
	{
		struct
		{
		};
		uint8_t TessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249__padding[1];
	};
};
struct UInt16_tF4C148C876015C212FD72652D0B6ED8CC247A455 
{
	uint16_t ___m_value;
};
struct UInt32_t1833D51FFA667B18A5AA4B8D34DE284F8495D29B 
{
	uint32_t ___m_value;
};
struct UInt64_t8F12534CC8FC4B5860F2A2CD1EE79D322E7A41AF 
{
	uint64_t ___m_value;
};
struct Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 
{
	float ___x;
	float ___y;
};
struct Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A 
{
	int32_t ___m_X;
	int32_t ___m_Y;
};
struct Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 
{
	float ___x;
	float ___y;
	float ___z;
};
struct Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 
{
	float ___x;
	float ___y;
	float ___z;
	float ___w;
};
struct Void_t4861ACF8F4594C3437BB48B6E56783494B843915 
{
	union
	{
		struct
		{
		};
		uint8_t Void_t4861ACF8F4594C3437BB48B6E56783494B843915__padding[1];
	};
};
struct XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B 
{
	union
	{
		struct
		{
		};
		uint8_t XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B__padding[1];
	};
};
struct double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA 
{
	double ___x;
	double ___y;
};
struct float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA 
{
	float ___x;
	float ___y;
};
struct float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E 
{
	float ___x;
	float ___y;
	float ___z;
};
struct float4_t89D9A294E7A79BD81BFBDD18654508532958555E 
{
	float ___x;
	float ___y;
	float ___z;
	float ___w;
};
struct int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A 
{
	int32_t ___x;
	int32_t ___y;
};
struct int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF 
{
	int32_t ___x;
	int32_t ___y;
	int32_t ___z;
};
struct int4_tBA77D4945786DE82C3A487B33955EA1004996052 
{
	int32_t ___x;
	int32_t ___y;
	int32_t ___z;
	int32_t ___w;
};
#pragma pack(push, tp, 1)
struct __StaticArrayInitTypeSizeU3D12_t5F40C9EEDE242DFE47A8DCE218ED3DF3E88B4EC0 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D12_t5F40C9EEDE242DFE47A8DCE218ED3DF3E88B4EC0__padding[12];
	};
};
#pragma pack(pop, tp)
#pragma pack(push, tp, 1)
struct __StaticArrayInitTypeSizeU3D16_tB86B9BFC4ADBF4E2DF11F39AF43639693C65DF05 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D16_tB86B9BFC4ADBF4E2DF11F39AF43639693C65DF05__padding[16];
	};
};
#pragma pack(pop, tp)
#pragma pack(push, tp, 1)
struct __StaticArrayInitTypeSizeU3D18057_tD52D99338C7D77BF40020E570B4ED083432382CE 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D18057_tD52D99338C7D77BF40020E570B4ED083432382CE__padding[18057];
	};
};
#pragma pack(pop, tp)
#pragma pack(push, tp, 1)
struct __StaticArrayInitTypeSizeU3D23517_tF4800C5299C00EDBB2EFE21EFC6012069C100625 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D23517_tF4800C5299C00EDBB2EFE21EFC6012069C100625__padding[23517];
	};
};
#pragma pack(pop, tp)
#pragma pack(push, tp, 1)
struct __StaticArrayInitTypeSizeU3D24_tB605E983EFADFA4C2759D8C48AB45B0B3A7BCC51 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D24_tB605E983EFADFA4C2759D8C48AB45B0B3A7BCC51__padding[24];
	};
};
#pragma pack(pop, tp)
#pragma pack(push, tp, 1)
struct __StaticArrayInitTypeSizeU3D960_t86900CB1F8550ABFAD884FDD8E17F7B7AA90ED0D 
{
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D960_t86900CB1F8550ABFAD884FDD8E17F7B7AA90ED0D__padding[960];
	};
};
#pragma pack(pop, tp)
struct U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0 
{
	union
	{
		struct
		{
			double ___FixedElementField;
		};
		uint8_t U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0__padding[32];
	};
};
struct U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29 
{
	union
	{
		struct
		{
			double ___FixedElementField;
		};
		uint8_t U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29__padding[32];
	};
};
struct SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4 
{
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* ___rtMSAA;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* ___rtResolve;
	String_t* ___name;
	int32_t ___msaa;
};
struct SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshaled_pinvoke
{
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* ___rtMSAA;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* ___rtResolve;
	char* ___name;
	int32_t ___msaa;
};
struct SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshaled_com
{
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* ___rtMSAA;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* ___rtResolve;
	Il2CppChar* ___name;
	int32_t ___msaa;
};
struct Settings_t3BEFDFF2C1A3D3A215DAF7B76E735B1BFB946C92 
{
	int32_t ___quality;
	float ___frameInfluence;
	float ___jitterScale;
	float ___mipBias;
	float ___varianceClampScale;
	float ___contrastAdaptiveSharpening;
	int32_t ___resetHistoryFrames;
	int32_t ___jitterFrameCountOffset;
};
struct TestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1 
{
	union
	{
		struct
		{
		};
		uint8_t TestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1__padding[1];
	};
};
struct TestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375 
{
	union
	{
		struct
		{
		};
		uint8_t TestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375__padding[1];
	};
};
struct TestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155 
{
	union
	{
		struct
		{
		};
		uint8_t TestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155__padding[1];
	};
};
struct TestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D 
{
	union
	{
		struct
		{
		};
		uint8_t TestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D__padding[1];
	};
};
struct TestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3 
{
	union
	{
		struct
		{
		};
		uint8_t TestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3__padding[1];
	};
};
struct TestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436 
{
	union
	{
		struct
		{
		};
		uint8_t TestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436__padding[1];
	};
};
struct IntFloatUnion_t549256A9DD754252DD18383D9CE7EA55EBBD6D96 
{
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			int32_t ___intValue;
		};
		#pragma pack(pop, tp)
		struct
		{
			int32_t ___intValue_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			float ___floatValue;
		};
		#pragma pack(pop, tp)
		struct
		{
			float ___floatValue_forAlignmentOnly;
		};
	};
};
struct LongDoubleUnion_tD71C400B6C4CD1A7F13CE8125AC6BBC7A22791CA 
{
	union
	{
		#pragma pack(push, tp, 1)
		struct
		{
			int64_t ___longValue;
		};
		#pragma pack(pop, tp)
		struct
		{
			int64_t ___longValue_forAlignmentOnly;
		};
		#pragma pack(push, tp, 1)
		struct
		{
			double ___doubleValue;
		};
		#pragma pack(pop, tp)
		struct
		{
			double ___doubleValue_forAlignmentOnly;
		};
	};
};
struct CameraData_tC27AE109CD20677486A4AC19C0CF014AE0F50C3E 
{
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___m_ViewMatrix;
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___m_ProjectionMatrix;
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___m_JitterMatrix;
	Camera_tA92CC927D7439999BC82DBEDC0AA45B470F9E184* ___camera;
	int32_t ___renderType;
	RenderTexture_tBA90C4C3AD9EECCFDDCC632D97C29FAB80D60D27* ___targetTexture;
	RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46 ___cameraTargetDescriptor;
	Rect_tA04E0F8A1830E767F40FB27ECD8D309303571F0D ___pixelRect;
	bool ___useScreenCoordOverride;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___screenSizeOverride;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___screenCoordScaleBias;
	int32_t ___pixelWidth;
	int32_t ___pixelHeight;
	float ___aspectRatio;
	float ___renderScale;
	int32_t ___imageScalingMode;
	int32_t ___upscalingFilter;
	bool ___fsrOverrideSharpness;
	float ___fsrSharpness;
	int32_t ___hdrColorBufferPrecision;
	bool ___clearDepth;
	int32_t ___cameraType;
	bool ___isDefaultViewport;
	bool ___isHdrEnabled;
	bool ___allowHDROutput;
	bool ___requiresDepthTexture;
	bool ___requiresOpaqueTexture;
	bool ___postProcessingRequiresDepthTexture;
	bool ___xrRendering;
	int32_t ___defaultOpaqueSortFlags;
	XRPass_tFC4577E97B88E0EAAAB2EB387AB3A92E9EB9C6DF* ___U3CxrU3Ek__BackingField;
	bool ___isStereoEnabled;
	float ___maxShadowDistance;
	bool ___postProcessEnabled;
	RuntimeObject* ___captureActions;
	LayerMask_t97CB6BDADEDC3D6423C7BCFEA7F86DA2EC6241DB ___volumeLayerMask;
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___volumeTrigger;
	bool ___isStopNaNEnabled;
	bool ___isDitheringEnabled;
	int32_t ___antialiasing;
	int32_t ___antialiasingQuality;
	ScriptableRenderer_tF15B95BB85F26BE4B4719901D909831B89DC8892* ___renderer;
	bool ___resolveFinalTarget;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___worldSpaceCameraPos;
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___backgroundColor;
	TaaPersistentData_t7AD3D320FD8FE7195225F0A7C7C676480A6ED775* ___taaPersistentData;
	Settings_t3BEFDFF2C1A3D3A215DAF7B76E735B1BFB946C92 ___taaSettings;
	Camera_tA92CC927D7439999BC82DBEDC0AA45B470F9E184* ___baseCamera;
};
struct CameraData_tC27AE109CD20677486A4AC19C0CF014AE0F50C3E_marshaled_pinvoke
{
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___m_ViewMatrix;
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___m_ProjectionMatrix;
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___m_JitterMatrix;
	Camera_tA92CC927D7439999BC82DBEDC0AA45B470F9E184* ___camera;
	int32_t ___renderType;
	RenderTexture_tBA90C4C3AD9EECCFDDCC632D97C29FAB80D60D27* ___targetTexture;
	RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46 ___cameraTargetDescriptor;
	Rect_tA04E0F8A1830E767F40FB27ECD8D309303571F0D ___pixelRect;
	int32_t ___useScreenCoordOverride;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___screenSizeOverride;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___screenCoordScaleBias;
	int32_t ___pixelWidth;
	int32_t ___pixelHeight;
	float ___aspectRatio;
	float ___renderScale;
	int32_t ___imageScalingMode;
	int32_t ___upscalingFilter;
	int32_t ___fsrOverrideSharpness;
	float ___fsrSharpness;
	int32_t ___hdrColorBufferPrecision;
	int32_t ___clearDepth;
	int32_t ___cameraType;
	int32_t ___isDefaultViewport;
	int32_t ___isHdrEnabled;
	int32_t ___allowHDROutput;
	int32_t ___requiresDepthTexture;
	int32_t ___requiresOpaqueTexture;
	int32_t ___postProcessingRequiresDepthTexture;
	int32_t ___xrRendering;
	int32_t ___defaultOpaqueSortFlags;
	XRPass_tFC4577E97B88E0EAAAB2EB387AB3A92E9EB9C6DF* ___U3CxrU3Ek__BackingField;
	int32_t ___isStereoEnabled;
	float ___maxShadowDistance;
	int32_t ___postProcessEnabled;
	RuntimeObject* ___captureActions;
	LayerMask_t97CB6BDADEDC3D6423C7BCFEA7F86DA2EC6241DB ___volumeLayerMask;
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___volumeTrigger;
	int32_t ___isStopNaNEnabled;
	int32_t ___isDitheringEnabled;
	int32_t ___antialiasing;
	int32_t ___antialiasingQuality;
	ScriptableRenderer_tF15B95BB85F26BE4B4719901D909831B89DC8892* ___renderer;
	int32_t ___resolveFinalTarget;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___worldSpaceCameraPos;
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___backgroundColor;
	TaaPersistentData_t7AD3D320FD8FE7195225F0A7C7C676480A6ED775* ___taaPersistentData;
	Settings_t3BEFDFF2C1A3D3A215DAF7B76E735B1BFB946C92 ___taaSettings;
	Camera_tA92CC927D7439999BC82DBEDC0AA45B470F9E184* ___baseCamera;
};
struct CameraData_tC27AE109CD20677486A4AC19C0CF014AE0F50C3E_marshaled_com
{
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___m_ViewMatrix;
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___m_ProjectionMatrix;
	Matrix4x4_tDB70CF134A14BA38190C59AA700BCE10E2AED3E6 ___m_JitterMatrix;
	Camera_tA92CC927D7439999BC82DBEDC0AA45B470F9E184* ___camera;
	int32_t ___renderType;
	RenderTexture_tBA90C4C3AD9EECCFDDCC632D97C29FAB80D60D27* ___targetTexture;
	RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46 ___cameraTargetDescriptor;
	Rect_tA04E0F8A1830E767F40FB27ECD8D309303571F0D ___pixelRect;
	int32_t ___useScreenCoordOverride;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___screenSizeOverride;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___screenCoordScaleBias;
	int32_t ___pixelWidth;
	int32_t ___pixelHeight;
	float ___aspectRatio;
	float ___renderScale;
	int32_t ___imageScalingMode;
	int32_t ___upscalingFilter;
	int32_t ___fsrOverrideSharpness;
	float ___fsrSharpness;
	int32_t ___hdrColorBufferPrecision;
	int32_t ___clearDepth;
	int32_t ___cameraType;
	int32_t ___isDefaultViewport;
	int32_t ___isHdrEnabled;
	int32_t ___allowHDROutput;
	int32_t ___requiresDepthTexture;
	int32_t ___requiresOpaqueTexture;
	int32_t ___postProcessingRequiresDepthTexture;
	int32_t ___xrRendering;
	int32_t ___defaultOpaqueSortFlags;
	XRPass_tFC4577E97B88E0EAAAB2EB387AB3A92E9EB9C6DF* ___U3CxrU3Ek__BackingField;
	int32_t ___isStereoEnabled;
	float ___maxShadowDistance;
	int32_t ___postProcessEnabled;
	RuntimeObject* ___captureActions;
	LayerMask_t97CB6BDADEDC3D6423C7BCFEA7F86DA2EC6241DB ___volumeLayerMask;
	Transform_tB27202C6F4E36D225EE28A13E4D662BF99785DB1* ___volumeTrigger;
	int32_t ___isStopNaNEnabled;
	int32_t ___isDitheringEnabled;
	int32_t ___antialiasing;
	int32_t ___antialiasingQuality;
	ScriptableRenderer_tF15B95BB85F26BE4B4719901D909831B89DC8892* ___renderer;
	int32_t ___resolveFinalTarget;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___worldSpaceCameraPos;
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___backgroundColor;
	TaaPersistentData_t7AD3D320FD8FE7195225F0A7C7C676480A6ED775* ___taaPersistentData;
	Settings_t3BEFDFF2C1A3D3A215DAF7B76E735B1BFB946C92 ___taaSettings;
	Camera_tA92CC927D7439999BC82DBEDC0AA45B470F9E184* ___baseCamera;
};
struct CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7  : public RuntimeObject
{
	intptr_t ___m_Ptr;
};
struct CullingResults_tD6B7EF20B68D47DFF3A99EB2EA73F47F1D460267 
{
	intptr_t ___ptr;
	CullingAllocationInfo_tB260F5CD0B290F74E145EB16E54B901CC68D9D5A* ___m_AllocationInfo;
};
struct Exception_t  : public RuntimeObject
{
	String_t* ____className;
	String_t* ____message;
	RuntimeObject* ____data;
	Exception_t* ____innerException;
	String_t* ____helpURL;
	RuntimeObject* ____stackTrace;
	String_t* ____stackTraceString;
	String_t* ____remoteStackTraceString;
	int32_t ____remoteStackIndex;
	RuntimeObject* ____dynamicMethods;
	int32_t ____HResult;
	String_t* ____source;
	SafeSerializationManager_tCBB85B95DFD1634237140CD892E82D06ECB3F5E6* ____safeSerializationManager;
	StackTraceU5BU5D_t32FBCB20930EAF5BAE3F450FF75228E5450DA0DF* ___captured_traces;
	IntPtrU5BU5D_tFD177F8C806A6921AD7150264CCC62FA00CAD832* ___native_trace_ips;
	int32_t ___caught_in_unmanaged;
};
struct Exception_t_marshaled_pinvoke
{
	char* ____className;
	char* ____message;
	RuntimeObject* ____data;
	Exception_t_marshaled_pinvoke* ____innerException;
	char* ____helpURL;
	Il2CppIUnknown* ____stackTrace;
	char* ____stackTraceString;
	char* ____remoteStackTraceString;
	int32_t ____remoteStackIndex;
	Il2CppIUnknown* ____dynamicMethods;
	int32_t ____HResult;
	char* ____source;
	SafeSerializationManager_tCBB85B95DFD1634237140CD892E82D06ECB3F5E6* ____safeSerializationManager;
	StackTraceU5BU5D_t32FBCB20930EAF5BAE3F450FF75228E5450DA0DF* ___captured_traces;
	Il2CppSafeArray* ___native_trace_ips;
	int32_t ___caught_in_unmanaged;
};
struct Exception_t_marshaled_com
{
	Il2CppChar* ____className;
	Il2CppChar* ____message;
	RuntimeObject* ____data;
	Exception_t_marshaled_com* ____innerException;
	Il2CppChar* ____helpURL;
	Il2CppIUnknown* ____stackTrace;
	Il2CppChar* ____stackTraceString;
	Il2CppChar* ____remoteStackTraceString;
	int32_t ____remoteStackIndex;
	Il2CppIUnknown* ____dynamicMethods;
	int32_t ____HResult;
	Il2CppChar* ____source;
	SafeSerializationManager_tCBB85B95DFD1634237140CD892E82D06ECB3F5E6* ____safeSerializationManager;
	StackTraceU5BU5D_t32FBCB20930EAF5BAE3F450FF75228E5450DA0DF* ___captured_traces;
	Il2CppSafeArray* ___native_trace_ips;
	int32_t ___caught_in_unmanaged;
};
struct IntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489 
{
	NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 ___points;
	NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___edges;
	U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0 ___xvasort;
	U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29 ___xvbsort;
};
struct LightData_t6A82F1C9AA97327A5EE9C16A3E949918F3A55470 
{
	int32_t ___mainLightIndex;
	int32_t ___additionalLightsCount;
	int32_t ___maxPerObjectAdditionalLightsCount;
	NativeArray_1_t71485A1E60B31CCAD3E525C907CF172E8B804468 ___visibleLights;
	bool ___shadeAdditionalLightsPerVertex;
	bool ___supportsMixedLighting;
	bool ___reflectionProbeBoxProjection;
	bool ___reflectionProbeBlending;
	bool ___supportsLightLayers;
	bool ___supportsAdditionalLights;
};
struct LightData_t6A82F1C9AA97327A5EE9C16A3E949918F3A55470_marshaled_pinvoke
{
	int32_t ___mainLightIndex;
	int32_t ___additionalLightsCount;
	int32_t ___maxPerObjectAdditionalLightsCount;
	NativeArray_1_t71485A1E60B31CCAD3E525C907CF172E8B804468 ___visibleLights;
	int32_t ___shadeAdditionalLightsPerVertex;
	int32_t ___supportsMixedLighting;
	int32_t ___reflectionProbeBoxProjection;
	int32_t ___reflectionProbeBlending;
	int32_t ___supportsLightLayers;
	int32_t ___supportsAdditionalLights;
};
struct LightData_t6A82F1C9AA97327A5EE9C16A3E949918F3A55470_marshaled_com
{
	int32_t ___mainLightIndex;
	int32_t ___additionalLightsCount;
	int32_t ___maxPerObjectAdditionalLightsCount;
	NativeArray_1_t71485A1E60B31CCAD3E525C907CF172E8B804468 ___visibleLights;
	int32_t ___shadeAdditionalLightsPerVertex;
	int32_t ___supportsMixedLighting;
	int32_t ___reflectionProbeBoxProjection;
	int32_t ___reflectionProbeBlending;
	int32_t ___supportsLightLayers;
	int32_t ___supportsAdditionalLights;
};
struct RTHandleProperties_tBCB3E1EFE8B366995704C1322B9C443877580CD6 
{
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___previousViewportSize;
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___previousRenderTargetSize;
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___currentViewportSize;
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___currentRenderTargetSize;
	Vector4_t58B63D32F48C0DBF50DE2C60794C4676C80EDBE3 ___rtHandleScale;
};
struct RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13  : public RuntimeObject
{
	SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4 ___m_A;
	SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4 ___m_B;
	int32_t ___m_FilterMode;
	bool ___m_AllowMSAA;
};
struct RenderTargetIdentifier_tA528663AC6EB3911D8E91AA40F7070FA5455442B 
{
	int32_t ___m_Type;
	int32_t ___m_NameID;
	int32_t ___m_InstanceID;
	intptr_t ___m_BufferPointer;
	int32_t ___m_MipLevel;
	int32_t ___m_CubeFace;
	int32_t ___m_DepthSlice;
};
struct ScriptableRenderContext_t5AB09B3602BEB456E0DC3D53926D3A3BDAF08E36 
{
	intptr_t ___m_Ptr;
};
struct ShadowData_tA165FDF7CA4CE6BEA8B649FFAB91C59ED684D832 
{
	bool ___supportsMainLightShadows;
	bool ___mainLightShadowsEnabled;
	bool ___requiresScreenSpaceShadowResolve;
	int32_t ___mainLightShadowmapWidth;
	int32_t ___mainLightShadowmapHeight;
	int32_t ___mainLightShadowCascadesCount;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___mainLightShadowCascadesSplit;
	float ___mainLightShadowCascadeBorder;
	bool ___supportsAdditionalLightShadows;
	bool ___additionalLightShadowsEnabled;
	int32_t ___additionalLightsShadowmapWidth;
	int32_t ___additionalLightsShadowmapHeight;
	bool ___supportsSoftShadows;
	int32_t ___shadowmapDepthBufferBits;
	List_1_tF42FEB6C3B18B7E7C8F2DE1FEBA00D2491736317* ___bias;
	List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* ___resolution;
	bool ___isKeywordAdditionalLightShadowsEnabled;
	bool ___isKeywordSoftShadowsEnabled;
};
struct ShadowData_tA165FDF7CA4CE6BEA8B649FFAB91C59ED684D832_marshaled_pinvoke
{
	int32_t ___supportsMainLightShadows;
	int32_t ___mainLightShadowsEnabled;
	int32_t ___requiresScreenSpaceShadowResolve;
	int32_t ___mainLightShadowmapWidth;
	int32_t ___mainLightShadowmapHeight;
	int32_t ___mainLightShadowCascadesCount;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___mainLightShadowCascadesSplit;
	float ___mainLightShadowCascadeBorder;
	int32_t ___supportsAdditionalLightShadows;
	int32_t ___additionalLightShadowsEnabled;
	int32_t ___additionalLightsShadowmapWidth;
	int32_t ___additionalLightsShadowmapHeight;
	int32_t ___supportsSoftShadows;
	int32_t ___shadowmapDepthBufferBits;
	List_1_tF42FEB6C3B18B7E7C8F2DE1FEBA00D2491736317* ___bias;
	List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* ___resolution;
	int32_t ___isKeywordAdditionalLightShadowsEnabled;
	int32_t ___isKeywordSoftShadowsEnabled;
};
struct ShadowData_tA165FDF7CA4CE6BEA8B649FFAB91C59ED684D832_marshaled_com
{
	int32_t ___supportsMainLightShadows;
	int32_t ___mainLightShadowsEnabled;
	int32_t ___requiresScreenSpaceShadowResolve;
	int32_t ___mainLightShadowmapWidth;
	int32_t ___mainLightShadowmapHeight;
	int32_t ___mainLightShadowCascadesCount;
	Vector3_t24C512C7B96BBABAD472002D0BA2BDA40A5A80B2 ___mainLightShadowCascadesSplit;
	float ___mainLightShadowCascadeBorder;
	int32_t ___supportsAdditionalLightShadows;
	int32_t ___additionalLightShadowsEnabled;
	int32_t ___additionalLightsShadowmapWidth;
	int32_t ___additionalLightsShadowmapHeight;
	int32_t ___supportsSoftShadows;
	int32_t ___shadowmapDepthBufferBits;
	List_1_tF42FEB6C3B18B7E7C8F2DE1FEBA00D2491736317* ___bias;
	List_1_t05915E9237850A58106982B7FE4BC5DA4E872E73* ___resolution;
	int32_t ___isKeywordAdditionalLightShadowsEnabled;
	int32_t ___isKeywordSoftShadowsEnabled;
};
struct TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38 
{
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___roots;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___ranks;
};
struct Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239 
{
	NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___m_Edges;
	NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099 ___m_Stars;
	NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 ___m_Cells;
	int32_t ___m_CellCount;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___m_ILArray;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___m_IUArray;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___m_SPArray;
	int32_t ___m_NumEdges;
	int32_t ___m_NumHulls;
	int32_t ___m_NumPoints;
	int32_t ___m_StarCount;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___m_Flags;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___m_Neighbors;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___m_Constraints;
	int32_t ___m_Allocator;
};
struct TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 
{
	ResourceHandle_t0B9B0555328A08152F1EDA2BE4024446D670531A ___handle;
};
struct UBounds_tCDBF966FD073C0EF8873F75FE739F8EEB030CAFC 
{
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___min;
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___max;
};
struct UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 
{
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___center;
	float ___radius;
};
struct UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA 
{
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___a;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___b;
	int32_t ___index;
};
struct UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 
{
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___a;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___b;
	int32_t ___idx;
	int32_t ___type;
};
struct UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 
{
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___a;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___b;
	int32_t ___idx;
	ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 ___ilarray;
	int32_t ___ilcount;
	ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 ___iuarray;
	int32_t ___iucount;
};
struct UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 
{
	ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 ___points;
	int32_t ___pointCount;
};
struct RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B  : public RuntimeObject
{
	RTHandleSystem_tAE496B31B56A77B4896E34576C961C3CA073998F* ___m_Owner;
	RenderTexture_tBA90C4C3AD9EECCFDDCC632D97C29FAB80D60D27* ___m_RT;
	Texture_t791CBB51219779964E0E8A2ED7C1AA5F92A4A700* ___m_ExternalTexture;
	RenderTargetIdentifier_tA528663AC6EB3911D8E91AA40F7070FA5455442B ___m_NameID;
	bool ___m_EnableMSAA;
	bool ___m_EnableRandomWrite;
	bool ___m_EnableHWDynamicScale;
	String_t* ___m_Name;
	bool ___m_UseCustomHandleScales;
	RTHandleProperties_tBCB3E1EFE8B366995704C1322B9C443877580CD6 ___m_CustomHandleProperties;
	Vector2_t1FD6F485C871E832B347AB2DC8CBA08B739D8DF7 ___U3CscaleFactorU3Ek__BackingField;
	ScaleFunc_t423F661DAD5C7A18F509C8F1F62C9D6AEA9A9791* ___scaleFunc;
	bool ___U3CuseScalingU3Ek__BackingField;
	Vector2Int_t69B2886EBAB732D9B880565E18E7568F3DE0CE6A ___U3CreferenceSizeU3Ek__BackingField;
};
struct RenderGraphContext_t230588A81E5222F21FB773FD8D1DB979190E0A08  : public RuntimeObject
{
	ScriptableRenderContext_t5AB09B3602BEB456E0DC3D53926D3A3BDAF08E36 ___renderContext;
	CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* ___cmd;
	RenderGraphObjectPool_t266B5D9BA6D695C3E7E1A3919F3304504C5BCC7A* ___renderGraphPool;
	RenderGraphDefaultResources_t9911A2DC8A2C28E3A1F7F2D48B03AFBCEF1F499B* ___defaultResources;
};
struct RenderGraphDefaultResources_t9911A2DC8A2C28E3A1F7F2D48B03AFBCEF1F499B  : public RuntimeObject
{
	bool ___m_IsValid;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* ___m_BlackTexture2D;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* ___m_WhiteTexture2D;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* ___m_ShadowTexture2D;
	TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 ___U3CblackTextureU3Ek__BackingField;
	TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 ___U3CwhiteTextureU3Ek__BackingField;
	TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 ___U3CclearTextureXRU3Ek__BackingField;
	TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 ___U3CmagentaTextureXRU3Ek__BackingField;
	TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 ___U3CblackTextureXRU3Ek__BackingField;
	TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 ___U3CblackTextureArrayXRU3Ek__BackingField;
	TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 ___U3CblackUIntTextureXRU3Ek__BackingField;
	TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 ___U3CblackTexture3DXRU3Ek__BackingField;
	TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 ___U3CwhiteTextureXRU3Ek__BackingField;
	TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 ___U3CdefaultShadowTextureU3Ek__BackingField;
};
struct RenderingData_tAAA01190551D6D5954314E3E1E85B58DD45EED71 
{
	CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* ___commandBuffer;
	CullingResults_tD6B7EF20B68D47DFF3A99EB2EA73F47F1D460267 ___cullResults;
	CameraData_tC27AE109CD20677486A4AC19C0CF014AE0F50C3E ___cameraData;
	LightData_t6A82F1C9AA97327A5EE9C16A3E949918F3A55470 ___lightData;
	ShadowData_tA165FDF7CA4CE6BEA8B649FFAB91C59ED684D832 ___shadowData;
	PostProcessingData_tFA75BF22951C600258B2707AF7A113E4EDA49BD4 ___postProcessingData;
	bool ___supportsDynamicBatching;
	int32_t ___perObjectData;
	bool ___postProcessingEnabled;
};
struct RenderingData_tAAA01190551D6D5954314E3E1E85B58DD45EED71_marshaled_pinvoke
{
	CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* ___commandBuffer;
	CullingResults_tD6B7EF20B68D47DFF3A99EB2EA73F47F1D460267 ___cullResults;
	CameraData_tC27AE109CD20677486A4AC19C0CF014AE0F50C3E_marshaled_pinvoke ___cameraData;
	LightData_t6A82F1C9AA97327A5EE9C16A3E949918F3A55470_marshaled_pinvoke ___lightData;
	ShadowData_tA165FDF7CA4CE6BEA8B649FFAB91C59ED684D832_marshaled_pinvoke ___shadowData;
	PostProcessingData_tFA75BF22951C600258B2707AF7A113E4EDA49BD4_marshaled_pinvoke ___postProcessingData;
	int32_t ___supportsDynamicBatching;
	int32_t ___perObjectData;
	int32_t ___postProcessingEnabled;
};
struct RenderingData_tAAA01190551D6D5954314E3E1E85B58DD45EED71_marshaled_com
{
	CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* ___commandBuffer;
	CullingResults_tD6B7EF20B68D47DFF3A99EB2EA73F47F1D460267 ___cullResults;
	CameraData_tC27AE109CD20677486A4AC19C0CF014AE0F50C3E_marshaled_com ___cameraData;
	LightData_t6A82F1C9AA97327A5EE9C16A3E949918F3A55470_marshaled_com ___lightData;
	ShadowData_tA165FDF7CA4CE6BEA8B649FFAB91C59ED684D832_marshaled_com ___shadowData;
	PostProcessingData_tFA75BF22951C600258B2707AF7A113E4EDA49BD4_marshaled_com ___postProcessingData;
	int32_t ___supportsDynamicBatching;
	int32_t ___perObjectData;
	int32_t ___postProcessingEnabled;
};
struct ScriptableRenderPass_tEA38F6C7AD8D111A2251E4C2A7530BCEE7D6D2B0  : public RuntimeObject
{
	int32_t ___U3CrenderPassEventU3Ek__BackingField;
	RenderBufferStoreActionU5BU5D_tFEA8F5DD460573EA9F35FBEC5727D1804C5DCBF5* ___m_ColorStoreActions;
	int32_t ___m_DepthStoreAction;
	BooleanU5BU5D_tD317D27C31DB892BE79FAE3AEBC0B3FFB73DE9B4* ___m_OverriddenColorStoreActions;
	bool ___m_OverriddenDepthStoreAction;
	ProfilingSampler_t420D4672EDB44E0EF980B31ADFD9E5747200FECE* ___U3CprofilingSamplerU3Ek__BackingField;
	bool ___U3CoverrideCameraTargetU3Ek__BackingField;
	bool ___U3CisBlitRenderPassU3Ek__BackingField;
	bool ___U3CuseNativeRenderPassU3Ek__BackingField;
	int32_t ___U3CrenderPassQueueIndexU3Ek__BackingField;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___m_ColorAttachmentIndices;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___m_InputAttachmentIndices;
	GraphicsFormatU5BU5D_tF6A3D90C430FA3F548B77E5D58D25D71F154E6C5* ___U3CrenderTargetFormatU3Ek__BackingField;
	bool ___m_UsesRTHandles;
	RTHandleU5BU5D_tE4B403B060D159B839BF74E8B59F8DCD52CF97DF* ___m_ColorAttachments;
	RenderTargetIdentifierU5BU5D_t179798C153B7CE381B41C57863F98CB24023C4CE* ___m_ColorAttachmentIds;
	RTHandleU5BU5D_tE4B403B060D159B839BF74E8B59F8DCD52CF97DF* ___m_InputAttachments;
	BooleanU5BU5D_tD317D27C31DB892BE79FAE3AEBC0B3FFB73DE9B4* ___m_InputAttachmentIsTransient;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* ___m_DepthAttachment;
	RenderTargetIdentifier_tA528663AC6EB3911D8E91AA40F7070FA5455442B ___m_DepthAttachmentId;
	int32_t ___m_Input;
	int32_t ___m_ClearFlag;
	Color_tD001788D726C3A7F1379BEED0260B9591F440C1F ___m_ClearColor;
};
struct UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD 
{
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___va;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___vb;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___vc;
	UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 ___c;
	float ___area;
	int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___indices;
};
struct MainLightShadowCasterPass_tC550260377ED69F98337CF963695B7A090B137E3  : public ScriptableRenderPass_tEA38F6C7AD8D111A2251E4C2A7530BCEE7D6D2B0
{
	float ___m_CascadeBorder;
	float ___m_MaxShadowDistanceSq;
	int32_t ___m_ShadowCasterCascadesCount;
	int32_t ___m_MainLightShadowmapID;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* ___m_MainLightShadowmapTexture;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* ___m_EmptyLightShadowmapTexture;
	Matrix4x4U5BU5D_t9C51C93425FABC022B506D2DB3A5FA70F9752C4D* ___m_MainLightShadowMatrices;
	ShadowSliceDataU5BU5D_t3B41B7A06BAB3677671AEE84FBCF1A23B7DC7D04* ___m_CascadeSlices;
	Vector4U5BU5D_tC0F3A7115F85007510F6D173968200CD31BCF7AD* ___m_CascadeSplitDistances;
	bool ___m_CreateEmptyShadowmap;
	int32_t ___renderTargetWidth;
	int32_t ___renderTargetHeight;
	ProfilingSampler_t420D4672EDB44E0EF980B31ADFD9E5747200FECE* ___m_ProfilingSetupSampler;
};
struct PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A  : public RuntimeObject
{
	MainLightShadowCasterPass_tC550260377ED69F98337CF963695B7A090B137E3* ___pass;
	RenderGraph_t5AA201AC80DFD885B4FFB147432366185AE489BB* ___graph;
	TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 ___shadowmapTexture;
	RenderingData_tAAA01190551D6D5954314E3E1E85B58DD45EED71 ___renderingData;
	int32_t ___shadowmapID;
	bool ___emptyShadowmap;
};
struct U3CPrivateImplementationDetailsU3E_t16CE31F4DEE6BA0AEFEB3FA0105D58630695B339_StaticFields
{
	__StaticArrayInitTypeSizeU3D16_tB86B9BFC4ADBF4E2DF11F39AF43639693C65DF05 ___08243D32F28C35701F6EA57F52AE707302C8528E8D358F13C6E6915543D265C6;
	__StaticArrayInitTypeSizeU3D24_tB605E983EFADFA4C2759D8C48AB45B0B3A7BCC51 ___18689A54C1FF754BE58500B2ED77A6C75B025BE96F6D01FEF89C42DA1C953F34;
	__StaticArrayInitTypeSizeU3D12_t5F40C9EEDE242DFE47A8DCE218ED3DF3E88B4EC0 ___4636993D3E1DA4E9D6B8F87B79E8F7C6D018580D52661950EABC3845C5897A4D;
	__StaticArrayInitTypeSizeU3D960_t86900CB1F8550ABFAD884FDD8E17F7B7AA90ED0D ___6322123493378558D4F9DD025993C168685B194246485704DD5B391FDCD77A64;
	__StaticArrayInitTypeSizeU3D16_tB86B9BFC4ADBF4E2DF11F39AF43639693C65DF05 ___888955380992D62883B27CC51FDC7E5C290C441026048F403C5618F305AD2BF1;
	__StaticArrayInitTypeSizeU3D12_t5F40C9EEDE242DFE47A8DCE218ED3DF3E88B4EC0 ___8E2129A5F232A49B45FCB149981C3507166B7EE6265A5B90A1C9B0B87B2C0A80;
	__StaticArrayInitTypeSizeU3D12_t5F40C9EEDE242DFE47A8DCE218ED3DF3E88B4EC0 ___9D3A6E7E88415D8C1A0F3887B6384A9A8E4F44A036C5A24796C319751ACACCAD;
	__StaticArrayInitTypeSizeU3D18057_tD52D99338C7D77BF40020E570B4ED083432382CE ___9DD94E5B9375C5F9EB745AE3472D96C270DDB32E8E49D8AB1165647A5817343C;
	__StaticArrayInitTypeSizeU3D12_t5F40C9EEDE242DFE47A8DCE218ED3DF3E88B4EC0 ___B6599D21CE74F24FA42D57991D6B0D0C5770322C90AF734EEB36A37F74090137;
	__StaticArrayInitTypeSizeU3D16_tB86B9BFC4ADBF4E2DF11F39AF43639693C65DF05 ___BAED642339816AFFB3FE8719792D0E4CE82F12DB72B7373D244EAA65445800FE;
	__StaticArrayInitTypeSizeU3D23517_tF4800C5299C00EDBB2EFE21EFC6012069C100625 ___C356A383406DAC2C689C39C9FD6A193AE149E4C58EBDFD17174E76AFC87DAD21;
	__StaticArrayInitTypeSizeU3D16_tB86B9BFC4ADBF4E2DF11F39AF43639693C65DF05 ___C94719FC63BFC7010A8361E8B4D4746BAB3C8AD593769F86532655EE58EBB101;
	__StaticArrayInitTypeSizeU3D960_t86900CB1F8550ABFAD884FDD8E17F7B7AA90ED0D ___E2EF5640DF412939A64301FFA3F66A62A34FA6E45A26E62F6994E5390B380D01;
};
struct RenderGraph_t5AA201AC80DFD885B4FFB147432366185AE489BB_StaticFields
{
	int32_t ___kMaxMRTCount;
	List_1_t212D7D10D2A8B008F722C657B1D0E8D655B83C77* ___s_RegisteredGraphs;
	bool ___U3CrequireDebugDataU3Ek__BackingField;
	OnGraphRegisteredDelegate_t31768B4561FF76800AC9B3D17A837827EC7E0EB9* ___onGraphRegistered;
	OnGraphRegisteredDelegate_t31768B4561FF76800AC9B3D17A837827EC7E0EB9* ___onGraphUnregistered;
	OnExecutionRegisteredDelegate_t4E612DCD17907BD63A44EEF6E3A0B43FD2A87FEE* ___onExecutionRegistered;
	OnExecutionRegisteredDelegate_t4E612DCD17907BD63A44EEF6E3A0B43FD2A87FEE* ___onExecutionUnregistered;
};
struct String_t_StaticFields
{
	String_t* ___Empty;
};
struct U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264_StaticFields
{
	U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264* ___U3CU3E9;
	RenderFunc_1_tAFF473C45BAB6B92BED11F24D63410C61AEDB710* ___U3CU3E9__27_0;
	RenderFunc_1_tAFF473C45BAB6B92BED11F24D63410C61AEDB710* ___U3CU3E9__27_1;
};
struct MainLightShadowConstantBuffer_tDE7E52C397EA5C7066924F7C9DC843321DF0A6E3_StaticFields
{
	int32_t ____WorldToShadow;
	int32_t ____ShadowParams;
	int32_t ____CascadeShadowSplitSpheres0;
	int32_t ____CascadeShadowSplitSpheres1;
	int32_t ____CascadeShadowSplitSpheres2;
	int32_t ____CascadeShadowSplitSpheres3;
	int32_t ____CascadeShadowSplitSphereRadii;
	int32_t ____ShadowOffset0;
	int32_t ____ShadowOffset1;
	int32_t ____ShadowmapSize;
};
struct Boolean_t09A6377A54BE2F9E6985A8149F19234FD7DDFE22_StaticFields
{
	String_t* ___TrueString;
	String_t* ___FalseString;
};
struct ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields
{
	int32_t ___kMaxArea;
	int32_t ___kMaxEdgeCount;
	int32_t ___kMaxIndexCount;
	int32_t ___kMaxVertexCount;
	int32_t ___kMaxTriangleCount;
	int32_t ___kMaxRefineIterations;
	int32_t ___kMaxSmoothenIterations;
	float ___kIncrementAreaFactor;
};
struct PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields
{
	double ___kEpsilon;
	int32_t ___kMaxIntersectionTolerance;
};
struct Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_StaticFields
{
	float ___kMinAreaFactor;
	float ___kMaxAreaFactor;
	int32_t ___kMaxSteinerCount;
};
struct Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_StaticFields
{
	float ___kMaxAreaTolerance;
	float ___kMaxEdgeTolerance;
};
struct double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA_StaticFields
{
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___zero;
};
struct float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_StaticFields
{
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___zero;
};
struct float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E_StaticFields
{
	float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___zero;
};
struct float4_t89D9A294E7A79BD81BFBDD18654508532958555E_StaticFields
{
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E ___zero;
};
struct int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_StaticFields
{
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___zero;
};
struct int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_StaticFields
{
	int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___zero;
};
struct int4_tBA77D4945786DE82C3A487B33955EA1004996052_StaticFields
{
	int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___zero;
};
struct Exception_t_StaticFields
{
	RuntimeObject* ___s_EDILock;
};
struct RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields
{
	bool ___m_AisBackBuffer;
	RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46 ___m_Desc;
};
struct ScriptableRenderContext_t5AB09B3602BEB456E0DC3D53926D3A3BDAF08E36_StaticFields
{
	ShaderTagId_t453E2085B5EE9448FF75E550CAB111EFF690ECB0 ___kRenderTypeTag;
};
struct TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09_StaticFields
{
	TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 ___s_NullHandle;
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif


IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void* NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D_gshared (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_nativeArray, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434_mBE4B56307E132AEA84ADF183CC238AA9ED176FA6_gshared (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434 ___3_comp, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisIntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489_mCEC67F4B9CB4B8CA627B923D2CFC9173F15EC916_gshared (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, IntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489 ___3_comp, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249_mDFFBE16DF5663EFCBC9251F641DD620ACBF7374D_gshared (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, TessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249 ___3_comp, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_gshared (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_gshared (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_mC429670774D3D1F7CB41BBD8C5BD9943404BDF54_gshared (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C_gshared (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_src, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___1_dst, int32_t ___2_length, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_gshared (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_mE0AE14258D3045288D915F3FD346533D843D7CDB_gshared (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_gshared (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_mCFEB37C6F648F756D9AC2C044D2EE01AE66DBE34_gshared (NativeArray_1_tB723C353A73B34FE57C3B9EA16A02A466B268BC2* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_m89F748542AF7065DD1BC4780E9A0E4F3D41073ED_gshared (NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_mB48AC20750ECFD2702E0F9915B2177D044D15C58_gshared (NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_m2FC0457FE238F347CEF96BDA77BA875179E5704B_gshared (NativeArray_1_tB723C353A73B34FE57C3B9EA16A02A466B268BC2* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_Copy_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mE623C4A9806A975DC543E10F18CD15CADCD6D02F_gshared (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 ___0_src, NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 ___1_dst, int32_t ___2_length, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_mC01F44D62CB455BB4FE045F1FFB6BBD3516CB265_gshared (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void* NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mB537AB040DF35BD6BE8FEBE48C04901884E592E3_gshared (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 ___0_nativeArray, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_InsertionSort_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_TisDelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B_m18BA196C639121F5500845FA59E90F34DB272028_gshared (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, DelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B ___3_comp, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_m38861384F84F1CD89A47D663C29D3ED425C5CCE0_gshared (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3_m0A70D6C3B3B43D49B43B90E25921F0935E4F0853_gshared (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_values, int32_t ___1_count, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_check, TestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3 ___3_condition, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ModuleHandle_GetUpper_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436_mFF87B6D1AF19335BBFCBFC9A88B90165B26C3987_gshared (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_values, int32_t ___1_count, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_check, TestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436 ___3_condition, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_gshared (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* __this, int32_t ___0_index, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ArraySlice_1_get_Length_m814A8881AF759049A308E6E04BE0451BFDA0076B_gshared_inline (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_gshared (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* __this, int32_t ___0_index, int32_t ___1_value, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D_mDDE7DE6D079B34BF84F234F97CEF203430E49608_gshared (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_values, int32_t ___1_count, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___2_check, TestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D ___3_condition, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402_gshared (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* __this, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___0_array, int32_t ___1_start, int32_t ___2_length, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ModuleHandle_GetEqual_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155_m27B4DE791ADEB1742E19D6628CA333842FC8FC54_gshared (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_values, int32_t ___1_count, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___2_check, TestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155 ___3_condition, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_m9D79AD54D34744D093257128146409873295E2DB_gshared (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ModuleHandle_GetEqual_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375_m00A96EB8B356CCA03D3D724C514C6175681907A8_gshared (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_values, int32_t ___1_count, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___2_check, TestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375 ___3_condition, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F_gshared (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t ModuleHandle_GetEqual_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1_mA2DC9A659A83000A07E39BAAFFA6588DF23C361A_gshared (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 ___0_values, int32_t ___1_count, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___2_check, TestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1 ___3_condition, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void* NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_m9322523E8F4F331EE08D7DE23A5F5E48B851AF00_gshared (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 ___0_nativeArray, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_InsertionSort_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE_mB73DA078075FCD273BA172C5E5D6EEDDBFA8279D_gshared (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE ___3_comp, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213_gshared (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_mEB7F36BB585F82EDD8F8C88166579082DFA402BF_gshared (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_m56963AF6292CEE1271AFDE037CEFD1B70C5050D4_gshared (NativeArray_1_t97EAB41C5774F97823C769B51FBCAC8DE508B75D* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void* NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_mD7FAFF405DB2912073D4F221E3403DEF24972B52_gshared (NativeArray_1_t97EAB41C5774F97823C769B51FBCAC8DE508B75D ___0_nativeArray, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_InsertionSort_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F_m1706B12E442DF1715DFA736CA4077E4896F0F251_gshared (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, TessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F ___3_comp, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_m44CBE8EDE8CD7B71350BF815EE8BB232511E7D79_gshared (NativeArray_1_t97EAB41C5774F97823C769B51FBCAC8DE508B75D* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_m9D682D26EB442C42FBAB528F6F5F90AE5C216E8C_gshared (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool NativeArray_1_get_IsCreated_m5BE85069615B49772C9DB202004FA2FD36F418F2_gshared_inline (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool NativeArray_1_get_IsCreated_mB43459BFDEF78038051D817E8A57FF1DF3C3D738_gshared_inline (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_m1ACF94B84372AD81EEE7228152F8E1770B09180B_gshared (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_gshared_inline (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool NativeArray_1_get_IsCreated_m448EBF5E1AF8055E179079DE8883B7F449125BAB_gshared_inline (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_InsertionSort_TisDouble_tE150EF3D1D43DEE85D533810AB4C742307EEDE5F_TisXCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B_mD9DFBCA0EC70F5BF558FBC5C79E929BB2316EFB7_gshared (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B ___3_comp, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F_gshared (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_src, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___1_dst, int32_t ___2_length, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_Copy_TisInt32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_m08EAF9EE4BD7B3611121EEBB1CA1AC40D9C29874_gshared (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___0_src, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___1_dst, int32_t ___2_length, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_gshared (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_gshared (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IJobExtensions_EarlyJobInit_TisDrawCallJob_t3EA2ABC822AD5DF50675A5B437DAB927DB95215D_m8175192716D38C9C006D2C98D5B36A7CC75E33AD_gshared (const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IJobParallelForTransformExtensions_EarlyJobInit_TisUpdateTransformsJob_t7CF957169E8C6560084F48A51BC15A447F3002C7_mA2F79749E27788E6B6B0DA93086B08A0C553480E_gshared (const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IJobForExtensions_EarlyJobInit_TisLightMinMaxZJob_tB4FE0854445DAADF46E5511EAAF54EA1E4B611C4_m6D407EF2FD72EE5C26BA1C843C9932ABCB9C16DA_gshared (const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IJobForExtensions_EarlyJobInit_TisReflectionProbeMinMaxZJob_tB55272F39D5B8B189F5DF7212CDA3FFF1EC0C71C_mE2595D2099394DF551AC793D9874D90167904DF2_gshared (const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IJobForExtensions_EarlyJobInit_TisTileRangeExpansionJob_t8342AD91DCB87CA5DBDB463981EE24D47408C876_m7F3455814736950B257AF91E4AE26136F7D2D588_gshared (const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IJobForExtensions_EarlyJobInit_TisTilingJob_t4506E6F62C95A90210A474DE43C83AF5EB8D3352_m4C05E9D5B6CBBFDCFF690B0C60C83CC47D299593_gshared (const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void IJobForExtensions_EarlyJobInit_TisZBinningJob_t9BC217C31924E66E667568C1B51EA2F44FA0A08E_mA5B015BCBE9BD211FDEFDAE5347DCBE7E91D1970_gshared (const RuntimeMethod* method) ;

IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2 (RuntimeObject* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m058892C1C716FD6680DFAFD5ED2A8BFAD692237C (U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainLightShadowCasterPass_RenderMainLightCascadeShadowmap_mF64DA095A00063B7429659FC71431C7F79B896C4 (MainLightShadowCasterPass_tC550260377ED69F98337CF963695B7A090B137E3* __this, ScriptableRenderContext_t5AB09B3602BEB456E0DC3D53926D3A3BDAF08E36* ___0_context, RenderingData_tAAA01190551D6D5954314E3E1E85B58DD45EED71* ___1_renderingData, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void MainLightShadowCasterPass_SetEmptyMainLightCascadeShadowmap_m1CC8D3E22696FC7CED71EBD3A99E6880EE458B5A (MainLightShadowCasterPass_tC550260377ED69F98337CF963695B7A090B137E3* __this, ScriptableRenderContext_t5AB09B3602BEB456E0DC3D53926D3A3BDAF08E36* ___0_context, RenderingData_tAAA01190551D6D5954314E3E1E85B58DD45EED71* ___1_renderingData, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RenderGraphDefaultResources_t9911A2DC8A2C28E3A1F7F2D48B03AFBCEF1F499B* RenderGraph_get_defaultResources_mAF14CF66D8EEB8E7BE53241437E9D7005C662E17_inline (RenderGraph_t5AA201AC80DFD885B4FFB147432366185AE489BB* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 RenderGraphDefaultResources_get_defaultShadowTexture_m4EA8FB8D0893BC33315B9FE9339E1C37DE050F50_inline (RenderGraphDefaultResources_t9911A2DC8A2C28E3A1F7F2D48B03AFBCEF1F499B* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RenderTargetIdentifier_tA528663AC6EB3911D8E91AA40F7070FA5455442B TextureHandle_op_Implicit_m7D0B532B3A4CE3E92E1FC08A743BED70AC767A55 (TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 ___0_texture, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void CommandBuffer_SetGlobalTexture_m65E012CB3C35EA43533CB4FF4C6F6498FDE229CD (CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* __this, int32_t ___0_nameID, RenderTargetIdentifier_tA528663AC6EB3911D8E91AA40F7070FA5455442B ___1_value, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR String_t* String_Concat_m9E3155FB84015C823606188F53B47CB44C444991 (String_t* ___0_str0, String_t* ___1_str1, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RTHandle_Release_m743C2A22FD95D177D2D425E9DF1F3088161F387B (RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* RenderTargetBufferSystem_get_backBuffer_mF7305DBD196865D17A0029AC212E8CC02D8205A2 (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RenderTargetBufferSystem_ReAllocate_m21F112E4C9D22893403D2BDC60ED8D41312AE0D9 (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* ___0_cmd, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* RenderTargetBufferSystem_PeekBackBuffer_m5496A9F37497CE9915D760AD5F44FEA5EE304941 (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* RenderTargetBufferSystem_get_frontBuffer_mDD8E09139E41F59A682216AD6C0A94AE4387E11A (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void RenderTextureDescriptor_set_msaaSamples_m6910E09489372746391B14FBAF59A7237539D6C4_inline (RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46* __this, int32_t ___0_value, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t RenderTextureDescriptor_get_msaaSamples_mFCC33643AFF2265C8305DCFD79ED8774A1A8FA22_inline (RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46* __this, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool RenderingUtils_ReAllocateIfNeeded_mDE48AE1C4158076D30E8D4D9322A9EE4219C2812 (RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B** ___0_handle, RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46* ___1_descriptor, int32_t ___2_filterMode, int32_t ___3_wrapMode, bool ___4_isShadowMap, int32_t ___5_anisoLevel, float ___6_mipMapBias, String_t* ___7_name, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RenderTargetIdentifier_tA528663AC6EB3911D8E91AA40F7070FA5455442B RTHandle_op_Implicit_m2462183372B0496DE475889924EDCAAAD2011B54 (RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* ___0_handle, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void CommandBuffer_SetGlobalTexture_mD6F1CC7E87FA88B5838D5EDAFBA602EF94FE1F69 (CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* __this, String_t* ___0_name, RenderTargetIdentifier_tA528663AC6EB3911D8E91AA40F7070FA5455442B ___1_value, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RenderTextureDescriptor_set_depthBufferBits_mA3710C0D6E485BA6465B328CD8B1954F0E4C5819 (RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46* __this, int32_t ___0_value, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RenderTargetBufferSystem_EnableMSAA_mFACEC550EEF2910AC94C1F22C0DA146DBE36F3CA (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, bool ___0_enable, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_min_m02D43DF516544C279AF660EA4731449C82991849_inline (int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline (int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) ;
inline void* NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_nativeArray, const RuntimeMethod* method)
{
	return ((  void* (*) (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2, const RuntimeMethod*))NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D_gshared)(___0_nativeArray, method);
}
inline void ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434_mBE4B56307E132AEA84ADF183CC238AA9ED176FA6 (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434 ___3_comp, const RuntimeMethod* method)
{
	((  void (*) (void*, int32_t, int32_t, TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434, const RuntimeMethod*))ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434_mBE4B56307E132AEA84ADF183CC238AA9ED176FA6_gshared)(___0_array, ___1_lo, ___2_hi, ___3_comp, method);
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool math_isinf_m4901864832BAA489A01E23F560733ACEF6E3ED60_inline (double ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_abs_mDF669CF3AF2C60713E8E118578461CDA050DAFD0_inline (double ___0_x, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR double ModuleHandle_OrientFastDouble_mABC4A67B5FBB79701003AF2B4367E67DA4E021AA (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_a, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_b, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___2_c, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_CheckCollinear_mE8541609200181B09456FDBC9E5650D88FA8FB80 (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_a0, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_a1, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___2_b0, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___3_b1, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_LineLineIntersection_m2B966C163526B64A4DA7761553162AB175C37681 (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_a0, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_a1, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___2_b0, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___3_b1, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_LineLineIntersection_mE3A4C366A1D1393F4AA6811190BC4E42B861A3E9 (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_p1, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_p2, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___2_p3, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___3_p4, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA* ___4_result, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline (int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* __this, int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) ;
inline void ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisIntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489_mCEC67F4B9CB4B8CA627B923D2CFC9173F15EC916 (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, IntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489 ___3_comp, const RuntimeMethod* method)
{
	((  void (*) (void*, int32_t, int32_t, IntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489, const RuntimeMethod*))ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisIntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489_mCEC67F4B9CB4B8CA627B923D2CFC9173F15EC916_gshared)(___0_array, ___1_lo, ___2_hi, ___3_comp, method);
}
inline void ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249_mDFFBE16DF5663EFCBC9251F641DD620ACBF7374D (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, TessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249 ___3_comp, const RuntimeMethod* method)
{
	((  void (*) (void*, int32_t, int32_t, TessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249, const RuntimeMethod*))ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249_mDFFBE16DF5663EFCBC9251F641DD620ACBF7374D_gshared)(___0_array, ___1_lo, ___2_hi, ___3_comp, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38 TessLink_CreateLink_m1E7D2D1DD89E196BF1CBBDC76B508021F81B2FB8 (int32_t ___0_count, int32_t ___1_allocator, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_distance_m72BEFBAADFC4404FADD3AD81F7EDD40E32624F4D_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_x, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_y, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TessLink_Link_m549C4DE253753727A94A94BC9BC7EF6B417DC9E0 (TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38* __this, int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TessLink_Find_mAD567324D6131379359E9A266D2AC30A31F0226E (TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38* __this, int32_t ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA math_min_m1D64D6B67B27FD9738D14BCEE6298146CB05CE00_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_x, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_y, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TessLink_DestroyLink_m96AD3C95F393DABD8862EC3CE5F8EEEB905B1CAD (TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38 ___0_link, const RuntimeMethod* method) ;
inline void NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
inline void NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13 (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
inline void NativeArray_1__ctor_mC429670774D3D1F7CB41BBD8C5BD9943404BDF54 (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_mC429670774D3D1F7CB41BBD8C5BD9943404BDF54_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA float2_op_Multiply_m34D03129CE0D7AD665A914DE83CB749585B2455F_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_lhs, float ___1_rhs, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA double2_op_Implicit_m168C031549D6C086B7C49ECA5B18C892B3112F17_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_v, const RuntimeMethod* method) ;
inline void ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_src, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___1_dst, int32_t ___2_length, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2, int32_t, const RuntimeMethod*))ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C_gshared)(___0_src, ___1_dst, ___2_length, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlanarGraph_RemoveDuplicateEdges_m4D8093C793442A4260E7A6F688BC8831F4DC0AF9 (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___0_edges, int32_t* ___1_edgeCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___2_duplicates, int32_t ___3_duplicateCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_CalculateEdgeIntersections_mD28FD1B9C616447BC850126854BA901F527E4E72 (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_edges, int32_t ___1_edgeCount, NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 ___2_points, int32_t ___3_pointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___4_results, NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* ___5_intersects, int32_t* ___6_resultCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_CalculateTJunctions_m6BEE6D4B46B8B467D3ED4B72528B80DE33EF631D (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_edges, int32_t ___1_edgeCount, NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 ___2_points, int32_t ___3_pointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___4_results, int32_t* ___5_resultCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_CutEdges_m2FB895C4BE99D67313093CB017933D5DFADDD205 (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* ___0_points, int32_t* ___1_pointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___2_edges, int32_t* ___3_edgeCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___4_tJunctions, int32_t* ___5_tJunctionCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___6_intersections, NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 ___7_intersects, int32_t ___8_intersectionCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlanarGraph_RemoveDuplicatePoints_m44A9ABC6078AC3B50542117CEE25DF8DF9ED58A1 (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* ___0_points, int32_t* ___1_pointCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___2_duplicates, int32_t* ___3_duplicateCount, int32_t ___4_allocator, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* __this, float ___0_x, float ___1_y, const RuntimeMethod* method) ;
inline void NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2 (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*, const RuntimeMethod*))NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_gshared)(__this, method);
}
inline void NativeArray_1_Dispose_mE0AE14258D3045288D915F3FD346533D843D7CDB (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7*, const RuntimeMethod*))NativeArray_1_Dispose_mE0AE14258D3045288D915F3FD346533D843D7CDB_gshared)(__this, method);
}
inline void NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*, const RuntimeMethod*))NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_gshared)(__this, method);
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA float2_op_Subtraction_m28172675A65BCFFBC8C9023BE815019E668B8380_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_lhs, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_rhs, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool math_any_mCBBE4E2611B227A8AE1A4DA7F104D779203539F9_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA float2_op_Addition_m718974663A956F64D7C45D06C088550637F13693_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_lhs, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_rhs, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_length_m3DB47D254C8544FBB740A892B4AE2143E8F45634_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_x, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Refinery_FindSegment_m7BECA9AA1FA8B303B08B67BB3E35EEEDA8FC141B (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_pgPoints, int32_t ___1_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___2_pgEdges, int32_t ___3_pgEdgeCount, UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA ___4_es, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_abs_mFF027629978A9039B059528ED3075D775AA0B0AB_inline (int32_t ___0_x, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Refinery_InsertVertex_mD6E0D24EC6CAF9562984E486202245B3E8356BC2 (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___0_pgPoints, int32_t* ___1_pgPointCount, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_newVertex, int32_t* ___3_nid, const RuntimeMethod* method) ;
inline void NativeArray_1__ctor_mCFEB37C6F648F756D9AC2C044D2EE01AE66DBE34 (NativeArray_1_tB723C353A73B34FE57C3B9EA16A02A466B268BC2* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tB723C353A73B34FE57C3B9EA16A02A466B268BC2*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_mCFEB37C6F648F756D9AC2C044D2EE01AE66DBE34_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
inline void NativeArray_1__ctor_m89F748542AF7065DD1BC4780E9A0E4F3D41073ED (NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_m89F748542AF7065DD1BC4780E9A0E4F3D41073ED_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_BuildTriangles_m48C3ED6D6EEFF398B32541E7685F1332A0040BA6 (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_vertices, int32_t ___1_vertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___2_indices, int32_t ___3_indexCount, NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5* ___4_triangles, int32_t* ___5_triangleCount, float* ___6_maxArea, float* ___7_avgArea, float* ___8_minArea, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_clamp_mB7233FC9D6C27522014C4E6D4E056D36CE82C97E_inline (float ___0_x, float ___1_a, float ___2_b, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline (float ___0_x, float ___1_y, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Refinery_RequiresRefining_mE61A0BDBFE5757B48372A5AC578FEF6181C3A384 (UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD ___0_tri, float ___1_maxArea, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Refinery_FetchEncroachedSegments_m75A2A73743DC464AA0A2F5D4119480D0063A4FFA (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_pgPoints, int32_t ___1_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___2_pgEdges, int32_t ___3_pgEdgeCount, NativeArray_1_tB723C353A73B34FE57C3B9EA16A02A466B268BC2* ___4_encroach, int32_t* ___5_encroachCount, UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 ___6_c, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Refinery_SplitSegments_m1B90CC5AE3456482287E24ECFB79F54C7CC1FE6A (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___0_pgPoints, int32_t* ___1_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___2_pgEdges, int32_t* ___3_pgEdgeCount, UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA ___4_es, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_Tessellate_m84DB7B38E7EC9AB5155F7EEDBC3382CF1092EC5E (int32_t ___0_allocator, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___1_pgPoints, int32_t ___2_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___3_pgEdges, int32_t ___4_pgEdgeCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___5_outputVertices, int32_t* ___6_vertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___7_outputIndices, int32_t* ___8_indexCount, const RuntimeMethod* method) ;
inline void NativeArray_1_Dispose_mB48AC20750ECFD2702E0F9915B2177D044D15C58 (NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5*, const RuntimeMethod*))NativeArray_1_Dispose_mB48AC20750ECFD2702E0F9915B2177D044D15C58_gshared)(__this, method);
}
inline void NativeArray_1_Dispose_m2FC0457FE238F347CEF96BDA77BA875179E5704B (NativeArray_1_tB723C353A73B34FE57C3B9EA16A02A466B268BC2* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tB723C353A73B34FE57C3B9EA16A02A466B268BC2*, const RuntimeMethod*))NativeArray_1_Dispose_m2FC0457FE238F347CEF96BDA77BA875179E5704B_gshared)(__this, method);
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void int4__ctor_m4E8D71A09721E26F7FCCE82EA8AD699062EE6216_inline (int4_tBA77D4945786DE82C3A487B33955EA1004996052* __this, int32_t ___0_x, int32_t ___1_y, int32_t ___2_z, int32_t ___3_w, const RuntimeMethod* method) ;
inline void ModuleHandle_Copy_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mE623C4A9806A975DC543E10F18CD15CADCD6D02F (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 ___0_src, NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 ___1_dst, int32_t ___2_length, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200, NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200, int32_t, const RuntimeMethod*))ModuleHandle_Copy_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mE623C4A9806A975DC543E10F18CD15CADCD6D02F_gshared)(___0_src, ___1_dst, ___2_length, method);
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA float2_op_Division_m4AA175CD0895AA1A50F5A73B54722CA53876EE6A_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_lhs, float ___1_rhs, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_distance_mE5E0FFDD103E710A4CB23360BFCAFD0AF2E1EFA9_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_x, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_y, const RuntimeMethod* method) ;
inline void NativeArray_1__ctor_mC01F44D62CB455BB4FE045F1FFB6BBD3516CB265 (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_mC01F44D62CB455BB4FE045F1FFB6BBD3516CB265_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_BuildTrianglesAndEdges_m902E978EB29E4C37FCA0B80D66E30B677CADDD31 (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_vertices, int32_t ___1_vertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___2_indices, int32_t ___3_indexCount, NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5* ___4_triangles, int32_t* ___5_triangleCount, NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* ___6_delaEdges, int32_t* ___7_delaEdgeCount, float* ___8_maxArea, float* ___9_avgArea, float* ___10_minArea, const RuntimeMethod* method) ;
inline void* NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mB537AB040DF35BD6BE8FEBE48C04901884E592E3 (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 ___0_nativeArray, const RuntimeMethod* method)
{
	return ((  void* (*) (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200, const RuntimeMethod*))NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mB537AB040DF35BD6BE8FEBE48C04901884E592E3_gshared)(___0_nativeArray, method);
}
inline void ModuleHandle_InsertionSort_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_TisDelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B_m18BA196C639121F5500845FA59E90F34DB272028 (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, DelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B ___3_comp, const RuntimeMethod* method)
{
	((  void (*) (void*, int32_t, int32_t, DelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B, const RuntimeMethod*))ModuleHandle_InsertionSort_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_TisDelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B_m18BA196C639121F5500845FA59E90F34DB272028_gshared)(___0_array, ___1_lo, ___2_hi, ___3_comp, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Smoothen_RefineEdges_mEB354A7F15520AD45BE59B6C3322FC28698806DB (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* ___0_refinedEdges, NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* ___1_delaEdges, int32_t* ___2_delaEdgeCount, NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* ___3_voronoiEdges, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Smoothen_GetAffectingEdges_mB3CBA0BB5CDA1557F68AC90C66236BA22FA02091 (int32_t ___0_pointIndex, NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 ___1_edges, int32_t ___2_edgeCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___3_resultSet, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___4_checkSet, int32_t* ___5_resultCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Smoothen_ConnectTriangles_m727034BB01BA926D7D5DBC1AAD81342CB5D8B26F (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* ___0_connectedTri, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___1_affectEdges, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___2_checkSet, NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 ___3_voronoiEdges, int32_t ___4_triangleCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Smoothen_CentroidByPolygon_m6111FE65A4B6D4F26D6C2920E2575094C8157533 (int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___0_e, NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5 ___1_triangles, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* ___2_centroid, float* ___3_area, float* ___4_distance, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_BuildTriangles_m2C767A1D0CBE89D726305D210EB2416DE1DA98CD (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_vertices, int32_t ___1_vertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___2_indices, int32_t ___3_indexCount, NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5* ___4_triangles, int32_t* ___5_triangleCount, float* ___6_maxArea, float* ___7_avgArea, float* ___8_minArea, float* ___9_maxEdge, float* ___10_avgEdge, float* ___11_minEdge, const RuntimeMethod* method) ;
inline void NativeArray_1_Dispose_m38861384F84F1CD89A47D663C29D3ED425C5CCE0 (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200*, const RuntimeMethod*))NativeArray_1_Dispose_m38861384F84F1CD89A47D663C29D3ED425C5CCE0_gshared)(__this, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float ModuleHandle_OrientFast_m39D34C2844061E3607200824ADE00A8CA5680634 (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_a, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_b, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_c, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Tessellator_SetAllocator_mC4F00FD3CD85AA582F89050F805A50236365B47A_inline (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_allocator, const RuntimeMethod* method) ;
inline int32_t ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3_m0A70D6C3B3B43D49B43B90E25921F0935E4F0853 (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_values, int32_t ___1_count, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_check, TestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3 ___3_condition, const RuntimeMethod* method)
{
	return ((  int32_t (*) (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89, int32_t, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, TestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3, const RuntimeMethod*))ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3_m0A70D6C3B3B43D49B43B90E25921F0935E4F0853_gshared)(___0_values, ___1_count, ___2_check, ___3_condition, method);
}
inline int32_t ModuleHandle_GetUpper_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436_mFF87B6D1AF19335BBFCBFC9A88B90165B26C3987 (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_values, int32_t ___1_count, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_check, TestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436 ___3_condition, const RuntimeMethod* method)
{
	return ((  int32_t (*) (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89, int32_t, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, TestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436, const RuntimeMethod*))ModuleHandle_GetUpper_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436_mFF87B6D1AF19335BBFCBFC9A88B90165B26C3987_gshared)(___0_values, ___1_count, ___2_check, ___3_condition, method);
}
inline int32_t ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252 (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* __this, int32_t ___0_index, const RuntimeMethod* method)
{
	return ((  int32_t (*) (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*, int32_t, const RuntimeMethod*))ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_gshared)(__this, ___0_index, method);
}
inline int32_t ArraySlice_1_get_Length_m814A8881AF759049A308E6E04BE0451BFDA0076B_inline (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*, const RuntimeMethod*))ArraySlice_1_get_Length_m814A8881AF759049A308E6E04BE0451BFDA0076B_gshared_inline)(__this, method);
}
inline void ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55 (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* __this, int32_t ___0_index, int32_t ___1_value, const RuntimeMethod* method)
{
	((  void (*) (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*, int32_t, int32_t, const RuntimeMethod*))ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_gshared)(__this, ___0_index, ___1_value, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_AddPoint_m182743F67F59E43CBD839CFDC1D0ADFE3F3B8299 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_hulls, int32_t ___1_hullCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___2_points, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___3_p, int32_t ___4_idx, const RuntimeMethod* method) ;
inline int32_t ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D_mDDE7DE6D079B34BF84F234F97CEF203430E49608 (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_values, int32_t ___1_count, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___2_check, TestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D ___3_condition, const RuntimeMethod* method)
{
	return ((  int32_t (*) (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89, int32_t, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, TestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D, const RuntimeMethod*))ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D_mDDE7DE6D079B34BF84F234F97CEF203430E49608_gshared)(___0_values, ___1_count, ___2_check, ___3_condition, method);
}
inline void ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402 (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* __this, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___0_array, int32_t ___1_start, int32_t ___2_length, const RuntimeMethod* method)
{
	((  void (*) (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C, int32_t, int32_t, const RuntimeMethod*))ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402_gshared)(__this, ___0_array, ___1_start, ___2_length, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_InsertHull_m78B0282356E02B23DA875D91E50D28691EE84442 (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_Hulls, int32_t ___1_Pos, int32_t* ___2_Count, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___3_Value, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_SplitHulls_m0E1DD4AC9AA526B11A5FF0729A50A17299A16A81 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_hulls, int32_t* ___1_hullCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___2_points, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___3_evt, const RuntimeMethod* method) ;
inline int32_t ModuleHandle_GetEqual_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155_m27B4DE791ADEB1742E19D6628CA333842FC8FC54 (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_values, int32_t ___1_count, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___2_check, TestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155 ___3_condition, const RuntimeMethod* method)
{
	return ((  int32_t (*) (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89, int32_t, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, TestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155, const RuntimeMethod*))ModuleHandle_GetEqual_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155_m27B4DE791ADEB1742E19D6628CA333842FC8FC54_gshared)(___0_values, ___1_count, ___2_check, ___3_condition, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_EraseHull_m99C74029D962F1EAB6D75DDBF856638D72B7BA03 (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_Hulls, int32_t ___1_Pos, int32_t* ___2_Count, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_MergeHulls_m9C43D5FB7E8BFA626169A2548C85E3FCF903751C (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_hulls, int32_t* ___1_hullCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___2_points, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___3_evt, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TessEdgeCompare_Compare_m29540C70B61ECC31030C7D3F52E8F3B534BEC37D (TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434* __this, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___0_a, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_b, const RuntimeMethod* method) ;
inline void NativeArray_1__ctor_m9D79AD54D34744D093257128146409873295E2DB (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_m9D79AD54D34744D093257128146409873295E2DB_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_InsertUniqueEdge_m143D5A36C4A932DAB167592C3634691BBDA38220 (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_edges, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_e, int32_t* ___2_edgeCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_PrepareDelaunay_mC18519EEF84FC79C0C98F273D1AF0FCBE4CFDC1D (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_edges, int32_t ___1_edgeCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Tessellator_OppositeOf_mB6E82B82152D79C874C4BEB6962348B5E408BCEE (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_a, int32_t ___1_b, const RuntimeMethod* method) ;
inline int32_t ModuleHandle_GetEqual_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375_m00A96EB8B356CCA03D3D724C514C6175681907A8 (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_values, int32_t ___1_count, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___2_check, TestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375 ___3_condition, const RuntimeMethod* method)
{
	return ((  int32_t (*) (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2, int32_t, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, TestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375, const RuntimeMethod*))ModuleHandle_GetEqual_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375_m00A96EB8B356CCA03D3D724C514C6175681907A8_gshared)(___0_values, ___1_count, ___2_check, ___3_condition, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Tessellator_FindConstraint_m20B8DD4CC9007571111316603CFBA28FAE0E1A4A (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_a, int32_t ___1_b, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_AddTriangle_m056EC10F57F04B372B226616D055F3D238E2A489 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_i, int32_t ___1_j, int32_t ___2_k, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_RemovePair_m510EF9D6AAC6C238EBC67C16661117381C7813B4 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_r, int32_t ___1_j, int32_t ___2_k, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_RemoveTriangle_m4B9D2A007809D00EE7610B870F6A1F74EFD21B00 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_i, int32_t ___1_j, int32_t ___2_k, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_EdgeFlip_mC4C0DD9C08C3DB477698E335DCDEC76D0AEEE81A (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_i, int32_t ___1_j, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ModuleHandle_IsInsideCircle_m7A080360A299D2F6BAF0390791DD36650D30AC2D (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_a, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_b, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_c, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___3_p, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_Flip_mBB5A8641BF0DB8D959F4ECC34DA80B9CAAC3229F (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_points, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___1_stack, int32_t* ___2_stackCount, int32_t ___3_a, int32_t ___4_b, int32_t ___5_x, const RuntimeMethod* method) ;
inline void NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 Tessellator_GetCells_m737CD6BFBF6CDE13F2C88C9B1E0331051E9D6212 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t* ___0_count, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_ApplyDelaunay_m97F59A65E5BAA3573864BC238165FDB8D14A0AD0 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_points, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___1_edges, const RuntimeMethod* method) ;
inline int32_t ModuleHandle_GetEqual_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1_mA2DC9A659A83000A07E39BAAFFA6588DF23C361A (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 ___0_values, int32_t ___1_count, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___2_check, TestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1 ___3_condition, const RuntimeMethod* method)
{
	return ((  int32_t (*) (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57, int32_t, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, TestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1, const RuntimeMethod*))ModuleHandle_GetEqual_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1_mA2DC9A659A83000A07E39BAAFFA6588DF23C361A_gshared)(___0_values, ___1_count, ___2_check, ___3_condition, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Tessellator_FindNeighbor_m3B762808E6088E8981D42BA431435A4B6EDC188F (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 ___0_cells, int32_t ___1_count, int32_t ___2_a, int32_t ___3_b, int32_t ___4_c, const RuntimeMethod* method) ;
inline void* NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_m9322523E8F4F331EE08D7DE23A5F5E48B851AF00 (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 ___0_nativeArray, const RuntimeMethod* method)
{
	return ((  void* (*) (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57, const RuntimeMethod*))NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_m9322523E8F4F331EE08D7DE23A5F5E48B851AF00_gshared)(___0_nativeArray, method);
}
inline void ModuleHandle_InsertionSort_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE_mB73DA078075FCD273BA172C5E5D6EEDDBFA8279D (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE ___3_comp, const RuntimeMethod* method)
{
	((  void (*) (void*, int32_t, int32_t, TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE, const RuntimeMethod*))ModuleHandle_InsertionSort_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE_mB73DA078075FCD273BA172C5E5D6EEDDBFA8279D_gshared)(___0_array, ___1_lo, ___2_hi, ___3_comp, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 Tessellator_Constrain_m8215808ACAA44BFA3312A4F1F46ADE90D040DE2F (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t* ___0_count, const RuntimeMethod* method) ;
inline void NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213 (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57*, const RuntimeMethod*))NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213_gshared)(__this, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 Tessellator_RemoveExterior_m9D5D1813823280A5BDBAF36CFBE713280079011F (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t* ___0_cellCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 Tessellator_RemoveInterior_m9D9D80F21881D933B53DF8CC4FEA4B6E4C7B45A8 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_cellCount, const RuntimeMethod* method) ;
inline void NativeArray_1__ctor_mEB7F36BB585F82EDD8F8C88166579082DFA402BF (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_mEB7F36BB585F82EDD8F8C88166579082DFA402BF_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
inline void NativeArray_1__ctor_m56963AF6292CEE1271AFDE037CEFD1B70C5050D4 (NativeArray_1_t97EAB41C5774F97823C769B51FBCAC8DE508B75D* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_t97EAB41C5774F97823C769B51FBCAC8DE508B75D*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_m56963AF6292CEE1271AFDE037CEFD1B70C5050D4_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
inline void* NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_mD7FAFF405DB2912073D4F221E3403DEF24972B52 (NativeArray_1_t97EAB41C5774F97823C769B51FBCAC8DE508B75D ___0_nativeArray, const RuntimeMethod* method)
{
	return ((  void* (*) (NativeArray_1_t97EAB41C5774F97823C769B51FBCAC8DE508B75D, const RuntimeMethod*))NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_mD7FAFF405DB2912073D4F221E3403DEF24972B52_gshared)(___0_nativeArray, method);
}
inline void ModuleHandle_InsertionSort_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F_m1706B12E442DF1715DFA736CA4077E4896F0F251 (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, TessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F ___3_comp, const RuntimeMethod* method)
{
	((  void (*) (void*, int32_t, int32_t, TessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F, const RuntimeMethod*))ModuleHandle_InsertionSort_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F_m1706B12E442DF1715DFA736CA4077E4896F0F251_gshared)(___0_array, ___1_lo, ___2_hi, ___3_comp, method);
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_abs_m3D9508B36B045BFE7B89C6C69AD34596264E4FE1_inline (float ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_pow_m2B2C611A37952CFB13BB0AE800A6A601A2E4A49B_inline (float ___0_x, float ___1_y, const RuntimeMethod* method) ;
inline void NativeArray_1_Dispose_m44CBE8EDE8CD7B71350BF815EE8BB232511E7D79 (NativeArray_1_t97EAB41C5774F97823C769B51FBCAC8DE508B75D* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_t97EAB41C5774F97823C769B51FBCAC8DE508B75D*, const RuntimeMethod*))NativeArray_1_Dispose_m44CBE8EDE8CD7B71350BF815EE8BB232511E7D79_gshared)(__this, method);
}
inline void NativeArray_1_Dispose_m9D682D26EB442C42FBAB528F6F5F90AE5C216E8C (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89*, const RuntimeMethod*))NativeArray_1_Dispose_m9D682D26EB442C42FBAB528F6F5F90AE5C216E8C_gshared)(__this, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_Triangulate_m285C63134AA7BD188AA87A6E3734923DDD4C8FF5 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_points, int32_t ___1_pointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___2_edges, int32_t ___3_edgeCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_Cleanup_m3B1B149B79AC4098E89B70A7AC57CA8D41309293 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, const RuntimeMethod* method) ;
inline bool NativeArray_1_get_IsCreated_m5BE85069615B49772C9DB202004FA2FD36F418F2_inline (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* __this, const RuntimeMethod* method)
{
	return ((  bool (*) (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*, const RuntimeMethod*))NativeArray_1_get_IsCreated_m5BE85069615B49772C9DB202004FA2FD36F418F2_gshared_inline)(__this, method);
}
inline bool NativeArray_1_get_IsCreated_mB43459BFDEF78038051D817E8A57FF1DF3C3D738_inline (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* __this, const RuntimeMethod* method)
{
	return ((  bool (*) (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*, const RuntimeMethod*))NativeArray_1_get_IsCreated_mB43459BFDEF78038051D817E8A57FF1DF3C3D738_gshared_inline)(__this, method);
}
inline void NativeArray_1_Dispose_m1ACF94B84372AD81EEE7228152F8E1770B09180B (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*, const RuntimeMethod*))NativeArray_1_Dispose_m1ACF94B84372AD81EEE7228152F8E1770B09180B_gshared)(__this, method);
}
inline bool NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_inline (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* __this, const RuntimeMethod* method)
{
	return ((  bool (*) (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*, const RuntimeMethod*))NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_gshared_inline)(__this, method);
}
inline bool NativeArray_1_get_IsCreated_m448EBF5E1AF8055E179079DE8883B7F449125BAB_inline (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* __this, const RuntimeMethod* method)
{
	return ((  bool (*) (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57*, const RuntimeMethod*))NativeArray_1_get_IsCreated_m448EBF5E1AF8055E179079DE8883B7F449125BAB_gshared_inline)(__this, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TestHullPointL_Test_m13DD2824D7E78DA3A4EF948C678CD51A88F5A716 (TestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3* __this, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_h, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_p, float* ___2_t, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TestHullPointU_Test_m2BBE9B65EB95E4ABA928A86A055086CED902517B (TestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436* __this, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_h, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_p, float* ___2_t, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Tessellator_FindSplit_mFEA20FADFD2F4401DA02191FE3C6F4462F37B9B5 (UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_hull, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___1_edge, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TestHullEventLe_Test_m93D489EB67F59C91419FF51EE01931CB1BB0A529 (TestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D* __this, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_h, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___1_p, float* ___2_t, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TestHullEventE_Test_mB58E3071967F89B4EA751EEBD5FE56EAD6B40F85 (TestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155* __this, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_h, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___1_p, float* ___2_t, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TestEdgePointE_Test_mE27BE906A78058D6E43C2EBC14C95B164554AC5E (TestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375* __this, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___0_h, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_p, float* ___2_t, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TessCellCompare_Compare_m1CA8ED338230EF907349884C7B60CCE3559BA57A (TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE* __this, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___0_a, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___1_b, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TestCellE_Test_mF4632944A15C6F5DEEB3A19A5DC35FF16FB31C2D (TestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1* __this, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___0_h, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___1_p, float* ___2_t, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t XCompare_Compare_m07A9D6C40F60E0E5AEBAEC1E27A8C95F2E7017A3 (XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B* __this, double ___0_a, double ___1_b, const RuntimeMethod* method) ;
inline void ModuleHandle_InsertionSort_TisDouble_tE150EF3D1D43DEE85D533810AB4C742307EEDE5F_TisXCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B_mD9DFBCA0EC70F5BF558FBC5C79E929BB2316EFB7 (void* ___0_array, int32_t ___1_lo, int32_t ___2_hi, XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B ___3_comp, const RuntimeMethod* method)
{
	((  void (*) (void*, int32_t, int32_t, XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B, const RuntimeMethod*))ModuleHandle_InsertionSort_TisDouble_tE150EF3D1D43DEE85D533810AB4C742307EEDE5F_TisXCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B_mD9DFBCA0EC70F5BF558FBC5C79E929BB2316EFB7_gshared)(___0_array, ___1_lo, ___2_hi, ___3_comp, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t IntersectionCompare_Compare_mCE1F00DE6559846CB71839148F1BAF54DB6260EF (IntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489* __this, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___0_a, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_b, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TessEventCompare_Compare_mFBC498906F6BF3279BB6843DC8C7D12B9D4522C1 (TessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F* __this, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___0_a, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___1_b, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TessJunctionCompare_Compare_m212C2AE3DCBD9AB1C8FA5E503811F8E573E6285A (TessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249* __this, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___0_a, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_b, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t DelaEdgeCompare_Compare_m9D63142C6EBC894B7DAD24EBE3A38FDD5678BEF2 (DelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B* __this, int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___0_a, int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___1_b, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_sqrt_mEF31DE7BD0179009683C5D7B0C58E6571B30CF4A_inline (float ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float3__ctor_mC61002CD0EC13D7C37D846D021A78C028FB80DB9_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E* __this, float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E float3_op_Subtraction_mB6036E9849D95650D6E73DA0D179CD7B61E696F2_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_lhs, float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___1_rhs, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E math_cross_m4CA2DAE150C6381B0D05E8AA9E48E88CF6157180_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_x, float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___1_y, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float ModuleHandle_Sign_mAD4C03A02763F90C0B6BB07F6A9A11DC00B59294 (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_p1, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_p2, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_p3, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float ModuleHandle_TriangleArea_m40B327CC9176416944F14D245D0F49DD5CB2CEA0 (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_va, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_vb, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_vc, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_dot_mF673D3E5B7D267C0A8569B678D05BDCCB667D04D_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_x, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_y, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 ModuleHandle_CircumCircle_m55302C4846463A91AB57830760699DC95BF4AC0B (UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD ___0_tri, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline (float ___0_x, float ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void int3__ctor_mE478318DE4CA648614FEF2C1DD438C0455284BF2_inline (int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF* __this, int32_t ___0_x, int32_t ___1_y, int32_t ___2_z, const RuntimeMethod* method) ;
inline void ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_src, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___1_dst, int32_t ___2_length, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E, int32_t, const RuntimeMethod*))ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F_gshared)(___0_src, ___1_dst, ___2_length, method);
}
inline void ModuleHandle_Copy_TisInt32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_m08EAF9EE4BD7B3611121EEBB1CA1AC40D9C29874 (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___0_src, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___1_dst, int32_t ___2_length, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C, int32_t, const RuntimeMethod*))ModuleHandle_Copy_TisInt32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_m08EAF9EE4BD7B3611121EEBB1CA1AC40D9C29874_gshared)(___0_src, ___1_dst, ___2_length, method);
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA math_min_m68ED612C41E325FA3446050EA04D0AC0CD191558_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_x, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA math_max_mFD64D6399932C2D91018BA7895C06FD055E1361B_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_x, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_y, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_Reorder_mC37CEAA08AE5E9B432106F95C633908AE0ABD600 (int32_t ___0_startVertexCount, int32_t ___1_index, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___2_indices, int32_t* ___3_indexCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___4_vertices, int32_t* ___5_vertexCount, const RuntimeMethod* method) ;
inline void NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* __this, int32_t ___0_length, int32_t ___1_allocator, int32_t ___2_options, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*, int32_t, int32_t, int32_t, const RuntimeMethod*))NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_gshared)(__this, ___0_length, ___1_allocator, ___2_options, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_GraphConditioner_m7C685F797F7096123ABD62F4932FFC0177FDE3CF (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_points, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___1_pgPoints, int32_t* ___2_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___3_pgEdges, int32_t* ___4_pgEdgeCount, bool ___5_resetTopology, const RuntimeMethod* method) ;
inline void NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* __this, const RuntimeMethod* method)
{
	((  void (*) (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*, const RuntimeMethod*))NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_gshared)(__this, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_Validate_mD6F5B2173F4C2C298986E926D9C372B88B0ED39D (int32_t ___0_allocator, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___1_inputPoints, int32_t ___2_pointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___3_inputEdges, int32_t ___4_edgeCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___5_outputPoints, int32_t* ___6_outputPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___7_outputEdges, int32_t* ___8_outputEdgeCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_TransferOutput_mE69BFB90D12C2CA71E368EC00347F5C1DA21BDAD (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_srcEdges, int32_t ___1_srcEdgeCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___2_dstEdges, int32_t* ___3_dstEdgeCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___4_srcIndices, int32_t ___5_srcIndexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___6_dstIndices, int32_t* ___7_dstIndexCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___8_srcVertices, int32_t ___9_srcVertexCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___10_dstVertices, int32_t* ___11_dstVertexCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Math_Min_m53C488772A34D53917BCA2A491E79A0A5356ED52 (int32_t ___0_val1, int32_t ___1_val2, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_CopyGraph_mD198F917465F876C1D09639EED8A2C2600ADF7EB (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_srcPoints, int32_t ___1_srcPointCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___2_dstPoints, int32_t* ___3_dstPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___4_srcEdges, int32_t ___5_srcEdgeCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___6_dstEdges, int32_t* ___7_dstEdgeCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_CopyGeometry_m41B14E71387642F5CDDA4F2C8C2C173FA9FF5E3C (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___0_srcIndices, int32_t ___1_srcIndexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___2_dstIndices, int32_t* ___3_dstIndexCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___4_srcVertices, int32_t ___5_srcVertexCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___6_dstVertices, int32_t* ___7_dstVertexCount, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Refinery_Condition_m75ECBF8D82871AEB1D046E61F20DD3700E18D214 (int32_t ___0_allocator, float ___1_factorArea, float ___2_targetArea, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___3_pgPoints, int32_t* ___4_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___5_pgEdges, int32_t* ___6_pgEdgeCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___7_vertices, int32_t* ___8_vertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___9_indices, int32_t* ___10_indexCount, float* ___11_maxArea, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_lerp_m58A82DB48BBA11871FFA81583C700875B3A9BC84_inline (float ___0_x, float ___1_y, float ___2_s, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_VertexCleanupConditioner_m53303FF76EFACCC24EB5C389780B9533FBD50D5A (int32_t ___0_startVertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___1_indices, int32_t* ___2_indexCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___3_vertices, int32_t* ___4_vertexCount, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_clamp_m9EABD008C8EAD9D150062ABE724D96FA2121EE1C_inline (int32_t ___0_x, int32_t ___1_a, int32_t ___2_b, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Smoothen_Condition_m831A479BB846A668D896E06A2737129629F3DFC2 (int32_t ___0_allocator, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___1_pgPoints, int32_t ___2_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___3_pgEdges, int32_t ___4_pgEdgeCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___5_vertices, int32_t* ___6_vertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___7_indices, int32_t* ___8_indexCount, const RuntimeMethod* method) ;
inline void IJobExtensions_EarlyJobInit_TisDrawCallJob_t3EA2ABC822AD5DF50675A5B437DAB927DB95215D_m8175192716D38C9C006D2C98D5B36A7CC75E33AD (const RuntimeMethod* method)
{
	((  void (*) (const RuntimeMethod*))IJobExtensions_EarlyJobInit_TisDrawCallJob_t3EA2ABC822AD5DF50675A5B437DAB927DB95215D_m8175192716D38C9C006D2C98D5B36A7CC75E33AD_gshared)(method);
}
inline void IJobParallelForTransformExtensions_EarlyJobInit_TisUpdateTransformsJob_t7CF957169E8C6560084F48A51BC15A447F3002C7_mA2F79749E27788E6B6B0DA93086B08A0C553480E (const RuntimeMethod* method)
{
	((  void (*) (const RuntimeMethod*))IJobParallelForTransformExtensions_EarlyJobInit_TisUpdateTransformsJob_t7CF957169E8C6560084F48A51BC15A447F3002C7_mA2F79749E27788E6B6B0DA93086B08A0C553480E_gshared)(method);
}
inline void IJobForExtensions_EarlyJobInit_TisLightMinMaxZJob_tB4FE0854445DAADF46E5511EAAF54EA1E4B611C4_m6D407EF2FD72EE5C26BA1C843C9932ABCB9C16DA (const RuntimeMethod* method)
{
	((  void (*) (const RuntimeMethod*))IJobForExtensions_EarlyJobInit_TisLightMinMaxZJob_tB4FE0854445DAADF46E5511EAAF54EA1E4B611C4_m6D407EF2FD72EE5C26BA1C843C9932ABCB9C16DA_gshared)(method);
}
inline void IJobForExtensions_EarlyJobInit_TisReflectionProbeMinMaxZJob_tB55272F39D5B8B189F5DF7212CDA3FFF1EC0C71C_mE2595D2099394DF551AC793D9874D90167904DF2 (const RuntimeMethod* method)
{
	((  void (*) (const RuntimeMethod*))IJobForExtensions_EarlyJobInit_TisReflectionProbeMinMaxZJob_tB55272F39D5B8B189F5DF7212CDA3FFF1EC0C71C_mE2595D2099394DF551AC793D9874D90167904DF2_gshared)(method);
}
inline void IJobForExtensions_EarlyJobInit_TisTileRangeExpansionJob_t8342AD91DCB87CA5DBDB463981EE24D47408C876_m7F3455814736950B257AF91E4AE26136F7D2D588 (const RuntimeMethod* method)
{
	((  void (*) (const RuntimeMethod*))IJobForExtensions_EarlyJobInit_TisTileRangeExpansionJob_t8342AD91DCB87CA5DBDB463981EE24D47408C876_m7F3455814736950B257AF91E4AE26136F7D2D588_gshared)(method);
}
inline void IJobForExtensions_EarlyJobInit_TisTilingJob_t4506E6F62C95A90210A474DE43C83AF5EB8D3352_m4C05E9D5B6CBBFDCFF690B0C60C83CC47D299593 (const RuntimeMethod* method)
{
	((  void (*) (const RuntimeMethod*))IJobForExtensions_EarlyJobInit_TisTilingJob_t4506E6F62C95A90210A474DE43C83AF5EB8D3352_m4C05E9D5B6CBBFDCFF690B0C60C83CC47D299593_gshared)(method);
}
inline void IJobForExtensions_EarlyJobInit_TisZBinningJob_t9BC217C31924E66E667568C1B51EA2F44FA0A08E_mA5B015BCBE9BD211FDEFDAE5347DCBE7E91D1970 (const RuntimeMethod* method)
{
	((  void (*) (const RuntimeMethod*))IJobForExtensions_EarlyJobInit_TisZBinningJob_t9BC217C31924E66E667568C1B51EA2F44FA0A08E_mA5B015BCBE9BD211FDEFDAE5347DCBE7E91D1970_gshared)(method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void EarlyInitHelpers_JobReflectionDataCreationFailed_mD6AB08D5BB411CCE38A87793C3C7062EC91FD1EC (Exception_t* ___0_ex, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void __JobReflectionRegistrationOutput__1843744399_CreateJobReflectionData_mB127811C289BF66B9FCFCBA4D17814336677687A (const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint64_t math_asulong_m2CF160E23B5FF618A85C3C29B2FB1C000E40290F_inline (double ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_asdouble_m3E7BC790C743E67EA45476AECD6D2D9A9E62E4F2_inline (uint64_t ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA double2_op_Subtraction_mDAD1E402F52C548544D20D62D7FA098F4F858BC8_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_lhs, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_rhs, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_length_mBC9788A14DDEC3FA5794F7F49EDD1516C5EDE4E3_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_min_m29A6A5FB36524D911D13DDB4866FF005C7BF00D5_inline (double ___0_x, double ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void double2__ctor_m4026FE95F69FAEBD29D7092ADAA1CB845A8E859B_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA* __this, double ___0_x, double ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void double2__ctor_m3355A4008574AE2483EAD2841176C67734F10F33_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA* __this, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_v, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Single_IsNaN_mFE637F6ECA9F7697CE8EFF56427858F4C5EDF75D_inline (float ___0_f, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_asuint_m503D1ABF19E4BA615FD8AE1BF1A2E103BBED6139_inline (float ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_asfloat_m20D259DAAB46464B59BD8BF5678F9D59800F70A9_inline (uint32_t ___0_x, const RuntimeMethod* method) ;
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR double Math_Pow_mEAE651F0858203FBE12B72B6A53951BBD0FB5265 (double ___0_x, double ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E float3_get_yzx_mDF6DE39B69C5DE384F74C0D1EC91AA0388E23535_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E* __this, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E float3_op_Multiply_m05E57074FBD5FAB0E72940C9CC019C41915280D7_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_lhs, float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___1_rhs, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int64_t math_aslong_mCD3846AC0EFB4901B00A20D0960C80C8CBE66366_inline (double ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_asdouble_m4C4CC1B9299FE33530ED375768D67B00676C31C8_inline (int64_t ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_dot_mA992F4ADC67180A7EB3850222857193CD0F6B21E_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_x, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_y, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_sqrt_mA3A9D5DFDF6841F8836E3ECD5D83555842383F36_inline (double ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Double_IsNaN_mF2BC6D1FD4813179B2CAE58D29770E42830D0883_inline (double ___0_d, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t BitConverter_SingleToInt32Bits_mC760C7CFC89725E3CF68DC45BE3A9A42A7E7DA73_inline (float ___0_value, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_asint_mBDED7FE966CA65F6A8ACEAEF8FD779B1B8998288_inline (float ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_asfloat_m9FA56DE5C61FCEF3DCD0675252D40DFD9C9B712F_inline (int32_t ___0_x, const RuntimeMethod* method) ;
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int64_t BitConverter_DoubleToInt64Bits_m4F42741818550F9956B5FBAF88C051F4DE5B0AE6_inline (double ___0_value, const RuntimeMethod* method) ;
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PassData__ctor_m8A566CD8229EC1D10D7A229EC89195F68F862CE9 (PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__cctor_m0C5537439A9A39074863DDB68E4394401731B16A (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264* L_0 = (U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264*)il2cpp_codegen_object_new(U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264_il2cpp_TypeInfo_var);
		U3CU3Ec__ctor_m058892C1C716FD6680DFAFD5ED2A8BFAD692237C(L_0, NULL);
		((U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264_il2cpp_TypeInfo_var))->___U3CU3E9 = L_0;
		Il2CppCodeGenWriteBarrier((void**)(&((U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264_StaticFields*)il2cpp_codegen_static_fields_for(U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264_il2cpp_TypeInfo_var))->___U3CU3E9), (void*)L_0);
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec__ctor_m058892C1C716FD6680DFAFD5ED2A8BFAD692237C (U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264* __this, const RuntimeMethod* method) 
{
	{
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec_U3CRenderU3Eb__27_0_m691ADDC9F3B5E9282A5C3A569C6BD951C66066EC (U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264* __this, PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* ___0_data, RenderGraphContext_t230588A81E5222F21FB773FD8D1DB979190E0A08* ___1_context, const RuntimeMethod* method) 
{
	{
		PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* L_0 = ___0_data;
		NullCheck(L_0);
		bool L_1 = L_0->___emptyShadowmap;
		if (L_1)
		{
			goto IL_001f;
		}
	}
	{
		PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* L_2 = ___0_data;
		NullCheck(L_2);
		MainLightShadowCasterPass_tC550260377ED69F98337CF963695B7A090B137E3* L_3 = L_2->___pass;
		RenderGraphContext_t230588A81E5222F21FB773FD8D1DB979190E0A08* L_4 = ___1_context;
		NullCheck(L_4);
		ScriptableRenderContext_t5AB09B3602BEB456E0DC3D53926D3A3BDAF08E36* L_5 = (ScriptableRenderContext_t5AB09B3602BEB456E0DC3D53926D3A3BDAF08E36*)(&L_4->___renderContext);
		PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* L_6 = ___0_data;
		NullCheck(L_6);
		RenderingData_tAAA01190551D6D5954314E3E1E85B58DD45EED71* L_7 = (RenderingData_tAAA01190551D6D5954314E3E1E85B58DD45EED71*)(&L_6->___renderingData);
		NullCheck(L_3);
		MainLightShadowCasterPass_RenderMainLightCascadeShadowmap_mF64DA095A00063B7429659FC71431C7F79B896C4(L_3, L_5, L_7, NULL);
	}

IL_001f:
	{
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void U3CU3Ec_U3CRenderU3Eb__27_1_m11A283407A468737C1E3E4E586C09D1B345B86BA (U3CU3Ec_tC651251045AF6738E88E0DC843CE52D8B72A3264* __this, PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* ___0_data, RenderGraphContext_t230588A81E5222F21FB773FD8D1DB979190E0A08* ___1_context, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* L_0 = ___0_data;
		NullCheck(L_0);
		bool L_1 = L_0->___emptyShadowmap;
		if (!L_1)
		{
			goto IL_0035;
		}
	}
	{
		PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* L_2 = ___0_data;
		NullCheck(L_2);
		MainLightShadowCasterPass_tC550260377ED69F98337CF963695B7A090B137E3* L_3 = L_2->___pass;
		RenderGraphContext_t230588A81E5222F21FB773FD8D1DB979190E0A08* L_4 = ___1_context;
		NullCheck(L_4);
		ScriptableRenderContext_t5AB09B3602BEB456E0DC3D53926D3A3BDAF08E36* L_5 = (ScriptableRenderContext_t5AB09B3602BEB456E0DC3D53926D3A3BDAF08E36*)(&L_4->___renderContext);
		PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* L_6 = ___0_data;
		NullCheck(L_6);
		RenderingData_tAAA01190551D6D5954314E3E1E85B58DD45EED71* L_7 = (RenderingData_tAAA01190551D6D5954314E3E1E85B58DD45EED71*)(&L_6->___renderingData);
		NullCheck(L_3);
		MainLightShadowCasterPass_SetEmptyMainLightCascadeShadowmap_m1CC8D3E22696FC7CED71EBD3A99E6880EE458B5A(L_3, L_5, L_7, NULL);
		PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* L_8 = ___0_data;
		PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* L_9 = ___0_data;
		NullCheck(L_9);
		RenderGraph_t5AA201AC80DFD885B4FFB147432366185AE489BB* L_10 = L_9->___graph;
		NullCheck(L_10);
		RenderGraphDefaultResources_t9911A2DC8A2C28E3A1F7F2D48B03AFBCEF1F499B* L_11;
		L_11 = RenderGraph_get_defaultResources_mAF14CF66D8EEB8E7BE53241437E9D7005C662E17_inline(L_10, NULL);
		NullCheck(L_11);
		TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 L_12;
		L_12 = RenderGraphDefaultResources_get_defaultShadowTexture_m4EA8FB8D0893BC33315B9FE9339E1C37DE050F50_inline(L_11, NULL);
		NullCheck(L_8);
		L_8->___shadowmapTexture = L_12;
	}

IL_0035:
	{
		PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* L_13 = ___0_data;
		NullCheck(L_13);
		RenderingData_tAAA01190551D6D5954314E3E1E85B58DD45EED71* L_14 = (RenderingData_tAAA01190551D6D5954314E3E1E85B58DD45EED71*)(&L_13->___renderingData);
		CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* L_15 = L_14->___commandBuffer;
		PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* L_16 = ___0_data;
		NullCheck(L_16);
		int32_t L_17 = L_16->___shadowmapID;
		PassData_t4EBCD157121F31BADC982DAC39A13767A7E5207A* L_18 = ___0_data;
		NullCheck(L_18);
		TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 L_19 = L_18->___shadowmapTexture;
		il2cpp_codegen_runtime_class_init_inline(TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09_il2cpp_TypeInfo_var);
		RenderTargetIdentifier_tA528663AC6EB3911D8E91AA40F7070FA5455442B L_20;
		L_20 = TextureHandle_op_Implicit_m7D0B532B3A4CE3E92E1FC08A743BED70AC767A55(L_19, NULL);
		NullCheck(L_15);
		CommandBuffer_SetGlobalTexture_m65E012CB3C35EA43533CB4FF4C6F6498FDE229CD(L_15, L_17, L_20, NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* RenderTargetBufferSystem_get_backBuffer_mF7305DBD196865D17A0029AC212E8CC02D8205A2 (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		il2cpp_codegen_runtime_class_init_inline(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		bool L_0 = ((RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields*)il2cpp_codegen_static_fields_for(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var))->___m_AisBackBuffer;
		if (L_0)
		{
			goto IL_000e;
		}
	}
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_1 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		return L_1;
	}

IL_000e:
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_2 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		return L_2;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* RenderTargetBufferSystem_get_frontBuffer_mDD8E09139E41F59A682216AD6C0A94AE4387E11A (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		il2cpp_codegen_runtime_class_init_inline(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		bool L_0 = ((RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields*)il2cpp_codegen_static_fields_for(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var))->___m_AisBackBuffer;
		if (L_0)
		{
			goto IL_000e;
		}
	}
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_1 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		return L_1;
	}

IL_000e:
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_2 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		return L_2;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RenderTargetBufferSystem__ctor_m86BE218D4CA2ED16CC91EEAE8A08BE67A5E860BE (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, String_t* ___0_name, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralAB69FA1AB6BB831506EFCAD83900FEE751E85F6F);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&_stringLiteralEF420ABFDDBDA7B9EE665D85EF62E4A437554003);
		s_Il2CppMethodInitialized = true;
	}
	{
		__this->___m_AllowMSAA = (bool)1;
		Object__ctor_mE837C6B9FA8C6D5D109F4B2EC885D79919AC0EA2(__this, NULL);
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_0 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		String_t* L_1 = ___0_name;
		String_t* L_2;
		L_2 = String_Concat_m9E3155FB84015C823606188F53B47CB44C444991(L_1, _stringLiteralEF420ABFDDBDA7B9EE665D85EF62E4A437554003, NULL);
		L_0->___name = L_2;
		Il2CppCodeGenWriteBarrier((void**)(&L_0->___name), (void*)L_2);
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_3 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		String_t* L_4 = ___0_name;
		String_t* L_5;
		L_5 = String_Concat_m9E3155FB84015C823606188F53B47CB44C444991(L_4, _stringLiteralAB69FA1AB6BB831506EFCAD83900FEE751E85F6F, NULL);
		L_3->___name = L_5;
		Il2CppCodeGenWriteBarrier((void**)(&L_3->___name), (void*)L_5);
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RenderTargetBufferSystem_Dispose_m1C3AC5DA450F8B824721316FAC28EBAE5377DBC6 (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, const RuntimeMethod* method) 
{
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* G_B2_0 = NULL;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* G_B1_0 = NULL;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* G_B5_0 = NULL;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* G_B4_0 = NULL;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* G_B8_0 = NULL;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* G_B7_0 = NULL;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* G_B11_0 = NULL;
	RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* G_B10_0 = NULL;
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_0 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_1 = L_0->___rtMSAA;
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_2 = L_1;
		if (L_2)
		{
			G_B2_0 = L_2;
			goto IL_0011;
		}
		G_B1_0 = L_2;
	}
	{
		goto IL_0016;
	}

IL_0011:
	{
		NullCheck(G_B2_0);
		RTHandle_Release_m743C2A22FD95D177D2D425E9DF1F3088161F387B(G_B2_0, NULL);
	}

IL_0016:
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_3 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_4 = L_3->___rtMSAA;
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_5 = L_4;
		if (L_5)
		{
			G_B5_0 = L_5;
			goto IL_0027;
		}
		G_B4_0 = L_5;
	}
	{
		goto IL_002c;
	}

IL_0027:
	{
		NullCheck(G_B5_0);
		RTHandle_Release_m743C2A22FD95D177D2D425E9DF1F3088161F387B(G_B5_0, NULL);
	}

IL_002c:
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_6 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_7 = L_6->___rtResolve;
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_8 = L_7;
		if (L_8)
		{
			G_B8_0 = L_8;
			goto IL_003d;
		}
		G_B7_0 = L_8;
	}
	{
		goto IL_0042;
	}

IL_003d:
	{
		NullCheck(G_B8_0);
		RTHandle_Release_m743C2A22FD95D177D2D425E9DF1F3088161F387B(G_B8_0, NULL);
	}

IL_0042:
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_9 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_10 = L_9->___rtResolve;
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_11 = L_10;
		if (L_11)
		{
			G_B11_0 = L_11;
			goto IL_0052;
		}
		G_B10_0 = L_11;
	}
	{
		return;
	}

IL_0052:
	{
		NullCheck(G_B11_0);
		RTHandle_Release_m743C2A22FD95D177D2D425E9DF1F3088161F387B(G_B11_0, NULL);
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* RenderTargetBufferSystem_PeekBackBuffer_m5496A9F37497CE9915D760AD5F44FEA5EE304941 (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, const RuntimeMethod* method) 
{
	{
		bool L_0 = __this->___m_AllowMSAA;
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_1;
		L_1 = RenderTargetBufferSystem_get_backBuffer_mF7305DBD196865D17A0029AC212E8CC02D8205A2(__this, NULL);
		int32_t L_2 = L_1->___msaa;
		if ((((int32_t)L_2) > ((int32_t)1)))
		{
			goto IL_0022;
		}
	}

IL_0016:
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_3;
		L_3 = RenderTargetBufferSystem_get_backBuffer_mF7305DBD196865D17A0029AC212E8CC02D8205A2(__this, NULL);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_4 = L_3->___rtResolve;
		return L_4;
	}

IL_0022:
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_5;
		L_5 = RenderTargetBufferSystem_get_backBuffer_mF7305DBD196865D17A0029AC212E8CC02D8205A2(__this, NULL);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_6 = L_5->___rtMSAA;
		return L_6;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* RenderTargetBufferSystem_GetBackBuffer_m5783C133D632176EB13AA0B5651723B212AAE3B1 (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* ___0_cmd, const RuntimeMethod* method) 
{
	{
		CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* L_0 = ___0_cmd;
		RenderTargetBufferSystem_ReAllocate_m21F112E4C9D22893403D2BDC60ED8D41312AE0D9(__this, L_0, NULL);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_1;
		L_1 = RenderTargetBufferSystem_PeekBackBuffer_m5496A9F37497CE9915D760AD5F44FEA5EE304941(__this, NULL);
		return L_1;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* RenderTargetBufferSystem_GetFrontBuffer_m85150875CDE3FB4ED1E33FFABD9B9F1893DEA2D1 (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* ___0_cmd, const RuntimeMethod* method) 
{
	{
		bool L_0 = __this->___m_AllowMSAA;
		if (L_0)
		{
			goto IL_0022;
		}
	}
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_1;
		L_1 = RenderTargetBufferSystem_get_frontBuffer_mDD8E09139E41F59A682216AD6C0A94AE4387E11A(__this, NULL);
		int32_t L_2 = L_1->___msaa;
		if ((((int32_t)L_2) <= ((int32_t)1)))
		{
			goto IL_0022;
		}
	}
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_3;
		L_3 = RenderTargetBufferSystem_get_frontBuffer_mDD8E09139E41F59A682216AD6C0A94AE4387E11A(__this, NULL);
		L_3->___msaa = 1;
	}

IL_0022:
	{
		CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* L_4 = ___0_cmd;
		RenderTargetBufferSystem_ReAllocate_m21F112E4C9D22893403D2BDC60ED8D41312AE0D9(__this, L_4, NULL);
		bool L_5 = __this->___m_AllowMSAA;
		if (!L_5)
		{
			goto IL_003f;
		}
	}
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_6;
		L_6 = RenderTargetBufferSystem_get_frontBuffer_mDD8E09139E41F59A682216AD6C0A94AE4387E11A(__this, NULL);
		int32_t L_7 = L_6->___msaa;
		if ((((int32_t)L_7) > ((int32_t)1)))
		{
			goto IL_004b;
		}
	}

IL_003f:
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_8;
		L_8 = RenderTargetBufferSystem_get_frontBuffer_mDD8E09139E41F59A682216AD6C0A94AE4387E11A(__this, NULL);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_9 = L_8->___rtResolve;
		return L_9;
	}

IL_004b:
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_10;
		L_10 = RenderTargetBufferSystem_get_frontBuffer_mDD8E09139E41F59A682216AD6C0A94AE4387E11A(__this, NULL);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_11 = L_10->___rtMSAA;
		return L_11;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RenderTargetBufferSystem_Swap_m3D2279D4D03B17F4BA36717BAB07360C6F2C6D31 (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		il2cpp_codegen_runtime_class_init_inline(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		bool L_0 = ((RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields*)il2cpp_codegen_static_fields_for(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var))->___m_AisBackBuffer;
		((RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields*)il2cpp_codegen_static_fields_for(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var))->___m_AisBackBuffer = (bool)((((int32_t)L_0) == ((int32_t)0))? 1 : 0);
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RenderTargetBufferSystem_ReAllocate_m21F112E4C9D22893403D2BDC60ED8D41312AE0D9 (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* ___0_cmd, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&RenderingUtils_t4E40200449A82FA3A172A563C490DF11FADA2BE1_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		il2cpp_codegen_runtime_class_init_inline(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46 L_0 = ((RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields*)il2cpp_codegen_static_fields_for(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var))->___m_Desc;
		V_0 = L_0;
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_1 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		int32_t L_2 = L_1->___msaa;
		RenderTextureDescriptor_set_msaaSamples_m6910E09489372746391B14FBAF59A7237539D6C4_inline((&V_0), L_2, NULL);
		int32_t L_3;
		L_3 = RenderTextureDescriptor_get_msaaSamples_mFCC33643AFF2265C8305DCFD79ED8774A1A8FA22_inline((&V_0), NULL);
		if ((((int32_t)L_3) <= ((int32_t)1)))
		{
			goto IL_004e;
		}
	}
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_4 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B** L_5 = (RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B**)(&L_4->___rtMSAA);
		int32_t L_6 = __this->___m_FilterMode;
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_7 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		String_t* L_8 = L_7->___name;
		il2cpp_codegen_runtime_class_init_inline(RenderingUtils_t4E40200449A82FA3A172A563C490DF11FADA2BE1_il2cpp_TypeInfo_var);
		bool L_9;
		L_9 = RenderingUtils_ReAllocateIfNeeded_mDE48AE1C4158076D30E8D4D9322A9EE4219C2812(L_5, (&V_0), L_6, 1, (bool)0, 1, (0.0f), L_8, NULL);
	}

IL_004e:
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_10 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		int32_t L_11 = L_10->___msaa;
		RenderTextureDescriptor_set_msaaSamples_m6910E09489372746391B14FBAF59A7237539D6C4_inline((&V_0), L_11, NULL);
		int32_t L_12;
		L_12 = RenderTextureDescriptor_get_msaaSamples_mFCC33643AFF2265C8305DCFD79ED8774A1A8FA22_inline((&V_0), NULL);
		if ((((int32_t)L_12) <= ((int32_t)1)))
		{
			goto IL_0096;
		}
	}
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_13 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B** L_14 = (RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B**)(&L_13->___rtMSAA);
		int32_t L_15 = __this->___m_FilterMode;
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_16 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		String_t* L_17 = L_16->___name;
		il2cpp_codegen_runtime_class_init_inline(RenderingUtils_t4E40200449A82FA3A172A563C490DF11FADA2BE1_il2cpp_TypeInfo_var);
		bool L_18;
		L_18 = RenderingUtils_ReAllocateIfNeeded_mDE48AE1C4158076D30E8D4D9322A9EE4219C2812(L_14, (&V_0), L_15, 1, (bool)0, 1, (0.0f), L_17, NULL);
	}

IL_0096:
	{
		RenderTextureDescriptor_set_msaaSamples_m6910E09489372746391B14FBAF59A7237539D6C4_inline((&V_0), 1, NULL);
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_19 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B** L_20 = (RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B**)(&L_19->___rtResolve);
		int32_t L_21 = __this->___m_FilterMode;
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_22 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		String_t* L_23 = L_22->___name;
		il2cpp_codegen_runtime_class_init_inline(RenderingUtils_t4E40200449A82FA3A172A563C490DF11FADA2BE1_il2cpp_TypeInfo_var);
		bool L_24;
		L_24 = RenderingUtils_ReAllocateIfNeeded_mDE48AE1C4158076D30E8D4D9322A9EE4219C2812(L_20, (&V_0), L_21, 1, (bool)0, 1, (0.0f), L_23, NULL);
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_25 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B** L_26 = (RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B**)(&L_25->___rtResolve);
		int32_t L_27 = __this->___m_FilterMode;
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_28 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		String_t* L_29 = L_28->___name;
		bool L_30;
		L_30 = RenderingUtils_ReAllocateIfNeeded_mDE48AE1C4158076D30E8D4D9322A9EE4219C2812(L_26, (&V_0), L_27, 1, (bool)0, 1, (0.0f), L_29, NULL);
		CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* L_31 = ___0_cmd;
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_32 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		String_t* L_33 = L_32->___name;
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_34 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_35 = L_34->___rtResolve;
		RenderTargetIdentifier_tA528663AC6EB3911D8E91AA40F7070FA5455442B L_36;
		L_36 = RTHandle_op_Implicit_m2462183372B0496DE475889924EDCAAAD2011B54(L_35, NULL);
		NullCheck(L_31);
		CommandBuffer_SetGlobalTexture_mD6F1CC7E87FA88B5838D5EDAFBA602EF94FE1F69(L_31, L_33, L_36, NULL);
		CommandBuffer_tB56007DC84EF56296C325EC32DD12AC1E3DC91F7* L_37 = ___0_cmd;
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_38 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		String_t* L_39 = L_38->___name;
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_40 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_41 = L_40->___rtResolve;
		RenderTargetIdentifier_tA528663AC6EB3911D8E91AA40F7070FA5455442B L_42;
		L_42 = RTHandle_op_Implicit_m2462183372B0496DE475889924EDCAAAD2011B54(L_41, NULL);
		NullCheck(L_37);
		CommandBuffer_SetGlobalTexture_mD6F1CC7E87FA88B5838D5EDAFBA602EF94FE1F69(L_37, L_39, L_42, NULL);
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RenderTargetBufferSystem_Clear_m6E8586BB1A508B94496610A54EF39BE0A03B431B (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* G_B2_0 = NULL;
	RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* G_B1_0 = NULL;
	int32_t G_B3_0 = 0;
	RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* G_B3_1 = NULL;
	{
		il2cpp_codegen_runtime_class_init_inline(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		((RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields*)il2cpp_codegen_static_fields_for(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var))->___m_AisBackBuffer = (bool)1;
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_0 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		int32_t L_1 = L_0->___msaa;
		if ((((int32_t)L_1) > ((int32_t)1)))
		{
			G_B2_0 = __this;
			goto IL_0025;
		}
		G_B1_0 = __this;
	}
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_2 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		int32_t L_3 = L_2->___msaa;
		G_B3_0 = ((((int32_t)L_3) > ((int32_t)1))? 1 : 0);
		G_B3_1 = G_B1_0;
		goto IL_0026;
	}

IL_0025:
	{
		G_B3_0 = 1;
		G_B3_1 = G_B2_0;
	}

IL_0026:
	{
		NullCheck(G_B3_1);
		G_B3_1->___m_AllowMSAA = (bool)G_B3_0;
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RenderTargetBufferSystem_SetCameraSettings_m1F65A3121D31191F44E826D47ECBE5279EDC93F8 (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46 ___0_desc, int32_t ___1_filterMode, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		RenderTextureDescriptor_set_depthBufferBits_mA3710C0D6E485BA6465B328CD8B1954F0E4C5819((&___0_desc), 0, NULL);
		RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46 L_0 = ___0_desc;
		il2cpp_codegen_runtime_class_init_inline(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		((RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields*)il2cpp_codegen_static_fields_for(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var))->___m_Desc = L_0;
		int32_t L_1 = ___1_filterMode;
		__this->___m_FilterMode = L_1;
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_2 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		int32_t L_3;
		L_3 = RenderTextureDescriptor_get_msaaSamples_mFCC33643AFF2265C8305DCFD79ED8774A1A8FA22_inline((&((RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields*)il2cpp_codegen_static_fields_for(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var))->___m_Desc), NULL);
		L_2->___msaa = L_3;
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_4 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		int32_t L_5;
		L_5 = RenderTextureDescriptor_get_msaaSamples_mFCC33643AFF2265C8305DCFD79ED8774A1A8FA22_inline((&((RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields*)il2cpp_codegen_static_fields_for(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var))->___m_Desc), NULL);
		L_4->___msaa = L_5;
		int32_t L_6;
		L_6 = RenderTextureDescriptor_get_msaaSamples_mFCC33643AFF2265C8305DCFD79ED8774A1A8FA22_inline((&((RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields*)il2cpp_codegen_static_fields_for(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var))->___m_Desc), NULL);
		if ((((int32_t)L_6) <= ((int32_t)1)))
		{
			goto IL_0053;
		}
	}
	{
		RenderTargetBufferSystem_EnableMSAA_mFACEC550EEF2910AC94C1F22C0DA146DBE36F3CA(__this, (bool)1, NULL);
	}

IL_0053:
	{
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* RenderTargetBufferSystem_GetBufferA_m0E904787365B2DC88C4966E4D5B530B2A3639241 (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, const RuntimeMethod* method) 
{
	{
		bool L_0 = __this->___m_AllowMSAA;
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_1 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		int32_t L_2 = L_1->___msaa;
		if ((((int32_t)L_2) > ((int32_t)1)))
		{
			goto IL_0022;
		}
	}

IL_0016:
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_3 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_4 = L_3->___rtResolve;
		return L_4;
	}

IL_0022:
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_5 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		RTHandle_t135537761C47BC929F032B3C8F4D55EA1111B07B* L_6 = L_5->___rtMSAA;
		return L_6;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RenderTargetBufferSystem_EnableMSAA_mFACEC550EEF2910AC94C1F22C0DA146DBE36F3CA (RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13* __this, bool ___0_enable, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = ___0_enable;
		__this->___m_AllowMSAA = L_0;
		bool L_1 = ___0_enable;
		if (!L_1)
		{
			goto IL_0034;
		}
	}
	{
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_2 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_A);
		il2cpp_codegen_runtime_class_init_inline(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		int32_t L_3;
		L_3 = RenderTextureDescriptor_get_msaaSamples_mFCC33643AFF2265C8305DCFD79ED8774A1A8FA22_inline((&((RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields*)il2cpp_codegen_static_fields_for(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var))->___m_Desc), NULL);
		L_2->___msaa = L_3;
		SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4* L_4 = (SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4*)(&__this->___m_B);
		int32_t L_5;
		L_5 = RenderTextureDescriptor_get_msaaSamples_mFCC33643AFF2265C8305DCFD79ED8774A1A8FA22_inline((&((RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields*)il2cpp_codegen_static_fields_for(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var))->___m_Desc), NULL);
		L_4->___msaa = L_5;
	}

IL_0034:
	{
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void RenderTargetBufferSystem__cctor_m43224CB0048305175C0E52072E876BEFD934F869 (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		((RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_StaticFields*)il2cpp_codegen_static_fields_for(RenderTargetBufferSystem_tB98B680006BB96E6EBC6311583EE31302F16EC13_il2cpp_TypeInfo_var))->___m_AisBackBuffer = (bool)1;
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C void SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshal_pinvoke(const SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4& unmarshaled, SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshaled_pinvoke& marshaled)
{
	Exception_t* ___rtMSAAException = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'rtMSAA' of type 'SwapBuffer': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___rtMSAAException, NULL);
}
IL2CPP_EXTERN_C void SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshal_pinvoke_back(const SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshaled_pinvoke& marshaled, SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4& unmarshaled)
{
	Exception_t* ___rtMSAAException = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'rtMSAA' of type 'SwapBuffer': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___rtMSAAException, NULL);
}
IL2CPP_EXTERN_C void SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshal_pinvoke_cleanup(SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshaled_pinvoke& marshaled)
{
}
IL2CPP_EXTERN_C void SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshal_com(const SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4& unmarshaled, SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshaled_com& marshaled)
{
	Exception_t* ___rtMSAAException = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'rtMSAA' of type 'SwapBuffer': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___rtMSAAException, NULL);
}
IL2CPP_EXTERN_C void SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshal_com_back(const SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshaled_com& marshaled, SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4& unmarshaled)
{
	Exception_t* ___rtMSAAException = il2cpp_codegen_get_marshal_directive_exception("Cannot marshal field 'rtMSAA' of type 'SwapBuffer': Reference type field marshaling is not supported.");
	IL2CPP_RAISE_MANAGED_EXCEPTION(___rtMSAAException, NULL);
}
IL2CPP_EXTERN_C void SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshal_com_cleanup(SwapBuffer_t431F23072C45F1BEE6FF42872627D5393B39A7C4_marshaled_com& marshaled)
{
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlanarGraph_RemoveDuplicateEdges_m4D8093C793442A4260E7A6F688BC8831F4DC0AF9 (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___0_edges, int32_t* ___1_edgeCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___2_duplicates, int32_t ___3_duplicateCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434_mBE4B56307E132AEA84ADF183CC238AA9ED176FA6_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_2;
	memset((&V_2), 0, sizeof(V_2));
	int32_t V_3 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_4;
	memset((&V_4), 0, sizeof(V_4));
	int32_t V_5 = 0;
	int32_t V_6 = 0;
	TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434 V_7;
	memset((&V_7), 0, sizeof(V_7));
	int32_t V_8 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_9;
	memset((&V_9), 0, sizeof(V_9));
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_10;
	memset((&V_10), 0, sizeof(V_10));
	{
		int32_t L_0 = ___3_duplicateCount;
		if (L_0)
		{
			goto IL_006a;
		}
	}
	{
		V_1 = 0;
		goto IL_0063;
	}

IL_0007:
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_1 = ___0_edges;
		int32_t L_2 = V_1;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_3;
		L_3 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_1)->___m_Buffer, L_2);
		V_2 = L_3;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_4 = ___0_edges;
		int32_t L_5 = V_1;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_6;
		L_6 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_4)->___m_Buffer, L_5);
		int32_t L_7 = L_6.___x;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_8 = ___0_edges;
		int32_t L_9 = V_1;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_10;
		L_10 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_8)->___m_Buffer, L_9);
		int32_t L_11 = L_10.___y;
		int32_t L_12;
		L_12 = math_min_m02D43DF516544C279AF660EA4731449C82991849_inline(L_7, L_11, NULL);
		(&V_2)->___x = L_12;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_13 = ___0_edges;
		int32_t L_14 = V_1;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_15;
		L_15 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_13)->___m_Buffer, L_14);
		int32_t L_16 = L_15.___x;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_17 = ___0_edges;
		int32_t L_18 = V_1;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_19;
		L_19 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_17)->___m_Buffer, L_18);
		int32_t L_20 = L_19.___y;
		int32_t L_21;
		L_21 = math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline(L_16, L_20, NULL);
		(&V_2)->___y = L_21;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_22 = ___0_edges;
		int32_t L_23 = V_1;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_24 = V_2;
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_22)->___m_Buffer, L_23, (L_24));
		int32_t L_25 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_25, 1));
	}

IL_0063:
	{
		int32_t L_26 = V_1;
		int32_t* L_27 = ___1_edgeCount;
		int32_t L_28 = *((int32_t*)L_27);
		if ((((int32_t)L_26) < ((int32_t)L_28)))
		{
			goto IL_0007;
		}
	}
	{
		goto IL_00c9;
	}

IL_006a:
	{
		V_3 = 0;
		goto IL_00c4;
	}

IL_006e:
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_29 = ___0_edges;
		int32_t L_30 = V_3;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_31;
		L_31 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_29)->___m_Buffer, L_30);
		V_4 = L_31;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_32 = V_4;
		int32_t L_33 = L_32.___x;
		int32_t L_34;
		L_34 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&___2_duplicates))->___m_Buffer, L_33);
		V_5 = L_34;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_35 = V_4;
		int32_t L_36 = L_35.___y;
		int32_t L_37;
		L_37 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&___2_duplicates))->___m_Buffer, L_36);
		V_6 = L_37;
		int32_t L_38 = V_5;
		int32_t L_39 = V_6;
		int32_t L_40;
		L_40 = math_min_m02D43DF516544C279AF660EA4731449C82991849_inline(L_38, L_39, NULL);
		(&V_4)->___x = L_40;
		int32_t L_41 = V_5;
		int32_t L_42 = V_6;
		int32_t L_43;
		L_43 = math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline(L_41, L_42, NULL);
		(&V_4)->___y = L_43;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_44 = ___0_edges;
		int32_t L_45 = V_3;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_46 = V_4;
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_44)->___m_Buffer, L_45, (L_46));
		int32_t L_47 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_add(L_47, 1));
	}

IL_00c4:
	{
		int32_t L_48 = V_3;
		int32_t* L_49 = ___1_edgeCount;
		int32_t L_50 = *((int32_t*)L_49);
		if ((((int32_t)L_48) < ((int32_t)L_50)))
		{
			goto IL_006e;
		}
	}

IL_00c9:
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_51 = ___0_edges;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_52 = (*(NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)L_51);
		void* L_53;
		L_53 = NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D(L_52, NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D_RuntimeMethod_var);
		int32_t* L_54 = ___1_edgeCount;
		int32_t L_55 = *((int32_t*)L_54);
		il2cpp_codegen_initobj((&V_7), sizeof(TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434));
		TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434 L_56 = V_7;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434_mBE4B56307E132AEA84ADF183CC238AA9ED176FA6(L_53, 0, ((int32_t)il2cpp_codegen_subtract(L_55, 1)), L_56, ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434_mBE4B56307E132AEA84ADF183CC238AA9ED176FA6_RuntimeMethod_var);
		V_0 = 1;
		V_8 = 1;
		goto IL_0148;
	}

IL_00ef:
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_57 = ___0_edges;
		int32_t L_58 = V_8;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_59;
		L_59 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_57)->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_58, 1)));
		V_9 = L_59;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_60 = ___0_edges;
		int32_t L_61 = V_8;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_62;
		L_62 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_60)->___m_Buffer, L_61);
		V_10 = L_62;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_63 = V_10;
		int32_t L_64 = L_63.___x;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_65 = V_9;
		int32_t L_66 = L_65.___x;
		if ((!(((uint32_t)L_64) == ((uint32_t)L_66))))
		{
			goto IL_0125;
		}
	}
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_67 = V_10;
		int32_t L_68 = L_67.___y;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_69 = V_9;
		int32_t L_70 = L_69.___y;
		if ((((int32_t)L_68) == ((int32_t)L_70)))
		{
			goto IL_0142;
		}
	}

IL_0125:
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_71 = V_10;
		int32_t L_72 = L_71.___x;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_73 = V_10;
		int32_t L_74 = L_73.___y;
		if ((((int32_t)L_72) == ((int32_t)L_74)))
		{
			goto IL_0142;
		}
	}
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_75 = ___0_edges;
		int32_t L_76 = V_0;
		int32_t L_77 = L_76;
		V_0 = ((int32_t)il2cpp_codegen_add(L_77, 1));
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_78 = V_10;
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_75)->___m_Buffer, L_77, (L_78));
	}

IL_0142:
	{
		int32_t L_79 = V_8;
		V_8 = ((int32_t)il2cpp_codegen_add(L_79, 1));
	}

IL_0148:
	{
		int32_t L_80 = V_8;
		int32_t* L_81 = ___1_edgeCount;
		int32_t L_82 = *((int32_t*)L_81);
		if ((((int32_t)L_80) < ((int32_t)L_82)))
		{
			goto IL_00ef;
		}
	}
	{
		int32_t* L_83 = ___1_edgeCount;
		int32_t L_84 = V_0;
		*((int32_t*)L_83) = (int32_t)L_84;
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_CheckCollinear_mE8541609200181B09456FDBC9E5650D88FA8FB80 (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_a0, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_a1, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___2_b0, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___3_b1, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_0;
	memset((&V_0), 0, sizeof(V_0));
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_1;
	memset((&V_1), 0, sizeof(V_1));
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_2;
	memset((&V_2), 0, sizeof(V_2));
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_3;
	memset((&V_3), 0, sizeof(V_3));
	double V_4 = 0.0;
	double V_5 = 0.0;
	double V_6 = 0.0;
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_0 = ___0_a0;
		V_0 = L_0;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_1 = ___1_a1;
		V_1 = L_1;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_2 = ___2_b0;
		V_2 = L_2;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_3 = ___3_b1;
		V_3 = L_3;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_4 = V_1;
		double L_5 = L_4.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_6 = V_0;
		double L_7 = L_6.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_8 = V_1;
		double L_9 = L_8.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_10 = V_0;
		double L_11 = L_10.___x;
		V_4 = ((double)(((double)il2cpp_codegen_subtract(L_5, L_7))/((double)il2cpp_codegen_subtract(L_9, L_11))));
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_12 = V_2;
		double L_13 = L_12.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_14 = V_0;
		double L_15 = L_14.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_16 = V_2;
		double L_17 = L_16.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_18 = V_0;
		double L_19 = L_18.___x;
		V_5 = ((double)(((double)il2cpp_codegen_subtract(L_13, L_15))/((double)il2cpp_codegen_subtract(L_17, L_19))));
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_20 = V_3;
		double L_21 = L_20.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_22 = V_0;
		double L_23 = L_22.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_24 = V_3;
		double L_25 = L_24.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_26 = V_0;
		double L_27 = L_26.___x;
		V_6 = ((double)(((double)il2cpp_codegen_subtract(L_21, L_23))/((double)il2cpp_codegen_subtract(L_25, L_27))));
		double L_28 = V_4;
		bool L_29;
		L_29 = math_isinf_m4901864832BAA489A01E23F560733ACEF6E3ED60_inline(L_28, NULL);
		if (!L_29)
		{
			goto IL_007a;
		}
	}
	{
		double L_30 = V_5;
		bool L_31;
		L_31 = math_isinf_m4901864832BAA489A01E23F560733ACEF6E3ED60_inline(L_30, NULL);
		if (!L_31)
		{
			goto IL_007a;
		}
	}
	{
		double L_32 = V_6;
		bool L_33;
		L_33 = math_isinf_m4901864832BAA489A01E23F560733ACEF6E3ED60_inline(L_32, NULL);
		if (L_33)
		{
			goto IL_009d;
		}
	}

IL_007a:
	{
		double L_34 = V_4;
		double L_35 = V_5;
		double L_36;
		L_36 = math_abs_mDF669CF3AF2C60713E8E118578461CDA050DAFD0_inline(((double)il2cpp_codegen_subtract(L_34, L_35)), NULL);
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_37 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_36) > ((double)L_37))))
		{
			goto IL_009d;
		}
	}
	{
		double L_38 = V_4;
		double L_39 = V_6;
		double L_40;
		L_40 = math_abs_mDF669CF3AF2C60713E8E118578461CDA050DAFD0_inline(((double)il2cpp_codegen_subtract(L_38, L_39)), NULL);
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_41 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		return (bool)((((double)L_40) > ((double)L_41))? 1 : 0);
	}

IL_009d:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_LineLineIntersection_m2B966C163526B64A4DA7761553162AB175C37681 (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_a0, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_a1, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___2_b0, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___3_b1, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	double V_0 = 0.0;
	double V_1 = 0.0;
	double V_2 = 0.0;
	double V_3 = 0.0;
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_0 = ___0_a0;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_1 = ___2_b0;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_2 = ___3_b1;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		double L_3;
		L_3 = ModuleHandle_OrientFastDouble_mABC4A67B5FBB79701003AF2B4367E67DA4E021AA(L_0, L_1, L_2, NULL);
		V_0 = L_3;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_4 = ___1_a1;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_5 = ___2_b0;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_6 = ___3_b1;
		double L_7;
		L_7 = ModuleHandle_OrientFastDouble_mABC4A67B5FBB79701003AF2B4367E67DA4E021AA(L_4, L_5, L_6, NULL);
		V_1 = L_7;
		double L_8 = V_0;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_9 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_8) > ((double)L_9))))
		{
			goto IL_0022;
		}
	}
	{
		double L_10 = V_1;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_11 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((((double)L_10) > ((double)L_11)))
		{
			goto IL_0034;
		}
	}

IL_0022:
	{
		double L_12 = V_0;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_13 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_12) < ((double)((-L_13))))))
		{
			goto IL_0036;
		}
	}
	{
		double L_14 = V_1;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_15 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_14) < ((double)((-L_15))))))
		{
			goto IL_0036;
		}
	}

IL_0034:
	{
		return (bool)0;
	}

IL_0036:
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_16 = ___2_b0;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_17 = ___0_a0;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_18 = ___1_a1;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		double L_19;
		L_19 = ModuleHandle_OrientFastDouble_mABC4A67B5FBB79701003AF2B4367E67DA4E021AA(L_16, L_17, L_18, NULL);
		V_2 = L_19;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_20 = ___3_b1;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_21 = ___0_a0;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_22 = ___1_a1;
		double L_23;
		L_23 = ModuleHandle_OrientFastDouble_mABC4A67B5FBB79701003AF2B4367E67DA4E021AA(L_20, L_21, L_22, NULL);
		V_3 = L_23;
		double L_24 = V_2;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_25 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_24) > ((double)L_25))))
		{
			goto IL_0058;
		}
	}
	{
		double L_26 = V_3;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_27 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((((double)L_26) > ((double)L_27)))
		{
			goto IL_006a;
		}
	}

IL_0058:
	{
		double L_28 = V_2;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_29 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_28) < ((double)((-L_29))))))
		{
			goto IL_006c;
		}
	}
	{
		double L_30 = V_3;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_31 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_30) < ((double)((-L_31))))))
		{
			goto IL_006c;
		}
	}

IL_006a:
	{
		return (bool)0;
	}

IL_006c:
	{
		double L_32 = V_0;
		double L_33;
		L_33 = math_abs_mDF669CF3AF2C60713E8E118578461CDA050DAFD0_inline(L_32, NULL);
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_34 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_33) < ((double)L_34))))
		{
			goto IL_00aa;
		}
	}
	{
		double L_35 = V_1;
		double L_36;
		L_36 = math_abs_mDF669CF3AF2C60713E8E118578461CDA050DAFD0_inline(L_35, NULL);
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_37 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_36) < ((double)L_37))))
		{
			goto IL_00aa;
		}
	}
	{
		double L_38 = V_2;
		double L_39;
		L_39 = math_abs_mDF669CF3AF2C60713E8E118578461CDA050DAFD0_inline(L_38, NULL);
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_40 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_39) < ((double)L_40))))
		{
			goto IL_00aa;
		}
	}
	{
		double L_41 = V_3;
		double L_42;
		L_42 = math_abs_mDF669CF3AF2C60713E8E118578461CDA050DAFD0_inline(L_41, NULL);
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_43 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_42) < ((double)L_43))))
		{
			goto IL_00aa;
		}
	}
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_44 = ___0_a0;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_45 = ___1_a1;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_46 = ___2_b0;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_47 = ___3_b1;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		bool L_48;
		L_48 = PlanarGraph_CheckCollinear_mE8541609200181B09456FDBC9E5650D88FA8FB80(L_44, L_45, L_46, L_47, NULL);
		return L_48;
	}

IL_00aa:
	{
		return (bool)1;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_LineLineIntersection_mE3A4C366A1D1393F4AA6811190BC4E42B861A3E9 (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_p1, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_p2, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___2_p3, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___3_p4, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA* ___4_result, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	double V_0 = 0.0;
	double V_1 = 0.0;
	double V_2 = 0.0;
	double V_3 = 0.0;
	double V_4 = 0.0;
	double V_5 = 0.0;
	double V_6 = 0.0;
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_0 = ___1_p2;
		double L_1 = L_0.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_2 = ___0_p1;
		double L_3 = L_2.___x;
		V_0 = ((double)il2cpp_codegen_subtract(L_1, L_3));
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_4 = ___1_p2;
		double L_5 = L_4.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_6 = ___0_p1;
		double L_7 = L_6.___y;
		V_1 = ((double)il2cpp_codegen_subtract(L_5, L_7));
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_8 = ___3_p4;
		double L_9 = L_8.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_10 = ___2_p3;
		double L_11 = L_10.___x;
		V_2 = ((double)il2cpp_codegen_subtract(L_9, L_11));
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_12 = ___3_p4;
		double L_13 = L_12.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_14 = ___2_p3;
		double L_15 = L_14.___y;
		V_3 = ((double)il2cpp_codegen_subtract(L_13, L_15));
		double L_16 = V_0;
		double L_17 = V_3;
		double L_18 = V_1;
		double L_19 = V_2;
		V_4 = ((double)il2cpp_codegen_subtract(((double)il2cpp_codegen_multiply(L_16, L_17)), ((double)il2cpp_codegen_multiply(L_18, L_19))));
		double L_20 = V_4;
		double L_21;
		L_21 = math_abs_mDF669CF3AF2C60713E8E118578461CDA050DAFD0_inline(L_20, NULL);
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_22 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_21) < ((double)L_22))))
		{
			goto IL_0051;
		}
	}
	{
		return (bool)0;
	}

IL_0051:
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_23 = ___2_p3;
		double L_24 = L_23.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_25 = ___0_p1;
		double L_26 = L_25.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_27 = ___2_p3;
		double L_28 = L_27.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_29 = ___0_p1;
		double L_30 = L_29.___y;
		V_5 = ((double)il2cpp_codegen_subtract(L_28, L_30));
		double L_31 = V_3;
		double L_32 = V_5;
		double L_33 = V_2;
		double L_34 = V_4;
		V_6 = ((double)(((double)il2cpp_codegen_subtract(((double)il2cpp_codegen_multiply(((double)il2cpp_codegen_subtract(L_24, L_26)), L_31)), ((double)il2cpp_codegen_multiply(L_32, L_33))))/L_34));
		double L_35 = V_6;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_36 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_35) >= ((double)((-L_36))))))
		{
			goto IL_00bc;
		}
	}
	{
		double L_37 = V_6;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_38 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_37) <= ((double)((double)il2cpp_codegen_add((1.0), L_38))))))
		{
			goto IL_00bc;
		}
	}
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA* L_39 = ___4_result;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_40 = ___0_p1;
		double L_41 = L_40.___x;
		double L_42 = V_6;
		double L_43 = V_0;
		L_39->___x = ((double)il2cpp_codegen_add(L_41, ((double)il2cpp_codegen_multiply(L_42, L_43))));
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA* L_44 = ___4_result;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_45 = ___0_p1;
		double L_46 = L_45.___y;
		double L_47 = V_6;
		double L_48 = V_1;
		L_44->___y = ((double)il2cpp_codegen_add(L_46, ((double)il2cpp_codegen_multiply(L_47, L_48))));
		return (bool)1;
	}

IL_00bc:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_CalculateEdgeIntersections_mD28FD1B9C616447BC850126854BA901F527E4E72 (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_edges, int32_t ___1_edgeCount, NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 ___2_points, int32_t ___3_pointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___4_results, NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* ___5_intersects, int32_t* ___6_resultCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisIntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489_mCEC67F4B9CB4B8CA627B923D2CFC9173F15EC916_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_2;
	memset((&V_2), 0, sizeof(V_2));
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_3;
	memset((&V_3), 0, sizeof(V_3));
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_4;
	memset((&V_4), 0, sizeof(V_4));
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_5;
	memset((&V_5), 0, sizeof(V_5));
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_6;
	memset((&V_6), 0, sizeof(V_6));
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_7;
	memset((&V_7), 0, sizeof(V_7));
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_8;
	memset((&V_8), 0, sizeof(V_8));
	int32_t V_9 = 0;
	IntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489 V_10;
	memset((&V_10), 0, sizeof(V_10));
	{
		int32_t* L_0 = ___6_resultCount;
		*((int32_t*)L_0) = (int32_t)0;
		V_0 = 0;
		goto IL_0112;
	}

IL_000b:
	{
		int32_t L_1 = V_0;
		V_1 = ((int32_t)il2cpp_codegen_add(L_1, 1));
		goto IL_0107;
	}

IL_0014:
	{
		int32_t L_2 = V_0;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_3;
		L_3 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_2);
		V_2 = L_3;
		int32_t L_4 = V_1;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_5;
		L_5 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_4);
		V_3 = L_5;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_6 = V_2;
		int32_t L_7 = L_6.___x;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_8 = V_3;
		int32_t L_9 = L_8.___x;
		if ((((int32_t)L_7) == ((int32_t)L_9)))
		{
			goto IL_0103;
		}
	}
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_10 = V_2;
		int32_t L_11 = L_10.___x;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_12 = V_3;
		int32_t L_13 = L_12.___y;
		if ((((int32_t)L_11) == ((int32_t)L_13)))
		{
			goto IL_0103;
		}
	}
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_14 = V_2;
		int32_t L_15 = L_14.___y;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_16 = V_3;
		int32_t L_17 = L_16.___x;
		if ((((int32_t)L_15) == ((int32_t)L_17)))
		{
			goto IL_0103;
		}
	}
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_18 = V_2;
		int32_t L_19 = L_18.___y;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_20 = V_3;
		int32_t L_21 = L_20.___y;
		if ((((int32_t)L_19) == ((int32_t)L_21)))
		{
			goto IL_0103;
		}
	}
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_22 = V_2;
		int32_t L_23 = L_22.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_24;
		L_24 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, ((&___2_points))->___m_Buffer, L_23);
		V_4 = L_24;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_25 = V_2;
		int32_t L_26 = L_25.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_27;
		L_27 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, ((&___2_points))->___m_Buffer, L_26);
		V_5 = L_27;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_28 = V_3;
		int32_t L_29 = L_28.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_30;
		L_30 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, ((&___2_points))->___m_Buffer, L_29);
		V_6 = L_30;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_31 = V_3;
		int32_t L_32 = L_31.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_33;
		L_33 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, ((&___2_points))->___m_Buffer, L_32);
		V_7 = L_33;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_34 = ((double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA_StaticFields*)il2cpp_codegen_static_fields_for(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA_il2cpp_TypeInfo_var))->___zero;
		V_8 = L_34;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_35 = V_4;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_36 = V_5;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_37 = V_6;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_38 = V_7;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		bool L_39;
		L_39 = PlanarGraph_LineLineIntersection_m2B966C163526B64A4DA7761553162AB175C37681(L_35, L_36, L_37, L_38, NULL);
		if (!L_39)
		{
			goto IL_0103;
		}
	}
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_40 = V_4;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_41 = V_5;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_42 = V_6;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_43 = V_7;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		bool L_44;
		L_44 = PlanarGraph_LineLineIntersection_mE3A4C366A1D1393F4AA6811190BC4E42B861A3E9(L_40, L_41, L_42, L_43, (&V_8), NULL);
		if (!L_44)
		{
			goto IL_0103;
		}
	}
	{
		int32_t* L_45 = ___6_resultCount;
		int32_t L_46 = *((int32_t*)L_45);
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_47 = ___5_intersects;
		int32_t L_48;
		L_48 = IL2CPP_NATIVEARRAY_GET_LENGTH((L_47)->___m_Length);
		if ((((int32_t)L_46) < ((int32_t)L_48)))
		{
			goto IL_00db;
		}
	}
	{
		return (bool)0;
	}

IL_00db:
	{
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_49 = ___5_intersects;
		int32_t* L_50 = ___6_resultCount;
		int32_t L_51 = *((int32_t*)L_50);
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_52 = V_8;
		IL2CPP_NATIVEARRAY_SET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_49)->___m_Buffer, L_51, (L_52));
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_53 = ___4_results;
		int32_t* L_54 = ___6_resultCount;
		int32_t* L_55 = ___6_resultCount;
		int32_t L_56 = *((int32_t*)L_55);
		V_9 = L_56;
		int32_t L_57 = V_9;
		*((int32_t*)L_54) = (int32_t)((int32_t)il2cpp_codegen_add(L_57, 1));
		int32_t L_58 = V_9;
		int32_t L_59 = V_0;
		int32_t L_60 = V_1;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_61;
		memset((&L_61), 0, sizeof(L_61));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_61), L_59, L_60, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_53)->___m_Buffer, L_58, (L_61));
	}

IL_0103:
	{
		int32_t L_62 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_62, 1));
	}

IL_0107:
	{
		int32_t L_63 = V_1;
		int32_t L_64 = ___1_edgeCount;
		if ((((int32_t)L_63) < ((int32_t)L_64)))
		{
			goto IL_0014;
		}
	}
	{
		int32_t L_65 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_65, 1));
	}

IL_0112:
	{
		int32_t L_66 = V_0;
		int32_t L_67 = ___1_edgeCount;
		if ((((int32_t)L_66) < ((int32_t)L_67)))
		{
			goto IL_000b;
		}
	}
	{
		int32_t* L_68 = ___6_resultCount;
		int32_t L_69 = *((int32_t*)L_68);
		int32_t L_70 = ___1_edgeCount;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		int32_t L_71 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kMaxIntersectionTolerance;
		if ((((int32_t)L_69) <= ((int32_t)((int32_t)il2cpp_codegen_multiply(L_70, L_71)))))
		{
			goto IL_0127;
		}
	}
	{
		return (bool)0;
	}

IL_0127:
	{
		il2cpp_codegen_initobj((&V_10), sizeof(IntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489));
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_72 = ___0_edges;
		(&V_10)->___edges = L_72;
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 L_73 = ___2_points;
		(&V_10)->___points = L_73;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_74 = ___4_results;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_75 = (*(NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)L_74);
		void* L_76;
		L_76 = NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D(L_75, NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D_RuntimeMethod_var);
		int32_t* L_77 = ___6_resultCount;
		int32_t L_78 = *((int32_t*)L_77);
		IntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489 L_79 = V_10;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisIntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489_mCEC67F4B9CB4B8CA627B923D2CFC9173F15EC916(L_76, 0, ((int32_t)il2cpp_codegen_subtract(L_78, 1)), L_79, ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisIntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489_mCEC67F4B9CB4B8CA627B923D2CFC9173F15EC916_RuntimeMethod_var);
		return (bool)1;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_CalculateTJunctions_m6BEE6D4B46B8B467D3ED4B72528B80DE33EF631D (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_edges, int32_t ___1_edgeCount, NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 ___2_points, int32_t ___3_pointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___4_results, int32_t* ___5_resultCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_2;
	memset((&V_2), 0, sizeof(V_2));
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_3;
	memset((&V_3), 0, sizeof(V_3));
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_4;
	memset((&V_4), 0, sizeof(V_4));
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_5;
	memset((&V_5), 0, sizeof(V_5));
	int32_t V_6 = 0;
	{
		int32_t* L_0 = ___5_resultCount;
		*((int32_t*)L_0) = (int32_t)0;
		V_0 = 0;
		goto IL_00a1;
	}

IL_000b:
	{
		V_1 = 0;
		goto IL_0096;
	}

IL_0012:
	{
		int32_t L_1 = V_0;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_2;
		L_2 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_1);
		V_2 = L_2;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_3 = V_2;
		int32_t L_4 = L_3.___x;
		int32_t L_5 = V_1;
		if ((((int32_t)L_4) == ((int32_t)L_5)))
		{
			goto IL_0092;
		}
	}
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_6 = V_2;
		int32_t L_7 = L_6.___y;
		int32_t L_8 = V_1;
		if ((((int32_t)L_7) == ((int32_t)L_8)))
		{
			goto IL_0092;
		}
	}
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_9 = V_2;
		int32_t L_10 = L_9.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_11;
		L_11 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, ((&___2_points))->___m_Buffer, L_10);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_12 = V_2;
		int32_t L_13 = L_12.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_14;
		L_14 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, ((&___2_points))->___m_Buffer, L_13);
		V_3 = L_14;
		int32_t L_15 = V_1;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_16;
		L_16 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, ((&___2_points))->___m_Buffer, L_15);
		V_4 = L_16;
		int32_t L_17 = V_1;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_18;
		L_18 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, ((&___2_points))->___m_Buffer, L_17);
		V_5 = L_18;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_19 = V_3;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_20 = V_4;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_21 = V_5;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		bool L_22;
		L_22 = PlanarGraph_LineLineIntersection_m2B966C163526B64A4DA7761553162AB175C37681(L_11, L_19, L_20, L_21, NULL);
		if (!L_22)
		{
			goto IL_0092;
		}
	}
	{
		int32_t* L_23 = ___5_resultCount;
		int32_t L_24 = *((int32_t*)L_23);
		int32_t L_25;
		L_25 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___4_results))->___m_Length);
		if ((((int32_t)L_24) < ((int32_t)L_25)))
		{
			goto IL_0076;
		}
	}
	{
		return (bool)0;
	}

IL_0076:
	{
		int32_t* L_26 = ___5_resultCount;
		int32_t* L_27 = ___5_resultCount;
		int32_t L_28 = *((int32_t*)L_27);
		V_6 = L_28;
		int32_t L_29 = V_6;
		*((int32_t*)L_26) = (int32_t)((int32_t)il2cpp_codegen_add(L_29, 1));
		int32_t L_30 = V_6;
		int32_t L_31 = V_0;
		int32_t L_32 = V_1;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_33;
		memset((&L_33), 0, sizeof(L_33));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_33), L_31, L_32, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___4_results))->___m_Buffer, L_30, (L_33));
	}

IL_0092:
	{
		int32_t L_34 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_34, 1));
	}

IL_0096:
	{
		int32_t L_35 = V_1;
		int32_t L_36 = ___3_pointCount;
		if ((((int32_t)L_35) < ((int32_t)L_36)))
		{
			goto IL_0012;
		}
	}
	{
		int32_t L_37 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_37, 1));
	}

IL_00a1:
	{
		int32_t L_38 = V_0;
		int32_t L_39 = ___1_edgeCount;
		if ((((int32_t)L_38) < ((int32_t)L_39)))
		{
			goto IL_000b;
		}
	}
	{
		return (bool)1;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_CutEdges_m2FB895C4BE99D67313093CB017933D5DFADDD205 (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* ___0_points, int32_t* ___1_pointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___2_edges, int32_t* ___3_edgeCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___4_tJunctions, int32_t* ___5_tJunctionCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___6_intersections, NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 ___7_intersects, int32_t ___8_intersectionCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249_mDFFBE16DF5663EFCBC9251F641DD620ACBF7374D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_3;
	memset((&V_3), 0, sizeof(V_3));
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_4;
	memset((&V_4), 0, sizeof(V_4));
	int32_t V_5 = 0;
	TessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249 V_6;
	memset((&V_6), 0, sizeof(V_6));
	int32_t V_7 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_8;
	memset((&V_8), 0, sizeof(V_8));
	int32_t V_9 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_10;
	memset((&V_10), 0, sizeof(V_10));
	int32_t V_11 = 0;
	int32_t V_12 = 0;
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_13;
	memset((&V_13), 0, sizeof(V_13));
	double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA V_14;
	memset((&V_14), 0, sizeof(V_14));
	int32_t V_15 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_16;
	memset((&V_16), 0, sizeof(V_16));
	int32_t V_17 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_18;
	memset((&V_18), 0, sizeof(V_18));
	{
		V_0 = 0;
		goto IL_00a2;
	}

IL_0007:
	{
		int32_t L_0 = V_0;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_1;
		L_1 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___6_intersections))->___m_Buffer, L_0);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_2 = L_1;
		int32_t L_3 = L_2.___x;
		V_1 = L_3;
		int32_t L_4 = L_2.___y;
		V_2 = L_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_5 = ((int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_StaticFields*)il2cpp_codegen_static_fields_for(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_il2cpp_TypeInfo_var))->___zero;
		V_3 = L_5;
		int32_t L_6 = V_1;
		(&V_3)->___x = L_6;
		int32_t* L_7 = ___1_pointCount;
		int32_t L_8 = *((int32_t*)L_7);
		(&V_3)->___y = L_8;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_9 = ___4_tJunctions;
		int32_t* L_10 = ___5_tJunctionCount;
		int32_t* L_11 = ___5_tJunctionCount;
		int32_t L_12 = *((int32_t*)L_11);
		V_5 = L_12;
		int32_t L_13 = V_5;
		*((int32_t*)L_10) = (int32_t)((int32_t)il2cpp_codegen_add(L_13, 1));
		int32_t L_14 = V_5;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_15 = V_3;
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_9)->___m_Buffer, L_14, (L_15));
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_16 = ((int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_StaticFields*)il2cpp_codegen_static_fields_for(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_il2cpp_TypeInfo_var))->___zero;
		V_4 = L_16;
		int32_t L_17 = V_2;
		(&V_4)->___x = L_17;
		int32_t* L_18 = ___1_pointCount;
		int32_t L_19 = *((int32_t*)L_18);
		(&V_4)->___y = L_19;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_20 = ___4_tJunctions;
		int32_t* L_21 = ___5_tJunctionCount;
		int32_t* L_22 = ___5_tJunctionCount;
		int32_t L_23 = *((int32_t*)L_22);
		V_5 = L_23;
		int32_t L_24 = V_5;
		*((int32_t*)L_21) = (int32_t)((int32_t)il2cpp_codegen_add(L_24, 1));
		int32_t L_25 = V_5;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_26 = V_4;
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_20)->___m_Buffer, L_25, (L_26));
		int32_t* L_27 = ___1_pointCount;
		int32_t L_28 = *((int32_t*)L_27);
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_29 = ___0_points;
		int32_t L_30;
		L_30 = IL2CPP_NATIVEARRAY_GET_LENGTH((L_29)->___m_Length);
		if ((((int32_t)L_28) < ((int32_t)L_30)))
		{
			goto IL_0084;
		}
	}
	{
		return (bool)0;
	}

IL_0084:
	{
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_31 = ___0_points;
		int32_t* L_32 = ___1_pointCount;
		int32_t* L_33 = ___1_pointCount;
		int32_t L_34 = *((int32_t*)L_33);
		V_5 = L_34;
		int32_t L_35 = V_5;
		*((int32_t*)L_32) = (int32_t)((int32_t)il2cpp_codegen_add(L_35, 1));
		int32_t L_36 = V_5;
		int32_t L_37 = V_0;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_38;
		L_38 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, ((&___7_intersects))->___m_Buffer, L_37);
		IL2CPP_NATIVEARRAY_SET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_31)->___m_Buffer, L_36, (L_38));
		int32_t L_39 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_39, 1));
	}

IL_00a2:
	{
		int32_t L_40 = V_0;
		int32_t L_41 = ___8_intersectionCount;
		if ((((int32_t)L_40) < ((int32_t)L_41)))
		{
			goto IL_0007;
		}
	}
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_42 = ___4_tJunctions;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_43 = (*(NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)L_42);
		void* L_44;
		L_44 = NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D(L_43, NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D_RuntimeMethod_var);
		int32_t* L_45 = ___5_tJunctionCount;
		int32_t L_46 = *((int32_t*)L_45);
		il2cpp_codegen_initobj((&V_6), sizeof(TessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249));
		TessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249 L_47 = V_6;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249_mDFFBE16DF5663EFCBC9251F641DD620ACBF7374D(L_44, 0, ((int32_t)il2cpp_codegen_subtract(L_46, 1)), L_47, ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249_mDFFBE16DF5663EFCBC9251F641DD620ACBF7374D_RuntimeMethod_var);
		int32_t* L_48 = ___5_tJunctionCount;
		int32_t L_49 = *((int32_t*)L_48);
		V_7 = ((int32_t)il2cpp_codegen_subtract(L_49, 1));
		goto IL_0225;
	}

IL_00d7:
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_50 = ___4_tJunctions;
		int32_t L_51 = V_7;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_52;
		L_52 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_50)->___m_Buffer, L_51);
		V_8 = L_52;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_53 = V_8;
		int32_t L_54 = L_53.___x;
		V_9 = L_54;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_55 = ___2_edges;
		int32_t L_56 = V_9;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_57;
		L_57 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_55)->___m_Buffer, L_56);
		V_10 = L_57;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_58 = V_10;
		int32_t L_59 = L_58.___x;
		V_11 = L_59;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_60 = V_10;
		int32_t L_61 = L_60.___y;
		V_12 = L_61;
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_62 = ___0_points;
		int32_t L_63 = V_11;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_64;
		L_64 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_62)->___m_Buffer, L_63);
		V_13 = L_64;
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_65 = ___0_points;
		int32_t L_66 = V_12;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_67;
		L_67 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_65)->___m_Buffer, L_66);
		V_14 = L_67;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_68 = V_13;
		double L_69 = L_68.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_70 = V_14;
		double L_71 = L_70.___x;
		if ((((double)((double)il2cpp_codegen_subtract(L_69, L_71))) < ((double)(0.0))))
		{
			goto IL_015f;
		}
	}
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_72 = V_13;
		double L_73 = L_72.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_74 = V_14;
		double L_75 = L_74.___x;
		if ((!(((double)L_73) == ((double)L_75))))
		{
			goto IL_0167;
		}
	}
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_76 = V_13;
		double L_77 = L_76.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_78 = V_14;
		double L_79 = L_78.___y;
		if ((!(((double)((double)il2cpp_codegen_subtract(L_77, L_79))) < ((double)(0.0)))))
		{
			goto IL_0167;
		}
	}

IL_015f:
	{
		int32_t L_80 = V_11;
		int32_t L_81 = V_12;
		V_11 = L_81;
		V_12 = L_80;
	}

IL_0167:
	{
		int32_t L_82 = V_11;
		(&V_10)->___x = L_82;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_83 = V_8;
		int32_t L_84 = L_83.___y;
		int32_t L_85 = L_84;
		V_5 = L_85;
		(&V_10)->___y = L_85;
		int32_t L_86 = V_5;
		V_15 = L_86;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_87 = ___2_edges;
		int32_t L_88 = V_9;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_89 = V_10;
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_87)->___m_Buffer, L_88, (L_89));
		goto IL_01d8;
	}

IL_0191:
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_90 = ___4_tJunctions;
		int32_t L_91 = V_7;
		int32_t L_92 = ((int32_t)il2cpp_codegen_subtract(L_91, 1));
		V_7 = L_92;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_93;
		L_93 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_90)->___m_Buffer, L_92);
		int32_t L_94 = L_93.___y;
		V_17 = L_94;
		il2cpp_codegen_initobj((&V_18), sizeof(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A));
		int32_t L_95 = V_15;
		(&V_18)->___x = L_95;
		int32_t L_96 = V_17;
		(&V_18)->___y = L_96;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_97 = ___2_edges;
		int32_t* L_98 = ___3_edgeCount;
		int32_t* L_99 = ___3_edgeCount;
		int32_t L_100 = *((int32_t*)L_99);
		V_5 = L_100;
		int32_t L_101 = V_5;
		*((int32_t*)L_98) = (int32_t)((int32_t)il2cpp_codegen_add(L_101, 1));
		int32_t L_102 = V_5;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_103 = V_18;
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_97)->___m_Buffer, L_102, (L_103));
		int32_t L_104 = V_17;
		V_15 = L_104;
	}

IL_01d8:
	{
		int32_t L_105 = V_7;
		if ((((int32_t)L_105) <= ((int32_t)0)))
		{
			goto IL_01f1;
		}
	}
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_106 = ___4_tJunctions;
		int32_t L_107 = V_7;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_108;
		L_108 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_106)->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_107, 1)));
		int32_t L_109 = L_108.___x;
		int32_t L_110 = V_9;
		if ((((int32_t)L_109) == ((int32_t)L_110)))
		{
			goto IL_0191;
		}
	}

IL_01f1:
	{
		il2cpp_codegen_initobj((&V_16), sizeof(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A));
		int32_t L_111 = V_15;
		(&V_16)->___x = L_111;
		int32_t L_112 = V_12;
		(&V_16)->___y = L_112;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_113 = ___2_edges;
		int32_t* L_114 = ___3_edgeCount;
		int32_t* L_115 = ___3_edgeCount;
		int32_t L_116 = *((int32_t*)L_115);
		V_5 = L_116;
		int32_t L_117 = V_5;
		*((int32_t*)L_114) = (int32_t)((int32_t)il2cpp_codegen_add(L_117, 1));
		int32_t L_118 = V_5;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_119 = V_16;
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_113)->___m_Buffer, L_118, (L_119));
		int32_t L_120 = V_7;
		V_7 = ((int32_t)il2cpp_codegen_subtract(L_120, 1));
	}

IL_0225:
	{
		int32_t L_121 = V_7;
		if ((((int32_t)L_121) >= ((int32_t)0)))
		{
			goto IL_00d7;
		}
	}
	{
		return (bool)1;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlanarGraph_RemoveDuplicatePoints_m44A9ABC6078AC3B50542117CEE25DF8DF9ED58A1 (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* ___0_points, int32_t* ___1_pointCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___2_duplicates, int32_t* ___3_duplicateCount, int32_t ___4_allocator, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38 V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	int32_t V_6 = 0;
	int32_t V_7 = 0;
	int32_t V_8 = 0;
	{
		int32_t* L_0 = ___1_pointCount;
		int32_t L_1 = *((int32_t*)L_0);
		int32_t L_2 = ___4_allocator;
		TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38 L_3;
		L_3 = TessLink_CreateLink_m1E7D2D1DD89E196BF1CBBDC76B508021F81B2FB8(L_1, L_2, NULL);
		V_0 = L_3;
		V_1 = 0;
		goto IL_0044;
	}

IL_000e:
	{
		int32_t L_4 = V_1;
		V_2 = ((int32_t)il2cpp_codegen_add(L_4, 1));
		goto IL_003b;
	}

IL_0014:
	{
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_5 = ___0_points;
		int32_t L_6 = V_1;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_7;
		L_7 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_5)->___m_Buffer, L_6);
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_8 = ___0_points;
		int32_t L_9 = V_2;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_10;
		L_10 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_8)->___m_Buffer, L_9);
		double L_11;
		L_11 = math_distance_m72BEFBAADFC4404FADD3AD81F7EDD40E32624F4D_inline(L_7, L_10, NULL);
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		double L_12 = ((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon;
		if ((!(((double)L_11) < ((double)L_12))))
		{
			goto IL_0037;
		}
	}
	{
		int32_t L_13 = V_1;
		int32_t L_14 = V_2;
		TessLink_Link_m549C4DE253753727A94A94BC9BC7EF6B417DC9E0((&V_0), L_13, L_14, NULL);
	}

IL_0037:
	{
		int32_t L_15 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add(L_15, 1));
	}

IL_003b:
	{
		int32_t L_16 = V_2;
		int32_t* L_17 = ___1_pointCount;
		int32_t L_18 = *((int32_t*)L_17);
		if ((((int32_t)L_16) < ((int32_t)L_18)))
		{
			goto IL_0014;
		}
	}
	{
		int32_t L_19 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_19, 1));
	}

IL_0044:
	{
		int32_t L_20 = V_1;
		int32_t* L_21 = ___1_pointCount;
		int32_t L_22 = *((int32_t*)L_21);
		if ((((int32_t)L_20) < ((int32_t)L_22)))
		{
			goto IL_000e;
		}
	}
	{
		int32_t* L_23 = ___3_duplicateCount;
		*((int32_t*)L_23) = (int32_t)0;
		V_3 = 0;
		goto IL_0085;
	}

IL_0050:
	{
		int32_t L_24 = V_3;
		int32_t L_25;
		L_25 = TessLink_Find_mAD567324D6131379359E9A266D2AC30A31F0226E((&V_0), L_24, NULL);
		V_4 = L_25;
		int32_t L_26 = V_4;
		int32_t L_27 = V_3;
		if ((((int32_t)L_26) == ((int32_t)L_27)))
		{
			goto IL_0081;
		}
	}
	{
		int32_t* L_28 = ___3_duplicateCount;
		int32_t* L_29 = ___3_duplicateCount;
		int32_t L_30 = *((int32_t*)L_29);
		*((int32_t*)L_28) = (int32_t)((int32_t)il2cpp_codegen_add(L_30, 1));
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_31 = ___0_points;
		int32_t L_32 = V_4;
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_33 = ___0_points;
		int32_t L_34 = V_3;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_35;
		L_35 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_33)->___m_Buffer, L_34);
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_36 = ___0_points;
		int32_t L_37 = V_4;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_38;
		L_38 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_36)->___m_Buffer, L_37);
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_39;
		L_39 = math_min_m1D64D6B67B27FD9738D14BCEE6298146CB05CE00_inline(L_35, L_38, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_31)->___m_Buffer, L_32, (L_39));
	}

IL_0081:
	{
		int32_t L_40 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_add(L_40, 1));
	}

IL_0085:
	{
		int32_t L_41 = V_3;
		int32_t* L_42 = ___1_pointCount;
		int32_t L_43 = *((int32_t*)L_42);
		if ((((int32_t)L_41) < ((int32_t)L_43)))
		{
			goto IL_0050;
		}
	}
	{
		int32_t* L_44 = ___3_duplicateCount;
		int32_t L_45 = *((int32_t*)L_44);
		if (!L_45)
		{
			goto IL_0118;
		}
	}
	{
		int32_t* L_46 = ___1_pointCount;
		int32_t L_47 = *((int32_t*)L_46);
		V_5 = L_47;
		int32_t* L_48 = ___1_pointCount;
		*((int32_t*)L_48) = (int32_t)0;
		V_6 = 0;
		goto IL_00df;
	}

IL_009d:
	{
		int32_t L_49 = V_6;
		int32_t L_50;
		L_50 = TessLink_Find_mAD567324D6131379359E9A266D2AC30A31F0226E((&V_0), L_49, NULL);
		int32_t L_51 = V_6;
		if ((!(((uint32_t)L_50) == ((uint32_t)L_51))))
		{
			goto IL_00d0;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_52 = ___2_duplicates;
		int32_t L_53 = V_6;
		int32_t* L_54 = ___1_pointCount;
		int32_t L_55 = *((int32_t*)L_54);
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_52)->___m_Buffer, L_53, (L_55));
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_56 = ___0_points;
		int32_t* L_57 = ___1_pointCount;
		int32_t* L_58 = ___1_pointCount;
		int32_t L_59 = *((int32_t*)L_58);
		V_7 = L_59;
		int32_t L_60 = V_7;
		*((int32_t*)L_57) = (int32_t)((int32_t)il2cpp_codegen_add(L_60, 1));
		int32_t L_61 = V_7;
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_62 = ___0_points;
		int32_t L_63 = V_6;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_64;
		L_64 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_62)->___m_Buffer, L_63);
		IL2CPP_NATIVEARRAY_SET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_56)->___m_Buffer, L_61, (L_64));
		goto IL_00d9;
	}

IL_00d0:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_65 = ___2_duplicates;
		int32_t L_66 = V_6;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_65)->___m_Buffer, L_66, ((-1)));
	}

IL_00d9:
	{
		int32_t L_67 = V_6;
		V_6 = ((int32_t)il2cpp_codegen_add(L_67, 1));
	}

IL_00df:
	{
		int32_t L_68 = V_6;
		int32_t L_69 = V_5;
		if ((((int32_t)L_68) < ((int32_t)L_69)))
		{
			goto IL_009d;
		}
	}
	{
		V_8 = 0;
		goto IL_0112;
	}

IL_00ea:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_70 = ___2_duplicates;
		int32_t L_71 = V_8;
		int32_t L_72;
		L_72 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_70)->___m_Buffer, L_71);
		if ((((int32_t)L_72) >= ((int32_t)0)))
		{
			goto IL_010c;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_73 = ___2_duplicates;
		int32_t L_74 = V_8;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_75 = ___2_duplicates;
		int32_t L_76 = V_8;
		int32_t L_77;
		L_77 = TessLink_Find_mAD567324D6131379359E9A266D2AC30A31F0226E((&V_0), L_76, NULL);
		int32_t L_78;
		L_78 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_75)->___m_Buffer, L_77);
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_73)->___m_Buffer, L_74, (L_78));
	}

IL_010c:
	{
		int32_t L_79 = V_8;
		V_8 = ((int32_t)il2cpp_codegen_add(L_79, 1));
	}

IL_0112:
	{
		int32_t L_80 = V_8;
		int32_t L_81 = V_5;
		if ((((int32_t)L_80) < ((int32_t)L_81)))
		{
			goto IL_00ea;
		}
	}

IL_0118:
	{
		TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38 L_82 = V_0;
		TessLink_DestroyLink_m96AD3C95F393DABD8862EC3CE5F8EEEB905B1CAD(L_82, NULL);
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool PlanarGraph_Validate_mD6F5B2173F4C2C298986E926D9C372B88B0ED39D (int32_t ___0_allocator, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___1_inputPoints, int32_t ___2_pointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___3_inputEdges, int32_t ___4_edgeCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___5_outputPoints, int32_t* ___6_outputPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___7_outputEdges, int32_t* ___8_outputEdgeCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_mE0AE14258D3045288D915F3FD346533D843D7CDB_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mC429670774D3D1F7CB41BBD8C5BD9943404BDF54_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	int32_t V_1 = 0;
	bool V_2 = false;
	bool V_3 = false;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C V_4;
	memset((&V_4), 0, sizeof(V_4));
	NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 V_5;
	memset((&V_5), 0, sizeof(V_5));
	NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 V_6;
	memset((&V_6), 0, sizeof(V_6));
	NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 V_7;
	memset((&V_7), 0, sizeof(V_7));
	NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 V_8;
	memset((&V_8), 0, sizeof(V_8));
	NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 V_9;
	memset((&V_9), 0, sizeof(V_9));
	int32_t V_10 = 0;
	int32_t V_11 = 0;
	int32_t V_12 = 0;
	int32_t V_13 = 0;
	int32_t V_14 = 0;
	int32_t G_B10_0 = 0;
	{
		V_0 = (10000.0f);
		int32_t L_0 = ___4_edgeCount;
		V_1 = L_0;
		V_2 = (bool)1;
		V_3 = (bool)0;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_1 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxEdgeCount;
		int32_t L_2 = ___0_allocator;
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&V_4), L_1, L_2, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		int32_t L_3 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxEdgeCount;
		int32_t L_4 = ___0_allocator;
		NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13((&V_5), L_3, L_4, 1, NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		int32_t L_5 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxEdgeCount;
		int32_t L_6 = ___0_allocator;
		NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13((&V_6), L_5, L_6, 1, NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		int32_t L_7 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxEdgeCount;
		int32_t L_8 = ___0_allocator;
		NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13((&V_7), L_7, L_8, 1, NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		int32_t L_9 = ___2_pointCount;
		int32_t L_10 = ___0_allocator;
		NativeArray_1__ctor_mC429670774D3D1F7CB41BBD8C5BD9943404BDF54((&V_8), ((int32_t)il2cpp_codegen_multiply(L_9, 8)), L_10, 1, NativeArray_1__ctor_mC429670774D3D1F7CB41BBD8C5BD9943404BDF54_RuntimeMethod_var);
		int32_t L_11 = ___2_pointCount;
		int32_t L_12 = ___0_allocator;
		NativeArray_1__ctor_mC429670774D3D1F7CB41BBD8C5BD9943404BDF54((&V_9), ((int32_t)il2cpp_codegen_multiply(L_11, 8)), L_12, 1, NativeArray_1__ctor_mC429670774D3D1F7CB41BBD8C5BD9943404BDF54_RuntimeMethod_var);
		V_10 = 0;
		goto IL_0085;
	}

IL_0062:
	{
		int32_t L_13 = V_10;
		int32_t L_14 = V_10;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_15;
		L_15 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___1_inputPoints))->___m_Buffer, L_14);
		float L_16 = V_0;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_17;
		L_17 = float2_op_Multiply_m34D03129CE0D7AD665A914DE83CB749585B2455F_inline(L_15, L_16, NULL);
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_18;
		L_18 = double2_op_Implicit_m168C031549D6C086B7C49ECA5B18C892B3112F17_inline(L_17, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, ((&V_8))->___m_Buffer, L_13, (L_18));
		int32_t L_19 = V_10;
		V_10 = ((int32_t)il2cpp_codegen_add(L_19, 1));
	}

IL_0085:
	{
		int32_t L_20 = V_10;
		int32_t L_21 = ___2_pointCount;
		if ((((int32_t)L_20) < ((int32_t)L_21)))
		{
			goto IL_0062;
		}
	}
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_22 = ___3_inputEdges;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_23 = V_5;
		int32_t L_24 = ___4_edgeCount;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C(L_22, L_23, L_24, ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C_RuntimeMethod_var);
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_25 = V_4;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		PlanarGraph_RemoveDuplicateEdges_m4D8093C793442A4260E7A6F688BC8831F4DC0AF9((&V_5), (&___4_edgeCount), L_25, 0, NULL);
		goto IL_0118;
	}

IL_00a2:
	{
		V_11 = 0;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_26 = V_5;
		int32_t L_27 = ___4_edgeCount;
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 L_28 = V_8;
		int32_t L_29 = ___2_pointCount;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		bool L_30;
		L_30 = PlanarGraph_CalculateEdgeIntersections_mD28FD1B9C616447BC850126854BA901F527E4E72(L_26, L_27, L_28, L_29, (&V_7), (&V_9), (&V_11), NULL);
		V_3 = L_30;
		bool L_31 = V_3;
		if (!L_31)
		{
			goto IL_0126;
		}
	}
	{
		V_12 = 0;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_32 = V_5;
		int32_t L_33 = ___4_edgeCount;
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 L_34 = V_8;
		int32_t L_35 = ___2_pointCount;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_36 = V_6;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		bool L_37;
		L_37 = PlanarGraph_CalculateTJunctions_m6BEE6D4B46B8B467D3ED4B72528B80DE33EF631D(L_32, L_33, L_34, L_35, L_36, (&V_12), NULL);
		V_3 = L_37;
		bool L_38 = V_3;
		if (!L_38)
		{
			goto IL_0126;
		}
	}
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_39 = V_7;
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7 L_40 = V_9;
		int32_t L_41 = V_11;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		bool L_42;
		L_42 = PlanarGraph_CutEdges_m2FB895C4BE99D67313093CB017933D5DFADDD205((&V_8), (&___2_pointCount), (&V_5), (&___4_edgeCount), (&V_6), (&V_12), L_39, L_40, L_41, NULL);
		V_3 = L_42;
		bool L_43 = V_3;
		if (!L_43)
		{
			goto IL_0126;
		}
	}
	{
		V_13 = 0;
		int32_t L_44 = ___0_allocator;
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		PlanarGraph_RemoveDuplicatePoints_m44A9ABC6078AC3B50542117CEE25DF8DF9ED58A1((&V_8), (&___2_pointCount), (&V_4), (&V_13), L_44, NULL);
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_45 = V_4;
		int32_t L_46 = V_13;
		PlanarGraph_RemoveDuplicateEdges_m4D8093C793442A4260E7A6F688BC8831F4DC0AF9((&V_5), (&___4_edgeCount), L_45, L_46, NULL);
		int32_t L_47 = V_11;
		if (L_47)
		{
			goto IL_0116;
		}
	}
	{
		int32_t L_48 = V_12;
		G_B10_0 = ((!(((uint32_t)L_48) <= ((uint32_t)0)))? 1 : 0);
		goto IL_0117;
	}

IL_0116:
	{
		G_B10_0 = 1;
	}

IL_0117:
	{
		V_2 = (bool)G_B10_0;
	}

IL_0118:
	{
		bool L_49 = V_2;
		if (!L_49)
		{
			goto IL_0126;
		}
	}
	{
		int32_t L_50 = V_1;
		int32_t L_51 = ((int32_t)il2cpp_codegen_subtract(L_50, 1));
		V_1 = L_51;
		if ((((int32_t)L_51) > ((int32_t)0)))
		{
			goto IL_00a2;
		}
	}

IL_0126:
	{
		bool L_52 = V_3;
		if (!L_52)
		{
			goto IL_0184;
		}
	}
	{
		int32_t* L_53 = ___8_outputEdgeCount;
		int32_t L_54 = ___4_edgeCount;
		*((int32_t*)L_53) = (int32_t)L_54;
		int32_t* L_55 = ___6_outputPointCount;
		int32_t L_56 = ___2_pointCount;
		*((int32_t*)L_55) = (int32_t)L_56;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_57 = V_5;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_58 = ___7_outputEdges;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_59 = (*(NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)L_58);
		int32_t L_60 = ___4_edgeCount;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C(L_57, L_59, L_60, ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C_RuntimeMethod_var);
		V_14 = 0;
		goto IL_017f;
	}

IL_0147:
	{
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_61 = ___5_outputPoints;
		int32_t L_62 = V_14;
		int32_t L_63 = V_14;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_64;
		L_64 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, ((&V_8))->___m_Buffer, L_63);
		double L_65 = L_64.___x;
		float L_66 = V_0;
		int32_t L_67 = V_14;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_68;
		L_68 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, ((&V_8))->___m_Buffer, L_67);
		double L_69 = L_68.___y;
		float L_70 = V_0;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_71;
		memset((&L_71), 0, sizeof(L_71));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_71), ((float)((double)(L_65/((double)L_66)))), ((float)((double)(L_69/((double)L_70)))), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_61)->___m_Buffer, L_62, (L_71));
		int32_t L_72 = V_14;
		V_14 = ((int32_t)il2cpp_codegen_add(L_72, 1));
	}

IL_017f:
	{
		int32_t L_73 = V_14;
		int32_t L_74 = ___2_pointCount;
		if ((((int32_t)L_73) < ((int32_t)L_74)))
		{
			goto IL_0147;
		}
	}

IL_0184:
	{
		NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2((&V_5), NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		NativeArray_1_Dispose_mE0AE14258D3045288D915F3FD346533D843D7CDB((&V_8), NativeArray_1_Dispose_mE0AE14258D3045288D915F3FD346533D843D7CDB_RuntimeMethod_var);
		NativeArray_1_Dispose_mE0AE14258D3045288D915F3FD346533D843D7CDB((&V_9), NativeArray_1_Dispose_mE0AE14258D3045288D915F3FD346533D843D7CDB_RuntimeMethod_var);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E((&V_4), NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2((&V_6), NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2((&V_7), NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		bool L_75 = V_3;
		if (!L_75)
		{
			goto IL_01b6;
		}
	}
	{
		int32_t L_76 = V_1;
		return (bool)((((int32_t)L_76) > ((int32_t)0))? 1 : 0);
	}

IL_01b6:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void PlanarGraph__cctor_m983A12F5FF58770032B1A963EED842705B3DD139 (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kEpsilon = (1.0000000000000001E-05);
		((PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_StaticFields*)il2cpp_codegen_static_fields_for(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var))->___kMaxIntersectionTolerance = 4;
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Refinery_RequiresRefining_mE61A0BDBFE5757B48372A5AC578FEF6181C3A384 (UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD ___0_tri, float ___1_maxArea, const RuntimeMethod* method) 
{
	{
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_0 = ___0_tri;
		float L_1 = L_0.___area;
		float L_2 = ___1_maxArea;
		return (bool)((((float)L_1) > ((float)L_2))? 1 : 0);
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Refinery_FetchEncroachedSegments_m75A2A73743DC464AA0A2F5D4119480D0063A4FFA (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_pgPoints, int32_t ___1_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___2_pgEdges, int32_t ___3_pgEdgeCount, NativeArray_1_tB723C353A73B34FE57C3B9EA16A02A466B268BC2* ___4_encroach, int32_t* ___5_encroachCount, UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 ___6_c, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_1;
	memset((&V_1), 0, sizeof(V_1));
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_2;
	memset((&V_2), 0, sizeof(V_2));
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_3;
	memset((&V_3), 0, sizeof(V_3));
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_4;
	memset((&V_4), 0, sizeof(V_4));
	float V_5 = 0.0f;
	UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA V_6;
	memset((&V_6), 0, sizeof(V_6));
	int32_t V_7 = 0;
	{
		V_0 = 0;
		goto IL_00d0;
	}

IL_0007:
	{
		int32_t L_0 = V_0;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_1;
		L_1 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___2_pgEdges))->___m_Buffer, L_0);
		V_1 = L_1;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_2 = V_1;
		int32_t L_3 = L_2.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4;
		L_4 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_pgPoints))->___m_Buffer, L_3);
		V_2 = L_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_5 = V_1;
		int32_t L_6 = L_5.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_7;
		L_7 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_pgPoints))->___m_Buffer, L_6);
		V_3 = L_7;
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_8 = ___6_c;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_9 = L_8.___center;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_10 = V_2;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_11;
		L_11 = float2_op_Subtraction_m28172675A65BCFFBC8C9023BE815019E668B8380_inline(L_9, L_10, NULL);
		bool L_12;
		L_12 = math_any_mCBBE4E2611B227A8AE1A4DA7F104D779203539F9_inline(L_11, NULL);
		if (!L_12)
		{
			goto IL_00cc;
		}
	}
	{
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_13 = ___6_c;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_14 = L_13.___center;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_15 = V_3;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_16;
		L_16 = float2_op_Subtraction_m28172675A65BCFFBC8C9023BE815019E668B8380_inline(L_14, L_15, NULL);
		bool L_17;
		L_17 = math_any_mCBBE4E2611B227A8AE1A4DA7F104D779203539F9_inline(L_16, NULL);
		if (!L_17)
		{
			goto IL_00cc;
		}
	}
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_18 = V_2;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_19 = V_3;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_20;
		L_20 = float2_op_Subtraction_m28172675A65BCFFBC8C9023BE815019E668B8380_inline(L_18, L_19, NULL);
		V_4 = L_20;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_21 = V_2;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_22 = V_3;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_23;
		L_23 = float2_op_Addition_m718974663A956F64D7C45D06C088550637F13693_inline(L_21, L_22, NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_24;
		L_24 = float2_op_Multiply_m34D03129CE0D7AD665A914DE83CB749585B2455F_inline(L_23, (0.5f), NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_25 = V_4;
		float L_26;
		L_26 = math_length_m3DB47D254C8544FBB740A892B4AE2143E8F45634_inline(L_25, NULL);
		V_5 = ((float)il2cpp_codegen_multiply(L_26, (0.5f)));
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_27 = ___6_c;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_28 = L_27.___center;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_29;
		L_29 = float2_op_Subtraction_m28172675A65BCFFBC8C9023BE815019E668B8380_inline(L_24, L_28, NULL);
		float L_30;
		L_30 = math_length_m3DB47D254C8544FBB740A892B4AE2143E8F45634_inline(L_29, NULL);
		float L_31 = V_5;
		if ((((float)L_30) > ((float)L_31)))
		{
			goto IL_00cc;
		}
	}
	{
		il2cpp_codegen_initobj((&V_6), sizeof(UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA));
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_32 = V_2;
		(&V_6)->___a = L_32;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_33 = V_3;
		(&V_6)->___b = L_33;
		int32_t L_34 = V_0;
		(&V_6)->___index = L_34;
		NativeArray_1_tB723C353A73B34FE57C3B9EA16A02A466B268BC2* L_35 = ___4_encroach;
		int32_t* L_36 = ___5_encroachCount;
		int32_t* L_37 = ___5_encroachCount;
		int32_t L_38 = *((int32_t*)L_37);
		V_7 = L_38;
		int32_t L_39 = V_7;
		*((int32_t*)L_36) = (int32_t)((int32_t)il2cpp_codegen_add(L_39, 1));
		int32_t L_40 = V_7;
		UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA L_41 = V_6;
		IL2CPP_NATIVEARRAY_SET_ITEM(UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA, (L_35)->___m_Buffer, L_40, (L_41));
	}

IL_00cc:
	{
		int32_t L_42 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_42, 1));
	}

IL_00d0:
	{
		int32_t L_43 = V_0;
		int32_t L_44 = ___3_pgEdgeCount;
		if ((((int32_t)L_43) < ((int32_t)L_44)))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Refinery_InsertVertex_mD6E0D24EC6CAF9562984E486202245B3E8356BC2 (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___0_pgPoints, int32_t* ___1_pgPointCount, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_newVertex, int32_t* ___3_nid, const RuntimeMethod* method) 
{
	{
		int32_t* L_0 = ___3_nid;
		int32_t* L_1 = ___1_pgPointCount;
		int32_t L_2 = *((int32_t*)L_1);
		*((int32_t*)L_0) = (int32_t)L_2;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_3 = ___0_pgPoints;
		int32_t* L_4 = ___3_nid;
		int32_t L_5 = *((int32_t*)L_4);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6 = ___2_newVertex;
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_3)->___m_Buffer, L_5, (L_6));
		int32_t* L_7 = ___1_pgPointCount;
		int32_t* L_8 = ___1_pgPointCount;
		int32_t L_9 = *((int32_t*)L_8);
		*((int32_t*)L_7) = (int32_t)((int32_t)il2cpp_codegen_add(L_9, 1));
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Refinery_FindSegment_m7BECA9AA1FA8B303B08B67BB3E35EEEDA8FC141B (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_pgPoints, int32_t ___1_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___2_pgEdges, int32_t ___3_pgEdgeCount, UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA ___4_es, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_1;
	memset((&V_1), 0, sizeof(V_1));
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_2;
	memset((&V_2), 0, sizeof(V_2));
	{
		UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA L_0 = ___4_es;
		int32_t L_1 = L_0.___index;
		V_0 = L_1;
		goto IL_005b;
	}

IL_000a:
	{
		int32_t L_2 = V_0;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_3;
		L_3 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___2_pgEdges))->___m_Buffer, L_2);
		V_1 = L_3;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_4 = V_1;
		int32_t L_5 = L_4.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6;
		L_6 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_pgPoints))->___m_Buffer, L_5);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_7 = V_1;
		int32_t L_8 = L_7.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_9;
		L_9 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_pgPoints))->___m_Buffer, L_8);
		V_2 = L_9;
		UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA L_10 = ___4_es;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_11 = L_10.___a;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_12;
		L_12 = float2_op_Subtraction_m28172675A65BCFFBC8C9023BE815019E668B8380_inline(L_6, L_11, NULL);
		bool L_13;
		L_13 = math_any_mCBBE4E2611B227A8AE1A4DA7F104D779203539F9_inline(L_12, NULL);
		if (L_13)
		{
			goto IL_0057;
		}
	}
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_14 = V_2;
		UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA L_15 = ___4_es;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_16 = L_15.___b;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_17;
		L_17 = float2_op_Subtraction_m28172675A65BCFFBC8C9023BE815019E668B8380_inline(L_14, L_16, NULL);
		bool L_18;
		L_18 = math_any_mCBBE4E2611B227A8AE1A4DA7F104D779203539F9_inline(L_17, NULL);
		if (L_18)
		{
			goto IL_0057;
		}
	}
	{
		int32_t L_19 = V_0;
		return L_19;
	}

IL_0057:
	{
		int32_t L_20 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_20, 1));
	}

IL_005b:
	{
		int32_t L_21 = V_0;
		int32_t L_22 = ___3_pgEdgeCount;
		if ((((int32_t)L_21) < ((int32_t)L_22)))
		{
			goto IL_000a;
		}
	}
	{
		return (-1);
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Refinery_SplitSegments_m1B90CC5AE3456482287E24ECFB79F54C7CC1FE6A (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___0_pgPoints, int32_t* ___1_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___2_pgEdges, int32_t* ___3_pgEdgeCount, UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA ___4_es, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_1;
	memset((&V_1), 0, sizeof(V_1));
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_2;
	memset((&V_2), 0, sizeof(V_2));
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_3;
	memset((&V_3), 0, sizeof(V_3));
	int32_t V_4 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_5;
	memset((&V_5), 0, sizeof(V_5));
	int32_t V_6 = 0;
	int32_t V_7 = 0;
	int32_t G_B6_0 = 0;
	{
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_0 = ___0_pgPoints;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_1 = (*(NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*)L_0);
		int32_t* L_2 = ___1_pgPointCount;
		int32_t L_3 = *((int32_t*)L_2);
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_4 = ___2_pgEdges;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_5 = (*(NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)L_4);
		int32_t* L_6 = ___3_pgEdgeCount;
		int32_t L_7 = *((int32_t*)L_6);
		UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA L_8 = ___4_es;
		il2cpp_codegen_runtime_class_init_inline(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var);
		int32_t L_9;
		L_9 = Refinery_FindSegment_m7BECA9AA1FA8B303B08B67BB3E35EEEDA8FC141B(L_1, L_3, L_5, L_7, L_8, NULL);
		V_0 = L_9;
		int32_t L_10 = V_0;
		if ((!(((uint32_t)L_10) == ((uint32_t)(-1)))))
		{
			goto IL_001d;
		}
	}
	{
		return;
	}

IL_001d:
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_11 = ___2_pgEdges;
		int32_t L_12 = V_0;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_13;
		L_13 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_11)->___m_Buffer, L_12);
		V_1 = L_13;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_14 = ___0_pgPoints;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_15 = V_1;
		int32_t L_16 = L_15.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_17;
		L_17 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_14)->___m_Buffer, L_16);
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_18 = ___0_pgPoints;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_19 = V_1;
		int32_t L_20 = L_19.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_21;
		L_21 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_18)->___m_Buffer, L_20);
		V_2 = L_21;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_22 = V_2;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_23;
		L_23 = float2_op_Addition_m718974663A956F64D7C45D06C088550637F13693_inline(L_17, L_22, NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_24;
		L_24 = float2_op_Multiply_m34D03129CE0D7AD665A914DE83CB749585B2455F_inline(L_23, (0.5f), NULL);
		V_3 = L_24;
		V_4 = 0;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_25 = V_1;
		int32_t L_26 = L_25.___x;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_27 = V_1;
		int32_t L_28 = L_27.___y;
		int32_t L_29;
		L_29 = math_abs_mFF027629978A9039B059528ED3075D775AA0B0AB_inline(((int32_t)il2cpp_codegen_subtract(L_26, L_28)), NULL);
		if ((!(((uint32_t)L_29) == ((uint32_t)1))))
		{
			goto IL_00f3;
		}
	}
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_30 = V_1;
		int32_t L_31 = L_30.___x;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_32 = V_1;
		int32_t L_33 = L_32.___y;
		if ((((int32_t)L_31) > ((int32_t)L_33)))
		{
			goto IL_0080;
		}
	}
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_34 = V_1;
		int32_t L_35 = L_34.___y;
		G_B6_0 = L_35;
		goto IL_0086;
	}

IL_0080:
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_36 = V_1;
		int32_t L_37 = L_36.___x;
		G_B6_0 = L_37;
	}

IL_0086:
	{
		V_4 = G_B6_0;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_38 = ___0_pgPoints;
		int32_t* L_39 = ___1_pgPointCount;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_40 = V_3;
		il2cpp_codegen_runtime_class_init_inline(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var);
		Refinery_InsertVertex_mD6E0D24EC6CAF9562984E486202245B3E8356BC2(L_38, L_39, L_40, (&V_4), NULL);
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_41 = ___2_pgEdges;
		int32_t L_42 = V_0;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_43;
		L_43 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_41)->___m_Buffer, L_42);
		V_5 = L_43;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_44 = ___2_pgEdges;
		int32_t L_45 = V_0;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_46 = V_5;
		int32_t L_47 = L_46.___x;
		int32_t L_48 = V_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_49;
		memset((&L_49), 0, sizeof(L_49));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_49), L_47, L_48, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_44)->___m_Buffer, L_45, (L_49));
		int32_t* L_50 = ___3_pgEdgeCount;
		int32_t L_51 = *((int32_t*)L_50);
		V_6 = L_51;
		goto IL_00ce;
	}

IL_00b6:
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_52 = ___2_pgEdges;
		int32_t L_53 = V_6;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_54 = ___2_pgEdges;
		int32_t L_55 = V_6;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_56;
		L_56 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_54)->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_55, 1)));
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_52)->___m_Buffer, L_53, (L_56));
		int32_t L_57 = V_6;
		V_6 = ((int32_t)il2cpp_codegen_subtract(L_57, 1));
	}

IL_00ce:
	{
		int32_t L_58 = V_6;
		int32_t L_59 = V_0;
		if ((((int32_t)L_58) > ((int32_t)((int32_t)il2cpp_codegen_add(L_59, 1)))))
		{
			goto IL_00b6;
		}
	}
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_60 = ___2_pgEdges;
		int32_t L_61 = V_0;
		int32_t L_62 = V_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_63 = V_5;
		int32_t L_64 = L_63.___y;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_65;
		memset((&L_65), 0, sizeof(L_65));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_65), L_62, L_64, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_60)->___m_Buffer, ((int32_t)il2cpp_codegen_add(L_61, 1)), (L_65));
		int32_t* L_66 = ___3_pgEdgeCount;
		int32_t* L_67 = ___3_pgEdgeCount;
		int32_t L_68 = *((int32_t*)L_67);
		*((int32_t*)L_66) = (int32_t)((int32_t)il2cpp_codegen_add(L_68, 1));
		return;
	}

IL_00f3:
	{
		int32_t* L_69 = ___1_pgPointCount;
		int32_t L_70 = *((int32_t*)L_69);
		V_4 = L_70;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_71 = ___0_pgPoints;
		int32_t* L_72 = ___1_pgPointCount;
		int32_t* L_73 = ___1_pgPointCount;
		int32_t L_74 = *((int32_t*)L_73);
		V_7 = L_74;
		int32_t L_75 = V_7;
		*((int32_t*)L_72) = (int32_t)((int32_t)il2cpp_codegen_add(L_75, 1));
		int32_t L_76 = V_7;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_77 = V_3;
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_71)->___m_Buffer, L_76, (L_77));
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_78 = ___2_pgEdges;
		int32_t L_79 = V_0;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_80 = V_1;
		int32_t L_81 = L_80.___x;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_82 = V_1;
		int32_t L_83 = L_82.___y;
		int32_t L_84;
		L_84 = math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline(L_81, L_83, NULL);
		int32_t L_85 = V_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_86;
		memset((&L_86), 0, sizeof(L_86));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_86), L_84, L_85, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_78)->___m_Buffer, L_79, (L_86));
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_87 = ___2_pgEdges;
		int32_t* L_88 = ___3_pgEdgeCount;
		int32_t* L_89 = ___3_pgEdgeCount;
		int32_t L_90 = *((int32_t*)L_89);
		V_7 = L_90;
		int32_t L_91 = V_7;
		*((int32_t*)L_88) = (int32_t)((int32_t)il2cpp_codegen_add(L_91, 1));
		int32_t L_92 = V_7;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_93 = V_1;
		int32_t L_94 = L_93.___x;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_95 = V_1;
		int32_t L_96 = L_95.___y;
		int32_t L_97;
		L_97 = math_min_m02D43DF516544C279AF660EA4731449C82991849_inline(L_94, L_96, NULL);
		int32_t L_98 = V_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_99;
		memset((&L_99), 0, sizeof(L_99));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_99), L_97, L_98, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_87)->___m_Buffer, L_92, (L_99));
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Refinery_Condition_m75ECBF8D82871AEB1D046E61F20DD3700E18D214 (int32_t ___0_allocator, float ___1_factorArea, float ___2_targetArea, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___3_pgPoints, int32_t* ___4_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___5_pgEdges, int32_t* ___6_pgEdgeCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___7_vertices, int32_t* ___8_vertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___9_indices, int32_t* ___10_indexCount, float* ___11_maxArea, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m2FC0457FE238F347CEF96BDA77BA875179E5704B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_mB48AC20750ECFD2702E0F9915B2177D044D15C58_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_m89F748542AF7065DD1BC4780E9A0E4F3D41073ED_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mCFEB37C6F648F756D9AC2C044D2EE01AE66DBE34_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	float V_1 = 0.0f;
	bool V_2 = false;
	bool V_3 = false;
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	int32_t V_6 = 0;
	NativeArray_1_tB723C353A73B34FE57C3B9EA16A02A466B268BC2 V_7;
	memset((&V_7), 0, sizeof(V_7));
	NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5 V_8;
	memset((&V_8), 0, sizeof(V_8));
	float V_9 = 0.0f;
	int32_t V_10 = 0;
	UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD V_11;
	memset((&V_11), 0, sizeof(V_11));
	int32_t V_12 = 0;
	int32_t V_13 = 0;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_14;
	memset((&V_14), 0, sizeof(V_14));
	int32_t V_15 = 0;
	float G_B3_0 = 0.0f;
	{
		float* L_0 = ___11_maxArea;
		*((float*)L_0) = (float)(0.0f);
		V_0 = (0.0f);
		V_1 = (0.0f);
		V_2 = (bool)0;
		V_3 = (bool)1;
		V_4 = 0;
		V_5 = (-1);
		int32_t* L_1 = ___4_pgPointCount;
		int32_t L_2 = *((int32_t*)L_1);
		V_6 = L_2;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_3 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxEdgeCount;
		int32_t L_4 = ___0_allocator;
		NativeArray_1__ctor_mCFEB37C6F648F756D9AC2C044D2EE01AE66DBE34((&V_7), L_3, L_4, 1, NativeArray_1__ctor_mCFEB37C6F648F756D9AC2C044D2EE01AE66DBE34_RuntimeMethod_var);
		int32_t L_5 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxTriangleCount;
		int32_t L_6 = ___0_allocator;
		NativeArray_1__ctor_m89F748542AF7065DD1BC4780E9A0E4F3D41073ED((&V_8), L_5, L_6, 1, NativeArray_1__ctor_m89F748542AF7065DD1BC4780E9A0E4F3D41073ED_RuntimeMethod_var);
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_7 = ___7_vertices;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_8 = (*(NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*)L_7);
		int32_t* L_9 = ___8_vertexCount;
		int32_t L_10 = *((int32_t*)L_9);
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_11 = ___9_indices;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_12 = (*(NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)L_11);
		int32_t* L_13 = ___10_indexCount;
		int32_t L_14 = *((int32_t*)L_13);
		float* L_15 = ___11_maxArea;
		ModuleHandle_BuildTriangles_m48C3ED6D6EEFF398B32541E7685F1332A0040BA6(L_8, L_10, L_12, L_14, (&V_8), (&V_4), L_15, (&V_1), (&V_0), NULL);
		float L_16 = ___1_factorArea;
		if ((!(((float)L_16) == ((float)(0.0f)))))
		{
			goto IL_006d;
		}
	}
	{
		float L_17 = ___1_factorArea;
		G_B3_0 = L_17;
		goto IL_007d;
	}

IL_006d:
	{
		float L_18 = ___1_factorArea;
		il2cpp_codegen_runtime_class_init_inline(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var);
		float L_19 = ((Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_StaticFields*)il2cpp_codegen_static_fields_for(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var))->___kMinAreaFactor;
		float L_20 = ((Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_StaticFields*)il2cpp_codegen_static_fields_for(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var))->___kMaxAreaFactor;
		float L_21;
		L_21 = math_clamp_mB7233FC9D6C27522014C4E6D4E056D36CE82C97E_inline(L_18, L_19, L_20, NULL);
		G_B3_0 = L_21;
	}

IL_007d:
	{
		___1_factorArea = G_B3_0;
		float* L_22 = ___11_maxArea;
		float L_23 = *((float*)L_22);
		float L_24 = ___1_factorArea;
		V_9 = ((float)il2cpp_codegen_multiply(L_23, L_24));
		float L_25 = V_9;
		float L_26 = ___2_targetArea;
		float L_27;
		L_27 = math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline(L_25, L_26, NULL);
		V_9 = L_27;
		goto IL_01b1;
	}

IL_0095:
	{
		V_10 = 0;
		goto IL_00b8;
	}

IL_009a:
	{
		int32_t L_28 = V_10;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_29;
		L_29 = IL2CPP_NATIVEARRAY_GET_ITEM(UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD, ((&V_8))->___m_Buffer, L_28);
		float L_30 = V_9;
		il2cpp_codegen_runtime_class_init_inline(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var);
		bool L_31;
		L_31 = Refinery_RequiresRefining_mE61A0BDBFE5757B48372A5AC578FEF6181C3A384(L_29, L_30, NULL);
		if (!L_31)
		{
			goto IL_00b2;
		}
	}
	{
		int32_t L_32 = V_10;
		V_5 = L_32;
		goto IL_00be;
	}

IL_00b2:
	{
		int32_t L_33 = V_10;
		V_10 = ((int32_t)il2cpp_codegen_add(L_33, 1));
	}

IL_00b8:
	{
		int32_t L_34 = V_10;
		int32_t L_35 = V_4;
		if ((((int32_t)L_34) < ((int32_t)L_35)))
		{
			goto IL_009a;
		}
	}

IL_00be:
	{
		int32_t L_36 = V_5;
		if ((((int32_t)L_36) == ((int32_t)(-1))))
		{
			goto IL_01af;
		}
	}
	{
		int32_t L_37 = V_5;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_38;
		L_38 = IL2CPP_NATIVEARRAY_GET_ITEM(UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD, ((&V_8))->___m_Buffer, L_37);
		V_11 = L_38;
		V_12 = 0;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_39 = ___3_pgPoints;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_40 = (*(NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*)L_39);
		int32_t* L_41 = ___4_pgPointCount;
		int32_t L_42 = *((int32_t*)L_41);
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_43 = ___5_pgEdges;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_44 = (*(NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)L_43);
		int32_t* L_45 = ___6_pgEdgeCount;
		int32_t L_46 = *((int32_t*)L_45);
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_47 = V_11;
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_48 = L_47.___c;
		il2cpp_codegen_runtime_class_init_inline(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var);
		Refinery_FetchEncroachedSegments_m75A2A73743DC464AA0A2F5D4119480D0063A4FFA(L_40, L_42, L_44, L_46, (&V_7), (&V_12), L_48, NULL);
		int32_t L_49 = V_12;
		if (!L_49)
		{
			goto IL_0123;
		}
	}
	{
		V_13 = 0;
		goto IL_011b;
	}

IL_0100:
	{
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_50 = ___3_pgPoints;
		int32_t* L_51 = ___4_pgPointCount;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_52 = ___5_pgEdges;
		int32_t* L_53 = ___6_pgEdgeCount;
		int32_t L_54 = V_13;
		UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA L_55;
		L_55 = IL2CPP_NATIVEARRAY_GET_ITEM(UEncroachingSegment_tD13983B03A27E74BB47A12B60732B020888416BA, ((&V_7))->___m_Buffer, L_54);
		il2cpp_codegen_runtime_class_init_inline(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var);
		Refinery_SplitSegments_m1B90CC5AE3456482287E24ECFB79F54C7CC1FE6A(L_50, L_51, L_52, L_53, L_55, NULL);
		int32_t L_56 = V_13;
		V_13 = ((int32_t)il2cpp_codegen_add(L_56, 1));
	}

IL_011b:
	{
		int32_t L_57 = V_13;
		int32_t L_58 = V_12;
		if ((((int32_t)L_57) < ((int32_t)L_58)))
		{
			goto IL_0100;
		}
	}
	{
		goto IL_0147;
	}

IL_0123:
	{
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_59 = V_11;
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_60 = L_59.___c;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_61 = L_60.___center;
		V_14 = L_61;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_62 = ___3_pgPoints;
		int32_t* L_63 = ___4_pgPointCount;
		int32_t* L_64 = ___4_pgPointCount;
		int32_t L_65 = *((int32_t*)L_64);
		V_15 = L_65;
		int32_t L_66 = V_15;
		*((int32_t*)L_63) = (int32_t)((int32_t)il2cpp_codegen_add(L_66, 1));
		int32_t L_67 = V_15;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_68 = V_14;
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_62)->___m_Buffer, L_67, (L_68));
	}

IL_0147:
	{
		int32_t* L_69 = ___10_indexCount;
		*((int32_t*)L_69) = (int32_t)0;
		int32_t* L_70 = ___8_vertexCount;
		*((int32_t*)L_70) = (int32_t)0;
		int32_t L_71 = ___0_allocator;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_72 = ___3_pgPoints;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_73 = (*(NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*)L_72);
		int32_t* L_74 = ___4_pgPointCount;
		int32_t L_75 = *((int32_t*)L_74);
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_76 = ___5_pgEdges;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_77 = (*(NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)L_76);
		int32_t* L_78 = ___6_pgEdgeCount;
		int32_t L_79 = *((int32_t*)L_78);
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_80 = ___7_vertices;
		int32_t* L_81 = ___8_vertexCount;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_82 = ___9_indices;
		int32_t* L_83 = ___10_indexCount;
		bool L_84;
		L_84 = Tessellator_Tessellate_m84DB7B38E7EC9AB5155F7EEDBC3382CF1092EC5E(L_71, L_73, L_75, L_77, L_79, L_80, L_81, L_82, L_83, NULL);
		V_3 = L_84;
		V_12 = 0;
		V_4 = 0;
		V_5 = (-1);
		bool L_85 = V_3;
		if (!L_85)
		{
			goto IL_01a0;
		}
	}
	{
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_86 = ___7_vertices;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_87 = (*(NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*)L_86);
		int32_t* L_88 = ___8_vertexCount;
		int32_t L_89 = *((int32_t*)L_88);
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_90 = ___9_indices;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_91 = (*(NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)L_90);
		int32_t* L_92 = ___10_indexCount;
		int32_t L_93 = *((int32_t*)L_92);
		float* L_94 = ___11_maxArea;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_BuildTriangles_m48C3ED6D6EEFF398B32541E7685F1332A0040BA6(L_87, L_89, L_91, L_93, (&V_8), (&V_4), L_94, (&V_1), (&V_0), NULL);
	}

IL_01a0:
	{
		int32_t* L_95 = ___4_pgPointCount;
		int32_t L_96 = *((int32_t*)L_95);
		int32_t L_97 = V_6;
		il2cpp_codegen_runtime_class_init_inline(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var);
		int32_t L_98 = ((Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_StaticFields*)il2cpp_codegen_static_fields_for(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var))->___kMaxSteinerCount;
		if ((((int32_t)((int32_t)il2cpp_codegen_subtract(L_96, L_97))) <= ((int32_t)L_98)))
		{
			goto IL_01b1;
		}
	}
	{
		goto IL_01bc;
	}

IL_01af:
	{
		V_2 = (bool)1;
	}

IL_01b1:
	{
		bool L_99 = V_2;
		bool L_100 = V_3;
		if (((int32_t)(((((int32_t)L_99) == ((int32_t)0))? 1 : 0)&(int32_t)L_100)))
		{
			goto IL_0095;
		}
	}

IL_01bc:
	{
		NativeArray_1_Dispose_mB48AC20750ECFD2702E0F9915B2177D044D15C58((&V_8), NativeArray_1_Dispose_mB48AC20750ECFD2702E0F9915B2177D044D15C58_RuntimeMethod_var);
		NativeArray_1_Dispose_m2FC0457FE238F347CEF96BDA77BA875179E5704B((&V_7), NativeArray_1_Dispose_m2FC0457FE238F347CEF96BDA77BA875179E5704B_RuntimeMethod_var);
		bool L_101 = V_2;
		return L_101;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Refinery__cctor_mD0D275A7B24F2E73CE3EEFB61DBBC6F59AF4ED3A (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		((Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_StaticFields*)il2cpp_codegen_static_fields_for(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var))->___kMinAreaFactor = (0.0482000001f);
		((Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_StaticFields*)il2cpp_codegen_static_fields_for(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var))->___kMaxAreaFactor = (0.481999993f);
		((Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_StaticFields*)il2cpp_codegen_static_fields_for(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var))->___kMaxSteinerCount = ((int32_t)4084);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Smoothen_RefineEdges_mEB354A7F15520AD45BE59B6C3322FC28698806DB (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* ___0_refinedEdges, NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* ___1_delaEdges, int32_t* ___2_delaEdgeCount, NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* ___3_voronoiEdges, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_Copy_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mE623C4A9806A975DC543E10F18CD15CADCD6D02F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int4_tBA77D4945786DE82C3A487B33955EA1004996052 V_2;
	memset((&V_2), 0, sizeof(V_2));
	int4_tBA77D4945786DE82C3A487B33955EA1004996052 V_3;
	memset((&V_3), 0, sizeof(V_3));
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	int32_t V_6 = 0;
	int32_t V_7 = 0;
	int4_tBA77D4945786DE82C3A487B33955EA1004996052 V_8;
	memset((&V_8), 0, sizeof(V_8));
	{
		int32_t* L_0 = ___2_delaEdgeCount;
		int32_t L_1 = *((int32_t*)L_0);
		V_0 = L_1;
		int32_t* L_2 = ___2_delaEdgeCount;
		*((int32_t*)L_2) = (int32_t)0;
		V_1 = 0;
		goto IL_0060;
	}

IL_000a:
	{
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_3 = ___1_delaEdges;
		int32_t L_4 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_5;
		L_5 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_3)->___m_Buffer, L_4);
		V_2 = L_5;
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_6 = ___1_delaEdges;
		int32_t L_7 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_8;
		L_8 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_6)->___m_Buffer, ((int32_t)il2cpp_codegen_add(L_7, 1)));
		V_3 = L_8;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_9 = V_2;
		int32_t L_10 = L_9.___x;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_11 = V_3;
		int32_t L_12 = L_11.___x;
		if ((!(((uint32_t)L_10) == ((uint32_t)L_12))))
		{
			goto IL_0049;
		}
	}
	{
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_13 = V_2;
		int32_t L_14 = L_13.___y;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_15 = V_3;
		int32_t L_16 = L_15.___y;
		if ((!(((uint32_t)L_14) == ((uint32_t)L_16))))
		{
			goto IL_0049;
		}
	}
	{
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_17 = V_3;
		int32_t L_18 = L_17.___z;
		(&V_2)->___w = L_18;
		int32_t L_19 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_19, 1));
	}

IL_0049:
	{
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_20 = ___0_refinedEdges;
		int32_t* L_21 = ___2_delaEdgeCount;
		int32_t* L_22 = ___2_delaEdgeCount;
		int32_t L_23 = *((int32_t*)L_22);
		V_4 = L_23;
		int32_t L_24 = V_4;
		*((int32_t*)L_21) = (int32_t)((int32_t)il2cpp_codegen_add(L_24, 1));
		int32_t L_25 = V_4;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_26 = V_2;
		IL2CPP_NATIVEARRAY_SET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_20)->___m_Buffer, L_25, (L_26));
		int32_t L_27 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_27, 1));
	}

IL_0060:
	{
		int32_t L_28 = V_1;
		int32_t L_29 = V_0;
		if ((((int32_t)L_28) < ((int32_t)((int32_t)il2cpp_codegen_subtract(L_29, 1)))))
		{
			goto IL_000a;
		}
	}
	{
		V_5 = 0;
		goto IL_00b1;
	}

IL_006b:
	{
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_30 = ___0_refinedEdges;
		int32_t L_31 = V_5;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_32;
		L_32 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_30)->___m_Buffer, L_31);
		int32_t L_33 = L_32.___z;
		V_6 = L_33;
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_34 = ___0_refinedEdges;
		int32_t L_35 = V_5;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_36;
		L_36 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_34)->___m_Buffer, L_35);
		int32_t L_37 = L_36.___w;
		V_7 = L_37;
		int32_t L_38 = V_6;
		if ((((int32_t)L_38) == ((int32_t)(-1))))
		{
			goto IL_00ab;
		}
	}
	{
		int32_t L_39 = V_7;
		if ((((int32_t)L_39) == ((int32_t)(-1))))
		{
			goto IL_00ab;
		}
	}
	{
		int32_t L_40 = V_7;
		int32_t L_41 = V_6;
		int32_t L_42 = V_5;
		int4__ctor_m4E8D71A09721E26F7FCCE82EA8AD699062EE6216_inline((&V_8), L_40, L_41, L_42, 0, NULL);
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_43 = ___3_voronoiEdges;
		int32_t L_44 = V_5;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_45 = V_8;
		IL2CPP_NATIVEARRAY_SET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_43)->___m_Buffer, L_44, (L_45));
	}

IL_00ab:
	{
		int32_t L_46 = V_5;
		V_5 = ((int32_t)il2cpp_codegen_add(L_46, 1));
	}

IL_00b1:
	{
		int32_t L_47 = V_5;
		int32_t* L_48 = ___2_delaEdgeCount;
		int32_t L_49 = *((int32_t*)L_48);
		if ((((int32_t)L_47) < ((int32_t)L_49)))
		{
			goto IL_006b;
		}
	}
	{
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_50 = ___0_refinedEdges;
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 L_51 = (*(NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200*)L_50);
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_52 = ___1_delaEdges;
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 L_53 = (*(NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200*)L_52);
		int32_t* L_54 = ___2_delaEdgeCount;
		int32_t L_55 = *((int32_t*)L_54);
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_Copy_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mE623C4A9806A975DC543E10F18CD15CADCD6D02F(L_51, L_53, L_55, ModuleHandle_Copy_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mE623C4A9806A975DC543E10F18CD15CADCD6D02F_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Smoothen_GetAffectingEdges_mB3CBA0BB5CDA1557F68AC90C66236BA22FA02091 (int32_t ___0_pointIndex, NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 ___1_edges, int32_t ___2_edgeCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___3_resultSet, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___4_checkSet, int32_t* ___5_resultCount, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	{
		int32_t* L_0 = ___5_resultCount;
		*((int32_t*)L_0) = (int32_t)0;
		V_0 = 0;
		goto IL_0047;
	}

IL_0008:
	{
		int32_t L_1 = ___0_pointIndex;
		int32_t L_2 = V_0;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_3;
		L_3 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___1_edges))->___m_Buffer, L_2);
		int32_t L_4 = L_3.___x;
		if ((((int32_t)L_1) == ((int32_t)L_4)))
		{
			goto IL_0028;
		}
	}
	{
		int32_t L_5 = ___0_pointIndex;
		int32_t L_6 = V_0;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_7;
		L_7 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___1_edges))->___m_Buffer, L_6);
		int32_t L_8 = L_7.___y;
		if ((!(((uint32_t)L_5) == ((uint32_t)L_8))))
		{
			goto IL_003a;
		}
	}

IL_0028:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_9 = ___3_resultSet;
		int32_t* L_10 = ___5_resultCount;
		int32_t* L_11 = ___5_resultCount;
		int32_t L_12 = *((int32_t*)L_11);
		V_1 = L_12;
		int32_t L_13 = V_1;
		*((int32_t*)L_10) = (int32_t)((int32_t)il2cpp_codegen_add(L_13, 1));
		int32_t L_14 = V_1;
		int32_t L_15 = V_0;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_9)->___m_Buffer, L_14, (L_15));
	}

IL_003a:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_16 = ___4_checkSet;
		int32_t L_17 = V_0;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_16)->___m_Buffer, L_17, (0));
		int32_t L_18 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_18, 1));
	}

IL_0047:
	{
		int32_t L_19 = V_0;
		int32_t L_20 = ___2_edgeCount;
		if ((((int32_t)L_19) < ((int32_t)L_20)))
		{
			goto IL_0008;
		}
	}
	{
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Smoothen_CentroidByPoints_mD028977D02C3C13514E45F83D433B29A5B9BD338 (int32_t ___0_triIndex, NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5 ___1_triangles, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___2_centroidTris, int32_t* ___3_centroidCount, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* ___4_aggregate, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* ___5_point, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	{
		V_0 = 0;
		goto IL_0013;
	}

IL_0004:
	{
		int32_t L_0 = ___0_triIndex;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_1 = ___2_centroidTris;
		int32_t L_2 = V_0;
		int32_t L_3;
		L_3 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_1)->___m_Buffer, L_2);
		if ((!(((uint32_t)L_0) == ((uint32_t)L_3))))
		{
			goto IL_000f;
		}
	}
	{
		return;
	}

IL_000f:
	{
		int32_t L_4 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_4, 1));
	}

IL_0013:
	{
		int32_t L_5 = V_0;
		int32_t* L_6 = ___3_centroidCount;
		int32_t L_7 = *((int32_t*)L_6);
		if ((((int32_t)L_5) < ((int32_t)L_7)))
		{
			goto IL_0004;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_8 = ___2_centroidTris;
		int32_t* L_9 = ___3_centroidCount;
		int32_t* L_10 = ___3_centroidCount;
		int32_t L_11 = *((int32_t*)L_10);
		V_1 = L_11;
		int32_t L_12 = V_1;
		*((int32_t*)L_9) = (int32_t)((int32_t)il2cpp_codegen_add(L_12, 1));
		int32_t L_13 = V_1;
		int32_t L_14 = ___0_triIndex;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_8)->___m_Buffer, L_13, (L_14));
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_15 = ___4_aggregate;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_16 = ___4_aggregate;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_17 = (*(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*)L_16);
		int32_t L_18 = ___0_triIndex;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_19;
		L_19 = IL2CPP_NATIVEARRAY_GET_ITEM(UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD, ((&___1_triangles))->___m_Buffer, L_18);
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_20 = L_19.___c;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_21 = L_20.___center;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_22;
		L_22 = float2_op_Addition_m718974663A956F64D7C45D06C088550637F13693_inline(L_17, L_21, NULL);
		*(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*)L_15 = L_22;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_23 = ___5_point;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_24 = ___4_aggregate;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_25 = (*(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*)L_24);
		int32_t* L_26 = ___3_centroidCount;
		int32_t L_27 = *((int32_t*)L_26);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_28;
		L_28 = float2_op_Division_m4AA175CD0895AA1A50F5A73B54722CA53876EE6A_inline(L_25, ((float)L_27), NULL);
		*(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*)L_23 = L_28;
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Smoothen_CentroidByPolygon_m6111FE65A4B6D4F26D6C2920E2575094C8157533 (int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___0_e, NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5 ___1_triangles, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* ___2_centroid, float* ___3_area, float* ___4_distance, const RuntimeMethod* method) 
{
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_0;
	memset((&V_0), 0, sizeof(V_0));
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_1;
	memset((&V_1), 0, sizeof(V_1));
	float V_2 = 0.0f;
	{
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_0 = ___0_e;
		int32_t L_1 = L_0.___x;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_2;
		L_2 = IL2CPP_NATIVEARRAY_GET_ITEM(UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD, ((&___1_triangles))->___m_Buffer, L_1);
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_3 = L_2.___c;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = L_3.___center;
		V_0 = L_4;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_5 = ___0_e;
		int32_t L_6 = L_5.___y;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_7;
		L_7 = IL2CPP_NATIVEARRAY_GET_ITEM(UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD, ((&___1_triangles))->___m_Buffer, L_6);
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_8 = L_7.___c;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_9 = L_8.___center;
		V_1 = L_9;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_10 = V_0;
		float L_11 = L_10.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_12 = V_1;
		float L_13 = L_12.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_14 = V_1;
		float L_15 = L_14.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_16 = V_0;
		float L_17 = L_16.___y;
		V_2 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_multiply(L_11, L_13)), ((float)il2cpp_codegen_multiply(L_15, L_17))));
		float* L_18 = ___4_distance;
		float* L_19 = ___4_distance;
		float L_20 = *((float*)L_19);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_21 = V_0;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_22 = V_1;
		float L_23;
		L_23 = math_distance_mE5E0FFDD103E710A4CB23360BFCAFD0AF2E1EFA9_inline(L_21, L_22, NULL);
		*((float*)L_18) = (float)((float)il2cpp_codegen_add(L_20, L_23));
		float* L_24 = ___3_area;
		float* L_25 = ___3_area;
		float L_26 = *((float*)L_25);
		float L_27 = V_2;
		*((float*)L_24) = (float)((float)il2cpp_codegen_add(L_26, L_27));
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_28 = ___2_centroid;
		float* L_29 = (float*)(&L_28->___x);
		float* L_30 = L_29;
		float L_31 = *((float*)L_30);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_32 = V_1;
		float L_33 = L_32.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_34 = V_0;
		float L_35 = L_34.___x;
		float L_36 = V_2;
		*((float*)L_30) = (float)((float)il2cpp_codegen_add(L_31, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_33, L_35)), L_36))));
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_37 = ___2_centroid;
		float* L_38 = (float*)(&L_37->___y);
		float* L_39 = L_38;
		float L_40 = *((float*)L_39);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_41 = V_1;
		float L_42 = L_41.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_43 = V_0;
		float L_44 = L_43.___y;
		float L_45 = V_2;
		*((float*)L_39) = (float)((float)il2cpp_codegen_add(L_40, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add(L_42, L_44)), L_45))));
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Smoothen_ConnectTriangles_m727034BB01BA926D7D5DBC1AAD81342CB5D8B26F (NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* ___0_connectedTri, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___1_affectEdges, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___2_checkSet, NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 ___3_voronoiEdges, int32_t ___4_triangleCount, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	bool V_3 = false;
	int32_t V_4 = 0;
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_0 = ___1_affectEdges;
		int32_t L_1;
		L_1 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_0)->___m_Buffer, 0);
		V_0 = L_1;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_2 = ___1_affectEdges;
		int32_t L_3;
		L_3 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_2)->___m_Buffer, 0);
		V_1 = L_3;
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_4 = ___0_connectedTri;
		int32_t L_5 = V_0;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_6;
		L_6 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_5);
		int32_t L_7 = L_6.___x;
		int32_t L_8 = V_0;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_9;
		L_9 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_8);
		int32_t L_10 = L_9.___y;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_11;
		memset((&L_11), 0, sizeof(L_11));
		int4__ctor_m4E8D71A09721E26F7FCCE82EA8AD699062EE6216_inline((&L_11), L_7, L_10, 0, 0, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_4)->___m_Buffer, 0, (L_11));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_12 = ___2_checkSet;
		int32_t L_13 = V_1;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_12)->___m_Buffer, L_13, (1));
		V_2 = 1;
		goto IL_01d9;
	}

IL_0047:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_14 = ___1_affectEdges;
		int32_t L_15 = V_2;
		int32_t L_16;
		L_16 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_14)->___m_Buffer, L_15);
		V_1 = L_16;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_17 = ___2_checkSet;
		int32_t L_18 = V_1;
		int32_t L_19;
		L_19 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_17)->___m_Buffer, L_18);
		if (L_19)
		{
			goto IL_00ff;
		}
	}
	{
		int32_t L_20 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_21;
		L_21 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_20);
		int32_t L_22 = L_21.___x;
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_23 = ___0_connectedTri;
		int32_t L_24 = V_2;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_25;
		L_25 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_23)->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_24, 1)));
		int32_t L_26 = L_25.___y;
		if ((!(((uint32_t)L_22) == ((uint32_t)L_26))))
		{
			goto IL_00ad;
		}
	}
	{
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_27 = ___0_connectedTri;
		int32_t L_28 = V_2;
		int32_t L_29 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_30;
		L_30 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_29);
		int32_t L_31 = L_30.___x;
		int32_t L_32 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_33;
		L_33 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_32);
		int32_t L_34 = L_33.___y;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_35;
		memset((&L_35), 0, sizeof(L_35));
		int4__ctor_m4E8D71A09721E26F7FCCE82EA8AD699062EE6216_inline((&L_35), L_31, L_34, 0, 0, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_27)->___m_Buffer, L_28, (L_35));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_36 = ___2_checkSet;
		int32_t L_37 = V_1;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_36)->___m_Buffer, L_37, (1));
		goto IL_01d5;
	}

IL_00ad:
	{
		int32_t L_38 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_39;
		L_39 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_38);
		int32_t L_40 = L_39.___y;
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_41 = ___0_connectedTri;
		int32_t L_42 = V_2;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_43;
		L_43 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_41)->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_42, 1)));
		int32_t L_44 = L_43.___y;
		if ((!(((uint32_t)L_40) == ((uint32_t)L_44))))
		{
			goto IL_00ff;
		}
	}
	{
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_45 = ___0_connectedTri;
		int32_t L_46 = V_2;
		int32_t L_47 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_48;
		L_48 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_47);
		int32_t L_49 = L_48.___y;
		int32_t L_50 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_51;
		L_51 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_50);
		int32_t L_52 = L_51.___x;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_53;
		memset((&L_53), 0, sizeof(L_53));
		int4__ctor_m4E8D71A09721E26F7FCCE82EA8AD699062EE6216_inline((&L_53), L_49, L_52, 0, 0, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_45)->___m_Buffer, L_46, (L_53));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_54 = ___2_checkSet;
		int32_t L_55 = V_1;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_54)->___m_Buffer, L_55, (1));
		goto IL_01d5;
	}

IL_00ff:
	{
		V_3 = (bool)0;
		V_4 = 0;
		goto IL_01c7;
	}

IL_0109:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_56 = ___1_affectEdges;
		int32_t L_57 = V_4;
		int32_t L_58;
		L_58 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_56)->___m_Buffer, L_57);
		V_1 = L_58;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_59 = ___2_checkSet;
		int32_t L_60 = V_1;
		int32_t L_61;
		L_61 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_59)->___m_Buffer, L_60);
		if ((((int32_t)L_61) == ((int32_t)1)))
		{
			goto IL_01c1;
		}
	}
	{
		int32_t L_62 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_63;
		L_63 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_62);
		int32_t L_64 = L_63.___x;
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_65 = ___0_connectedTri;
		int32_t L_66 = V_2;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_67;
		L_67 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_65)->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_66, 1)));
		int32_t L_68 = L_67.___y;
		if ((!(((uint32_t)L_64) == ((uint32_t)L_68))))
		{
			goto IL_0170;
		}
	}
	{
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_69 = ___0_connectedTri;
		int32_t L_70 = V_2;
		int32_t L_71 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_72;
		L_72 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_71);
		int32_t L_73 = L_72.___x;
		int32_t L_74 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_75;
		L_75 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_74);
		int32_t L_76 = L_75.___y;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_77;
		memset((&L_77), 0, sizeof(L_77));
		int4__ctor_m4E8D71A09721E26F7FCCE82EA8AD699062EE6216_inline((&L_77), L_73, L_76, 0, 0, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_69)->___m_Buffer, L_70, (L_77));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_78 = ___2_checkSet;
		int32_t L_79 = V_1;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_78)->___m_Buffer, L_79, (1));
		V_3 = (bool)1;
		goto IL_01d0;
	}

IL_0170:
	{
		int32_t L_80 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_81;
		L_81 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_80);
		int32_t L_82 = L_81.___y;
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_83 = ___0_connectedTri;
		int32_t L_84 = V_2;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_85;
		L_85 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_83)->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_84, 1)));
		int32_t L_86 = L_85.___y;
		if ((!(((uint32_t)L_82) == ((uint32_t)L_86))))
		{
			goto IL_01c1;
		}
	}
	{
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_87 = ___0_connectedTri;
		int32_t L_88 = V_2;
		int32_t L_89 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_90;
		L_90 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_89);
		int32_t L_91 = L_90.___y;
		int32_t L_92 = V_1;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_93;
		L_93 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&___3_voronoiEdges))->___m_Buffer, L_92);
		int32_t L_94 = L_93.___x;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_95;
		memset((&L_95), 0, sizeof(L_95));
		int4__ctor_m4E8D71A09721E26F7FCCE82EA8AD699062EE6216_inline((&L_95), L_91, L_94, 0, 0, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_87)->___m_Buffer, L_88, (L_95));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_96 = ___2_checkSet;
		int32_t L_97 = V_1;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_96)->___m_Buffer, L_97, (1));
		V_3 = (bool)1;
		goto IL_01d0;
	}

IL_01c1:
	{
		int32_t L_98 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_add(L_98, 1));
	}

IL_01c7:
	{
		int32_t L_99 = V_4;
		int32_t L_100 = ___4_triangleCount;
		if ((((int32_t)L_99) < ((int32_t)L_100)))
		{
			goto IL_0109;
		}
	}

IL_01d0:
	{
		bool L_101 = V_3;
		if (L_101)
		{
			goto IL_01d5;
		}
	}
	{
		return (bool)0;
	}

IL_01d5:
	{
		int32_t L_102 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add(L_102, 1));
	}

IL_01d9:
	{
		int32_t L_103 = V_2;
		int32_t L_104 = ___4_triangleCount;
		if ((((int32_t)L_103) < ((int32_t)L_104)))
		{
			goto IL_0047;
		}
	}
	{
		return (bool)1;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Smoothen_Condition_m831A479BB846A668D896E06A2737129629F3DFC2 (int32_t ___0_allocator, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___1_pgPoints, int32_t ___2_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___3_pgEdges, int32_t ___4_pgEdgeCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___5_vertices, int32_t* ___6_vertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___7_indices, int32_t* ___8_indexCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_InsertionSort_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_TisDelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B_m18BA196C639121F5500845FA59E90F34DB272028_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mB537AB040DF35BD6BE8FEBE48C04901884E592E3_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m38861384F84F1CD89A47D663C29D3ED425C5CCE0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_mB48AC20750ECFD2702E0F9915B2177D044D15C58_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_m89F748542AF7065DD1BC4780E9A0E4F3D41073ED_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mC01F44D62CB455BB4FE045F1FFB6BBD3516CB265_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	float V_1 = 0.0f;
	float V_2 = 0.0f;
	float V_3 = 0.0f;
	float V_4 = 0.0f;
	float V_5 = 0.0f;
	float V_6 = 0.0f;
	float V_7 = 0.0f;
	bool V_8 = false;
	bool V_9 = false;
	int32_t V_10 = 0;
	int32_t V_11 = 0;
	int32_t V_12 = 0;
	NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5 V_13;
	memset((&V_13), 0, sizeof(V_13));
	NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 V_14;
	memset((&V_14), 0, sizeof(V_14));
	NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 V_15;
	memset((&V_15), 0, sizeof(V_15));
	NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 V_16;
	memset((&V_16), 0, sizeof(V_16));
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C V_17;
	memset((&V_17), 0, sizeof(V_17));
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C V_18;
	memset((&V_18), 0, sizeof(V_18));
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C V_19;
	memset((&V_19), 0, sizeof(V_19));
	NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 V_20;
	memset((&V_20), 0, sizeof(V_20));
	int32_t V_21 = 0;
	int32_t V_22 = 0;
	DelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B V_23;
	memset((&V_23), 0, sizeof(V_23));
	int32_t V_24 = 0;
	bool V_25 = false;
	int32_t V_26 = 0;
	int32_t V_27 = 0;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_28;
	memset((&V_28), 0, sizeof(V_28));
	float V_29 = 0.0f;
	float V_30 = 0.0f;
	int32_t V_31 = 0;
	int32_t G_B22_0 = 0;
	{
		V_0 = (0.0f);
		V_1 = (0.0f);
		V_2 = (0.0f);
		V_3 = (0.0f);
		V_4 = (0.0f);
		V_5 = (0.0f);
		V_6 = (0.0f);
		V_7 = (0.0f);
		V_8 = (bool)1;
		V_9 = (bool)1;
		V_10 = 0;
		V_11 = 0;
		V_12 = 0;
		int32_t* L_0 = ___8_indexCount;
		int32_t L_1 = *((int32_t*)L_0);
		int32_t L_2 = ___0_allocator;
		NativeArray_1__ctor_m89F748542AF7065DD1BC4780E9A0E4F3D41073ED((&V_13), L_1, L_2, 1, NativeArray_1__ctor_m89F748542AF7065DD1BC4780E9A0E4F3D41073ED_RuntimeMethod_var);
		int32_t* L_3 = ___8_indexCount;
		int32_t L_4 = *((int32_t*)L_3);
		int32_t L_5 = ___0_allocator;
		NativeArray_1__ctor_mC01F44D62CB455BB4FE045F1FFB6BBD3516CB265((&V_14), L_4, L_5, 1, NativeArray_1__ctor_mC01F44D62CB455BB4FE045F1FFB6BBD3516CB265_RuntimeMethod_var);
		int32_t* L_6 = ___8_indexCount;
		int32_t L_7 = *((int32_t*)L_6);
		int32_t L_8 = ___0_allocator;
		NativeArray_1__ctor_mC01F44D62CB455BB4FE045F1FFB6BBD3516CB265((&V_15), L_7, L_8, 1, NativeArray_1__ctor_mC01F44D62CB455BB4FE045F1FFB6BBD3516CB265_RuntimeMethod_var);
		int32_t* L_9 = ___6_vertexCount;
		int32_t L_10 = *((int32_t*)L_9);
		int32_t L_11 = ___0_allocator;
		NativeArray_1__ctor_mC01F44D62CB455BB4FE045F1FFB6BBD3516CB265((&V_16), L_10, L_11, 1, NativeArray_1__ctor_mC01F44D62CB455BB4FE045F1FFB6BBD3516CB265_RuntimeMethod_var);
		int32_t* L_12 = ___8_indexCount;
		int32_t L_13 = *((int32_t*)L_12);
		int32_t L_14 = ___0_allocator;
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&V_17), L_13, L_14, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		int32_t* L_15 = ___8_indexCount;
		int32_t L_16 = *((int32_t*)L_15);
		int32_t L_17 = ___0_allocator;
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&V_18), L_16, L_17, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		int32_t* L_18 = ___6_vertexCount;
		int32_t L_19 = *((int32_t*)L_18);
		int32_t L_20 = ___0_allocator;
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&V_19), L_19, L_20, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_21 = ___5_vertices;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_22 = (*(NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*)L_21);
		int32_t* L_23 = ___6_vertexCount;
		int32_t L_24 = *((int32_t*)L_23);
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_25 = ___7_indices;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_26 = (*(NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)L_25);
		int32_t* L_27 = ___8_indexCount;
		int32_t L_28 = *((int32_t*)L_27);
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_BuildTrianglesAndEdges_m902E978EB29E4C37FCA0B80D66E30B677CADDD31(L_22, L_24, L_26, L_28, (&V_13), (&V_10), (&V_14), (&V_11), (&V_0), (&V_4), (&V_2), NULL);
		int32_t L_29 = V_11;
		int32_t L_30 = ___0_allocator;
		NativeArray_1__ctor_mC01F44D62CB455BB4FE045F1FFB6BBD3516CB265((&V_20), L_29, L_30, 1, NativeArray_1__ctor_mC01F44D62CB455BB4FE045F1FFB6BBD3516CB265_RuntimeMethod_var);
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 L_31 = V_14;
		void* L_32;
		L_32 = NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mB537AB040DF35BD6BE8FEBE48C04901884E592E3(L_31, NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_mB537AB040DF35BD6BE8FEBE48C04901884E592E3_RuntimeMethod_var);
		int32_t L_33 = V_11;
		il2cpp_codegen_initobj((&V_23), sizeof(DelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B));
		DelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B L_34 = V_23;
		ModuleHandle_InsertionSort_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_TisDelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B_m18BA196C639121F5500845FA59E90F34DB272028(L_32, 0, ((int32_t)il2cpp_codegen_subtract(L_33, 1)), L_34, ModuleHandle_InsertionSort_Tisint4_tBA77D4945786DE82C3A487B33955EA1004996052_TisDelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B_m18BA196C639121F5500845FA59E90F34DB272028_RuntimeMethod_var);
		il2cpp_codegen_runtime_class_init_inline(Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var);
		Smoothen_RefineEdges_mEB354A7F15520AD45BE59B6C3322FC28698806DB((&V_20), (&V_14), (&V_11), (&V_15), NULL);
		V_24 = 0;
		goto IL_01ca;
	}

IL_00f9:
	{
		int32_t L_35 = V_24;
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 L_36 = V_14;
		int32_t L_37 = V_11;
		il2cpp_codegen_runtime_class_init_inline(Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var);
		Smoothen_GetAffectingEdges_mB3CBA0BB5CDA1557F68AC90C66236BA22FA02091(L_35, L_36, L_37, (&V_18), (&V_17), (&V_12), NULL);
		int32_t L_38 = V_12;
		V_25 = (bool)((!(((uint32_t)L_38) <= ((uint32_t)0)))? 1 : 0);
		V_26 = 0;
		goto IL_014e;
	}

IL_0116:
	{
		int32_t L_39 = V_26;
		int32_t L_40;
		L_40 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&V_18))->___m_Buffer, L_39);
		V_27 = L_40;
		int32_t L_41 = V_27;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_42;
		L_42 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&V_14))->___m_Buffer, L_41);
		int32_t L_43 = L_42.___z;
		if ((((int32_t)L_43) == ((int32_t)(-1))))
		{
			goto IL_0143;
		}
	}
	{
		int32_t L_44 = V_27;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_45;
		L_45 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&V_14))->___m_Buffer, L_44);
		int32_t L_46 = L_45.___w;
		if ((!(((uint32_t)L_46) == ((uint32_t)(-1)))))
		{
			goto IL_0148;
		}
	}

IL_0143:
	{
		V_25 = (bool)0;
		goto IL_0154;
	}

IL_0148:
	{
		int32_t L_47 = V_26;
		V_26 = ((int32_t)il2cpp_codegen_add(L_47, 1));
	}

IL_014e:
	{
		int32_t L_48 = V_26;
		int32_t L_49 = V_12;
		if ((((int32_t)L_48) < ((int32_t)L_49)))
		{
			goto IL_0116;
		}
	}

IL_0154:
	{
		bool L_50 = V_25;
		if (!L_50)
		{
			goto IL_01c4;
		}
	}
	{
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200 L_51 = V_15;
		int32_t L_52 = V_12;
		il2cpp_codegen_runtime_class_init_inline(Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var);
		bool L_53;
		L_53 = Smoothen_ConnectTriangles_m727034BB01BA926D7D5DBC1AAD81342CB5D8B26F((&V_16), (&V_18), (&V_17), L_51, L_52, NULL);
		V_8 = L_53;
		bool L_54 = V_8;
		if (!L_54)
		{
			goto IL_01d4;
		}
	}
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_55 = ((float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_StaticFields*)il2cpp_codegen_static_fields_for(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_il2cpp_TypeInfo_var))->___zero;
		V_28 = L_55;
		V_29 = (0.0f);
		V_30 = (0.0f);
		V_31 = 0;
		goto IL_01a3;
	}

IL_0187:
	{
		int32_t L_56 = V_31;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_57;
		L_57 = IL2CPP_NATIVEARRAY_GET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, ((&V_16))->___m_Buffer, L_56);
		NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5 L_58 = V_13;
		il2cpp_codegen_runtime_class_init_inline(Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var);
		Smoothen_CentroidByPolygon_m6111FE65A4B6D4F26D6C2920E2575094C8157533(L_57, L_58, (&V_28), (&V_29), (&V_30), NULL);
		int32_t L_59 = V_31;
		V_31 = ((int32_t)il2cpp_codegen_add(L_59, 1));
	}

IL_01a3:
	{
		int32_t L_60 = V_31;
		int32_t L_61 = V_12;
		if ((((int32_t)L_60) < ((int32_t)L_61)))
		{
			goto IL_0187;
		}
	}
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_62 = V_28;
		float L_63 = V_29;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_64;
		L_64 = float2_op_Division_m4AA175CD0895AA1A50F5A73B54722CA53876EE6A_inline(L_62, ((float)il2cpp_codegen_multiply((3.0f), L_63)), NULL);
		V_28 = L_64;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_65 = ___1_pgPoints;
		int32_t L_66 = V_24;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_67 = V_28;
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_65)->___m_Buffer, L_66, (L_67));
	}

IL_01c4:
	{
		int32_t L_68 = V_24;
		V_24 = ((int32_t)il2cpp_codegen_add(L_68, 1));
	}

IL_01ca:
	{
		int32_t L_69 = V_24;
		int32_t* L_70 = ___6_vertexCount;
		int32_t L_71 = *((int32_t*)L_70);
		if ((((int32_t)L_69) < ((int32_t)L_71)))
		{
			goto IL_00f9;
		}
	}

IL_01d4:
	{
		int32_t* L_72 = ___8_indexCount;
		int32_t L_73 = *((int32_t*)L_72);
		V_21 = L_73;
		int32_t* L_74 = ___6_vertexCount;
		int32_t L_75 = *((int32_t*)L_74);
		V_22 = L_75;
		int32_t* L_76 = ___8_indexCount;
		*((int32_t*)L_76) = (int32_t)0;
		int32_t* L_77 = ___6_vertexCount;
		*((int32_t*)L_77) = (int32_t)0;
		V_10 = 0;
		bool L_78 = V_8;
		if (!L_78)
		{
			goto IL_0253;
		}
	}
	{
		int32_t L_79 = ___0_allocator;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_80 = ___1_pgPoints;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_81 = (*(NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*)L_80);
		int32_t L_82 = ___2_pgPointCount;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_83 = ___3_pgEdges;
		int32_t L_84 = ___4_pgEdgeCount;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_85 = ___5_vertices;
		int32_t* L_86 = ___6_vertexCount;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_87 = ___7_indices;
		int32_t* L_88 = ___8_indexCount;
		bool L_89;
		L_89 = Tessellator_Tessellate_m84DB7B38E7EC9AB5155F7EEDBC3382CF1092EC5E(L_79, L_81, L_82, L_83, L_84, L_85, L_86, L_87, L_88, NULL);
		V_9 = L_89;
		bool L_90 = V_9;
		if (!L_90)
		{
			goto IL_0234;
		}
	}
	{
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_91 = ___5_vertices;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_92 = (*(NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*)L_91);
		int32_t* L_93 = ___6_vertexCount;
		int32_t L_94 = *((int32_t*)L_93);
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_95 = ___7_indices;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_96 = (*(NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)L_95);
		int32_t* L_97 = ___8_indexCount;
		int32_t L_98 = *((int32_t*)L_97);
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_BuildTriangles_m2C767A1D0CBE89D726305D210EB2416DE1DA98CD(L_92, L_94, L_96, L_98, (&V_13), (&V_10), (&V_1), (&V_4), (&V_3), (&V_6), (&V_7), (&V_5), NULL);
	}

IL_0234:
	{
		bool L_99 = V_9;
		if (!L_99)
		{
			goto IL_0250;
		}
	}
	{
		float L_100 = V_1;
		float L_101 = V_0;
		il2cpp_codegen_runtime_class_init_inline(Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var);
		float L_102 = ((Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_StaticFields*)il2cpp_codegen_static_fields_for(Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var))->___kMaxAreaTolerance;
		if ((!(((float)L_100) < ((float)((float)il2cpp_codegen_multiply(L_101, L_102))))))
		{
			goto IL_0250;
		}
	}
	{
		float L_103 = V_6;
		float L_104 = V_7;
		il2cpp_codegen_runtime_class_init_inline(Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var);
		float L_105 = ((Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_StaticFields*)il2cpp_codegen_static_fields_for(Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var))->___kMaxEdgeTolerance;
		G_B22_0 = ((((float)L_103) < ((float)((float)il2cpp_codegen_multiply(L_104, L_105))))? 1 : 0);
		goto IL_0251;
	}

IL_0250:
	{
		G_B22_0 = 0;
	}

IL_0251:
	{
		V_9 = (bool)G_B22_0;
	}

IL_0253:
	{
		NativeArray_1_Dispose_mB48AC20750ECFD2702E0F9915B2177D044D15C58((&V_13), NativeArray_1_Dispose_mB48AC20750ECFD2702E0F9915B2177D044D15C58_RuntimeMethod_var);
		NativeArray_1_Dispose_m38861384F84F1CD89A47D663C29D3ED425C5CCE0((&V_14), NativeArray_1_Dispose_m38861384F84F1CD89A47D663C29D3ED425C5CCE0_RuntimeMethod_var);
		NativeArray_1_Dispose_m38861384F84F1CD89A47D663C29D3ED425C5CCE0((&V_20), NativeArray_1_Dispose_m38861384F84F1CD89A47D663C29D3ED425C5CCE0_RuntimeMethod_var);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E((&V_17), NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		NativeArray_1_Dispose_m38861384F84F1CD89A47D663C29D3ED425C5CCE0((&V_15), NativeArray_1_Dispose_m38861384F84F1CD89A47D663C29D3ED425C5CCE0_RuntimeMethod_var);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E((&V_18), NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E((&V_19), NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		NativeArray_1_Dispose_m38861384F84F1CD89A47D663C29D3ED425C5CCE0((&V_16), NativeArray_1_Dispose_m38861384F84F1CD89A47D663C29D3ED425C5CCE0_RuntimeMethod_var);
		bool L_106 = V_9;
		if (!L_106)
		{
			goto IL_029e;
		}
	}
	{
		int32_t L_107 = V_21;
		int32_t* L_108 = ___8_indexCount;
		int32_t L_109 = *((int32_t*)L_108);
		if ((!(((uint32_t)L_107) == ((uint32_t)L_109))))
		{
			goto IL_029e;
		}
	}
	{
		int32_t L_110 = V_22;
		int32_t* L_111 = ___6_vertexCount;
		int32_t L_112 = *((int32_t*)L_111);
		return (bool)((((int32_t)L_110) == ((int32_t)L_112))? 1 : 0);
	}

IL_029e:
	{
		return (bool)0;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Smoothen__cctor_m250E6FDDF1F635976F1E65914E05FFA1F7F6B369 (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		((Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_StaticFields*)il2cpp_codegen_static_fields_for(Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var))->___kMaxAreaTolerance = (1.84200001f);
		((Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_StaticFields*)il2cpp_codegen_static_fields_for(Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var))->___kMaxEdgeTolerance = (2.48200011f);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float Tessellator_FindSplit_mFEA20FADFD2F4401DA02191FE3C6F4462F37B9B5 (UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_hull, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___1_edge, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	{
		V_0 = (0.0f);
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_0 = ___0_hull;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_1 = L_0.___a;
		float L_2 = L_1.___x;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_3 = ___1_edge;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = L_3.___a;
		float L_5 = L_4.___x;
		if ((!(((float)L_2) < ((float)L_5))))
		{
			goto IL_0038;
		}
	}
	{
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_6 = ___0_hull;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_7 = L_6.___a;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_8 = ___0_hull;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_9 = L_8.___b;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_10 = ___1_edge;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_11 = L_10.___a;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		float L_12;
		L_12 = ModuleHandle_OrientFast_m39D34C2844061E3607200824ADE00A8CA5680634(L_7, L_9, L_11, NULL);
		V_0 = L_12;
		goto IL_0050;
	}

IL_0038:
	{
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_13 = ___1_edge;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_14 = L_13.___b;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_15 = ___1_edge;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_16 = L_15.___a;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_17 = ___0_hull;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_18 = L_17.___a;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		float L_19;
		L_19 = ModuleHandle_OrientFast_m39D34C2844061E3607200824ADE00A8CA5680634(L_14, L_16, L_18, NULL);
		V_0 = L_19;
	}

IL_0050:
	{
		float L_20 = V_0;
		if ((((float)(0.0f)) == ((float)L_20)))
		{
			goto IL_005a;
		}
	}
	{
		float L_21 = V_0;
		return L_21;
	}

IL_005a:
	{
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_22 = ___1_edge;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_23 = L_22.___b;
		float L_24 = L_23.___x;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_25 = ___0_hull;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_26 = L_25.___b;
		float L_27 = L_26.___x;
		if ((!(((float)L_24) < ((float)L_27))))
		{
			goto IL_008c;
		}
	}
	{
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_28 = ___0_hull;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_29 = L_28.___a;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_30 = ___0_hull;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_31 = L_30.___b;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_32 = ___1_edge;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_33 = L_32.___b;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		float L_34;
		L_34 = ModuleHandle_OrientFast_m39D34C2844061E3607200824ADE00A8CA5680634(L_29, L_31, L_33, NULL);
		V_0 = L_34;
		goto IL_00a4;
	}

IL_008c:
	{
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_35 = ___1_edge;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_36 = L_35.___b;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_37 = ___1_edge;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_38 = L_37.___a;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_39 = ___0_hull;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_40 = L_39.___b;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		float L_41;
		L_41 = ModuleHandle_OrientFast_m39D34C2844061E3607200824ADE00A8CA5680634(L_36, L_38, L_40, NULL);
		V_0 = L_41;
	}

IL_00a4:
	{
		float L_42 = V_0;
		if ((((float)(0.0f)) == ((float)L_42)))
		{
			goto IL_00ae;
		}
	}
	{
		float L_43 = V_0;
		return L_43;
	}

IL_00ae:
	{
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_44 = ___0_hull;
		int32_t L_45 = L_44.___idx;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_46 = ___1_edge;
		int32_t L_47 = L_46.___idx;
		return ((float)((int32_t)il2cpp_codegen_subtract(L_45, L_47)));
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_SetAllocator_mC4F00FD3CD85AA582F89050F805A50236365B47A (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_allocator, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = ___0_allocator;
		__this->___m_Allocator = L_0;
		return;
	}
}
IL2CPP_EXTERN_C  void Tessellator_SetAllocator_mC4F00FD3CD85AA582F89050F805A50236365B47A_AdjustorThunk (RuntimeObject* __this, int32_t ___0_allocator, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	Tessellator_SetAllocator_mC4F00FD3CD85AA582F89050F805A50236365B47A_inline(_thisAdjusted, ___0_allocator, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_AddPoint_m182743F67F59E43CBD839CFDC1D0ADFE3F3B8299 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_hulls, int32_t ___1_hullCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___2_points, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___3_p, int32_t ___4_idx, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_get_Length_m814A8881AF759049A308E6E04BE0451BFDA0076B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3_m0A70D6C3B3B43D49B43B90E25921F0935E4F0853_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_GetUpper_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436_mFF87B6D1AF19335BBFCBFC9A88B90165B26C3987_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	TestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3 V_2;
	memset((&V_2), 0, sizeof(V_2));
	TestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436 V_3;
	memset((&V_3), 0, sizeof(V_3));
	int32_t V_4 = 0;
	UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 V_5;
	memset((&V_5), 0, sizeof(V_5));
	int32_t V_6 = 0;
	int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF V_7;
	memset((&V_7), 0, sizeof(V_7));
	int32_t V_8 = 0;
	int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF V_9;
	memset((&V_9), 0, sizeof(V_9));
	{
		NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 L_0 = ___0_hulls;
		int32_t L_1 = ___1_hullCount;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = ___3_p;
		il2cpp_codegen_initobj((&V_2), sizeof(TestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3));
		TestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3 L_3 = V_2;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_4;
		L_4 = ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3_m0A70D6C3B3B43D49B43B90E25921F0935E4F0853(L_0, L_1, L_2, L_3, ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3_m0A70D6C3B3B43D49B43B90E25921F0935E4F0853_RuntimeMethod_var);
		V_0 = L_4;
		NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 L_5 = ___0_hulls;
		int32_t L_6 = ___1_hullCount;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_7 = ___3_p;
		il2cpp_codegen_initobj((&V_3), sizeof(TestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436));
		TestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436 L_8 = V_3;
		int32_t L_9;
		L_9 = ModuleHandle_GetUpper_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436_mFF87B6D1AF19335BBFCBFC9A88B90165B26C3987(L_5, L_6, L_7, L_8, ModuleHandle_GetUpper_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_TisTestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436_mFF87B6D1AF19335BBFCBFC9A88B90165B26C3987_RuntimeMethod_var);
		V_1 = L_9;
		int32_t L_10 = V_0;
		if ((((int32_t)L_10) < ((int32_t)0)))
		{
			goto IL_002e;
		}
	}
	{
		int32_t L_11 = V_1;
		if ((((int32_t)L_11) >= ((int32_t)0)))
		{
			goto IL_0030;
		}
	}

IL_002e:
	{
		return (bool)0;
	}

IL_0030:
	{
		int32_t L_12 = V_0;
		V_4 = L_12;
		goto IL_0222;
	}

IL_0038:
	{
		int32_t L_13 = V_4;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_14;
		L_14 = IL2CPP_NATIVEARRAY_GET_ITEM(UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53, ((&___0_hulls))->___m_Buffer, L_13);
		V_5 = L_14;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_15 = V_5;
		int32_t L_16 = L_15.___ilcount;
		V_6 = L_16;
		goto IL_00b4;
	}

IL_004e:
	{
		il2cpp_codegen_initobj((&V_7), sizeof(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF));
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_17 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___ilarray);
		int32_t L_18 = V_6;
		int32_t L_19;
		L_19 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_17, ((int32_t)il2cpp_codegen_subtract(L_18, 1)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		(&V_7)->___x = L_19;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_20 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___ilarray);
		int32_t L_21 = V_6;
		int32_t L_22;
		L_22 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_20, ((int32_t)il2cpp_codegen_subtract(L_21, 2)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		(&V_7)->___y = L_22;
		int32_t L_23 = ___4_idx;
		(&V_7)->___z = L_23;
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* L_24 = (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57*)(&__this->___m_Cells);
		int32_t L_25 = __this->___m_CellCount;
		V_8 = L_25;
		int32_t L_26 = V_8;
		__this->___m_CellCount = ((int32_t)il2cpp_codegen_add(L_26, 1));
		int32_t L_27 = V_8;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_28 = V_7;
		IL2CPP_NATIVEARRAY_SET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, (L_24)->___m_Buffer, L_27, (L_28));
		int32_t L_29 = V_6;
		V_6 = ((int32_t)il2cpp_codegen_subtract(L_29, 1));
	}

IL_00b4:
	{
		int32_t L_30 = V_6;
		if ((((int32_t)L_30) <= ((int32_t)1)))
		{
			goto IL_00f8;
		}
	}
	{
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_31 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___ilarray);
		int32_t L_32 = V_6;
		int32_t L_33;
		L_33 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_31, ((int32_t)il2cpp_codegen_subtract(L_32, 2)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_34;
		L_34 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___2_points))->___m_Buffer, L_33);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_35 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___ilarray);
		int32_t L_36 = V_6;
		int32_t L_37;
		L_37 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_35, ((int32_t)il2cpp_codegen_subtract(L_36, 1)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_38;
		L_38 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___2_points))->___m_Buffer, L_37);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_39 = ___3_p;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		float L_40;
		L_40 = ModuleHandle_OrientFast_m39D34C2844061E3607200824ADE00A8CA5680634(L_34, L_38, L_39, NULL);
		if ((((float)L_40) > ((float)(0.0f))))
		{
			goto IL_004e;
		}
	}

IL_00f8:
	{
		int32_t L_41 = V_6;
		(&V_5)->___ilcount = ((int32_t)il2cpp_codegen_add(L_41, 1));
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_42 = V_5;
		int32_t L_43 = L_42.___ilcount;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_44 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___ilarray);
		int32_t L_45;
		L_45 = ArraySlice_1_get_Length_m814A8881AF759049A308E6E04BE0451BFDA0076B_inline(L_44, ArraySlice_1_get_Length_m814A8881AF759049A308E6E04BE0451BFDA0076B_RuntimeMethod_var);
		if ((((int32_t)L_43) <= ((int32_t)L_45)))
		{
			goto IL_011a;
		}
	}
	{
		return (bool)0;
	}

IL_011a:
	{
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_46 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___ilarray);
		int32_t L_47 = V_6;
		int32_t L_48 = ___4_idx;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_46, L_47, L_48, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_49 = V_5;
		int32_t L_50 = L_49.___iucount;
		V_6 = L_50;
		goto IL_019b;
	}

IL_0135:
	{
		il2cpp_codegen_initobj((&V_9), sizeof(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF));
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_51 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___iuarray);
		int32_t L_52 = V_6;
		int32_t L_53;
		L_53 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_51, ((int32_t)il2cpp_codegen_subtract(L_52, 2)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		(&V_9)->___x = L_53;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_54 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___iuarray);
		int32_t L_55 = V_6;
		int32_t L_56;
		L_56 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_54, ((int32_t)il2cpp_codegen_subtract(L_55, 1)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		(&V_9)->___y = L_56;
		int32_t L_57 = ___4_idx;
		(&V_9)->___z = L_57;
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* L_58 = (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57*)(&__this->___m_Cells);
		int32_t L_59 = __this->___m_CellCount;
		V_8 = L_59;
		int32_t L_60 = V_8;
		__this->___m_CellCount = ((int32_t)il2cpp_codegen_add(L_60, 1));
		int32_t L_61 = V_8;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_62 = V_9;
		IL2CPP_NATIVEARRAY_SET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, (L_58)->___m_Buffer, L_61, (L_62));
		int32_t L_63 = V_6;
		V_6 = ((int32_t)il2cpp_codegen_subtract(L_63, 1));
	}

IL_019b:
	{
		int32_t L_64 = V_6;
		if ((((int32_t)L_64) <= ((int32_t)1)))
		{
			goto IL_01df;
		}
	}
	{
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_65 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___iuarray);
		int32_t L_66 = V_6;
		int32_t L_67;
		L_67 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_65, ((int32_t)il2cpp_codegen_subtract(L_66, 2)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_68;
		L_68 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___2_points))->___m_Buffer, L_67);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_69 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___iuarray);
		int32_t L_70 = V_6;
		int32_t L_71;
		L_71 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_69, ((int32_t)il2cpp_codegen_subtract(L_70, 1)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_72;
		L_72 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___2_points))->___m_Buffer, L_71);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_73 = ___3_p;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		float L_74;
		L_74 = ModuleHandle_OrientFast_m39D34C2844061E3607200824ADE00A8CA5680634(L_68, L_72, L_73, NULL);
		if ((((float)L_74) < ((float)(0.0f))))
		{
			goto IL_0135;
		}
	}

IL_01df:
	{
		int32_t L_75 = V_6;
		(&V_5)->___iucount = ((int32_t)il2cpp_codegen_add(L_75, 1));
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_76 = V_5;
		int32_t L_77 = L_76.___iucount;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_78 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___iuarray);
		int32_t L_79;
		L_79 = ArraySlice_1_get_Length_m814A8881AF759049A308E6E04BE0451BFDA0076B_inline(L_78, ArraySlice_1_get_Length_m814A8881AF759049A308E6E04BE0451BFDA0076B_RuntimeMethod_var);
		if ((((int32_t)L_77) <= ((int32_t)L_79)))
		{
			goto IL_0201;
		}
	}
	{
		return (bool)0;
	}

IL_0201:
	{
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_80 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___iuarray);
		int32_t L_81 = V_6;
		int32_t L_82 = ___4_idx;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_80, L_81, L_82, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		int32_t L_83 = V_4;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_84 = V_5;
		IL2CPP_NATIVEARRAY_SET_ITEM(UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53, ((&___0_hulls))->___m_Buffer, L_83, (L_84));
		int32_t L_85 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_add(L_85, 1));
	}

IL_0222:
	{
		int32_t L_86 = V_4;
		int32_t L_87 = V_1;
		if ((((int32_t)L_86) < ((int32_t)L_87)))
		{
			goto IL_0038;
		}
	}
	{
		return (bool)1;
	}
}
IL2CPP_EXTERN_C  bool Tessellator_AddPoint_m182743F67F59E43CBD839CFDC1D0ADFE3F3B8299_AdjustorThunk (RuntimeObject* __this, NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_hulls, int32_t ___1_hullCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___2_points, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___3_p, int32_t ___4_idx, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	bool _returnValue;
	_returnValue = Tessellator_AddPoint_m182743F67F59E43CBD839CFDC1D0ADFE3F3B8299(_thisAdjusted, ___0_hulls, ___1_hullCount, ___2_points, ___3_p, ___4_idx, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_InsertHull_m78B0282356E02B23DA875D91E50D28691EE84442 (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_Hulls, int32_t ___1_Pos, int32_t* ___2_Count, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___3_Value, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		int32_t* L_0 = ___2_Count;
		int32_t L_1 = *((int32_t*)L_0);
		int32_t L_2;
		L_2 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___0_Hulls))->___m_Length);
		if ((((int32_t)L_1) >= ((int32_t)((int32_t)il2cpp_codegen_subtract(L_2, 1)))))
		{
			goto IL_003b;
		}
	}
	{
		int32_t* L_3 = ___2_Count;
		int32_t L_4 = *((int32_t*)L_3);
		V_0 = L_4;
		goto IL_0028;
	}

IL_0012:
	{
		int32_t L_5 = V_0;
		int32_t L_6 = V_0;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_7;
		L_7 = IL2CPP_NATIVEARRAY_GET_ITEM(UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53, ((&___0_Hulls))->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_6, 1)));
		IL2CPP_NATIVEARRAY_SET_ITEM(UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53, ((&___0_Hulls))->___m_Buffer, L_5, (L_7));
		int32_t L_8 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_subtract(L_8, 1));
	}

IL_0028:
	{
		int32_t L_9 = V_0;
		int32_t L_10 = ___1_Pos;
		if ((((int32_t)L_9) > ((int32_t)L_10)))
		{
			goto IL_0012;
		}
	}
	{
		int32_t L_11 = ___1_Pos;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_12 = ___3_Value;
		IL2CPP_NATIVEARRAY_SET_ITEM(UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53, ((&___0_Hulls))->___m_Buffer, L_11, (L_12));
		int32_t* L_13 = ___2_Count;
		int32_t* L_14 = ___2_Count;
		int32_t L_15 = *((int32_t*)L_14);
		*((int32_t*)L_13) = (int32_t)((int32_t)il2cpp_codegen_add(L_15, 1));
	}

IL_003b:
	{
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_EraseHull_m99C74029D962F1EAB6D75DDBF856638D72B7BA03 (NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_Hulls, int32_t ___1_Pos, int32_t* ___2_Count, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		int32_t* L_0 = ___2_Count;
		int32_t L_1 = *((int32_t*)L_0);
		int32_t L_2;
		L_2 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___0_Hulls))->___m_Length);
		if ((((int32_t)L_1) >= ((int32_t)L_2)))
		{
			goto IL_0032;
		}
	}
	{
		int32_t L_3 = ___1_Pos;
		V_0 = L_3;
		goto IL_0025;
	}

IL_000f:
	{
		int32_t L_4 = V_0;
		int32_t L_5 = V_0;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_6;
		L_6 = IL2CPP_NATIVEARRAY_GET_ITEM(UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53, ((&___0_Hulls))->___m_Buffer, ((int32_t)il2cpp_codegen_add(L_5, 1)));
		IL2CPP_NATIVEARRAY_SET_ITEM(UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53, ((&___0_Hulls))->___m_Buffer, L_4, (L_6));
		int32_t L_7 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_7, 1));
	}

IL_0025:
	{
		int32_t L_8 = V_0;
		int32_t* L_9 = ___2_Count;
		int32_t L_10 = *((int32_t*)L_9);
		if ((((int32_t)L_8) < ((int32_t)((int32_t)il2cpp_codegen_subtract(L_10, 1)))))
		{
			goto IL_000f;
		}
	}
	{
		int32_t* L_11 = ___2_Count;
		int32_t* L_12 = ___2_Count;
		int32_t L_13 = *((int32_t*)L_12);
		*((int32_t*)L_11) = (int32_t)((int32_t)il2cpp_codegen_subtract(L_13, 1));
	}

IL_0032:
	{
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_SplitHulls_m0E1DD4AC9AA526B11A5FF0729A50A17299A16A81 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_hulls, int32_t* ___1_hullCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___2_points, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___3_evt, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D_mDDE7DE6D079B34BF84F234F97CEF203430E49608_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 V_1;
	memset((&V_1), 0, sizeof(V_1));
	UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 V_2;
	memset((&V_2), 0, sizeof(V_2));
	int32_t V_3 = 0;
	TestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D V_4;
	memset((&V_4), 0, sizeof(V_4));
	int32_t V_5 = 0;
	{
		NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 L_0 = ___0_hulls;
		int32_t* L_1 = ___1_hullCount;
		int32_t L_2 = *((int32_t*)L_1);
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_3 = ___3_evt;
		il2cpp_codegen_initobj((&V_4), sizeof(TestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D));
		TestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D L_4 = V_4;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_5;
		L_5 = ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D_mDDE7DE6D079B34BF84F234F97CEF203430E49608(L_0, L_2, L_3, L_4, ModuleHandle_GetLower_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D_mDDE7DE6D079B34BF84F234F97CEF203430E49608_RuntimeMethod_var);
		V_0 = L_5;
		int32_t L_6 = V_0;
		if ((((int32_t)L_6) >= ((int32_t)0)))
		{
			goto IL_001b;
		}
	}
	{
		return (bool)0;
	}

IL_001b:
	{
		int32_t L_7 = V_0;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_8;
		L_8 = IL2CPP_NATIVEARRAY_GET_ITEM(UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53, ((&___0_hulls))->___m_Buffer, L_7);
		V_1 = L_8;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_9 = ___3_evt;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_10 = L_9.___a;
		(&V_2)->___a = L_10;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_11 = ___3_evt;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_12 = L_11.___b;
		(&V_2)->___b = L_12;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_13 = ___3_evt;
		int32_t L_14 = L_13.___idx;
		(&V_2)->___idx = L_14;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_15 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_1)->___iuarray);
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_16 = V_1;
		int32_t L_17 = L_16.___iucount;
		int32_t L_18;
		L_18 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_15, ((int32_t)il2cpp_codegen_subtract(L_17, 1)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		V_3 = L_18;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_19 = __this->___m_IUArray;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_20 = V_2;
		int32_t L_21 = L_20.___idx;
		int32_t L_22 = __this->___m_NumHulls;
		int32_t L_23 = __this->___m_NumHulls;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 L_24;
		memset((&L_24), 0, sizeof(L_24));
		ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402((&L_24), L_19, ((int32_t)il2cpp_codegen_multiply(L_21, L_22)), L_23, ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402_RuntimeMethod_var);
		(&V_2)->___iuarray = L_24;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_25 = V_1;
		int32_t L_26 = L_25.___iucount;
		(&V_2)->___iucount = L_26;
		V_5 = 0;
		goto IL_00bc;
	}

IL_009a:
	{
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_27 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_2)->___iuarray);
		int32_t L_28 = V_5;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_29 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_1)->___iuarray);
		int32_t L_30 = V_5;
		int32_t L_31;
		L_31 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_29, L_30, ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_27, L_28, L_31, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		int32_t L_32 = V_5;
		V_5 = ((int32_t)il2cpp_codegen_add(L_32, 1));
	}

IL_00bc:
	{
		int32_t L_33 = V_5;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_34 = V_2;
		int32_t L_35 = L_34.___iucount;
		if ((((int32_t)L_33) < ((int32_t)L_35)))
		{
			goto IL_009a;
		}
	}
	{
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_36 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_1)->___iuarray);
		int32_t L_37 = V_3;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_36, 0, L_37, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		(&V_1)->___iucount = 1;
		int32_t L_38 = V_0;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_39 = V_1;
		IL2CPP_NATIVEARRAY_SET_ITEM(UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53, ((&___0_hulls))->___m_Buffer, L_38, (L_39));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_40 = __this->___m_ILArray;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_41 = V_2;
		int32_t L_42 = L_41.___idx;
		int32_t L_43 = __this->___m_NumHulls;
		int32_t L_44 = __this->___m_NumHulls;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 L_45;
		memset((&L_45), 0, sizeof(L_45));
		ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402((&L_45), L_40, ((int32_t)il2cpp_codegen_multiply(L_42, L_43)), L_44, ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402_RuntimeMethod_var);
		(&V_2)->___ilarray = L_45;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_46 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_2)->___ilarray);
		int32_t L_47 = V_3;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_46, 0, L_47, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		(&V_2)->___ilcount = 1;
		NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 L_48 = ___0_hulls;
		int32_t L_49 = V_0;
		int32_t* L_50 = ___1_hullCount;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_51 = V_2;
		Tessellator_InsertHull_m78B0282356E02B23DA875D91E50D28691EE84442(L_48, ((int32_t)il2cpp_codegen_add(L_49, 1)), L_50, L_51, NULL);
		return (bool)1;
	}
}
IL2CPP_EXTERN_C  bool Tessellator_SplitHulls_m0E1DD4AC9AA526B11A5FF0729A50A17299A16A81_AdjustorThunk (RuntimeObject* __this, NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_hulls, int32_t* ___1_hullCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___2_points, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___3_evt, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	bool _returnValue;
	_returnValue = Tessellator_SplitHulls_m0E1DD4AC9AA526B11A5FF0729A50A17299A16A81(_thisAdjusted, ___0_hulls, ___1_hullCount, ___2_points, ___3_evt, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_MergeHulls_m9C43D5FB7E8BFA626169A2548C85E3FCF903751C (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_hulls, int32_t* ___1_hullCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___2_points, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___3_evt, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_GetEqual_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155_m27B4DE791ADEB1742E19D6628CA333842FC8FC54_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 V_2;
	memset((&V_2), 0, sizeof(V_2));
	UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 V_3;
	memset((&V_3), 0, sizeof(V_3));
	TestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155 V_4;
	memset((&V_4), 0, sizeof(V_4));
	int32_t V_5 = 0;
	{
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_0 = ___3_evt;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_1 = L_0.___a;
		V_0 = L_1;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_2 = ___3_evt;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_3 = L_2.___b;
		(&___3_evt)->___a = L_3;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = V_0;
		(&___3_evt)->___b = L_4;
		NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 L_5 = ___0_hulls;
		int32_t* L_6 = ___1_hullCount;
		int32_t L_7 = *((int32_t*)L_6);
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_8 = ___3_evt;
		il2cpp_codegen_initobj((&V_4), sizeof(TestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155));
		TestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155 L_9 = V_4;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_10;
		L_10 = ModuleHandle_GetEqual_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155_m27B4DE791ADEB1742E19D6628CA333842FC8FC54(L_5, L_7, L_8, L_9, ModuleHandle_GetEqual_TisUHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155_m27B4DE791ADEB1742E19D6628CA333842FC8FC54_RuntimeMethod_var);
		V_1 = L_10;
		int32_t L_11 = V_1;
		if ((((int32_t)L_11) >= ((int32_t)0)))
		{
			goto IL_0039;
		}
	}
	{
		return (bool)0;
	}

IL_0039:
	{
		int32_t L_12 = V_1;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_13;
		L_13 = IL2CPP_NATIVEARRAY_GET_ITEM(UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53, ((&___0_hulls))->___m_Buffer, L_12);
		V_2 = L_13;
		int32_t L_14 = V_1;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_15;
		L_15 = IL2CPP_NATIVEARRAY_GET_ITEM(UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53, ((&___0_hulls))->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_14, 1)));
		V_3 = L_15;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_16 = V_2;
		int32_t L_17 = L_16.___iucount;
		(&V_3)->___iucount = L_17;
		V_5 = 0;
		goto IL_0081;
	}

IL_005f:
	{
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_18 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_3)->___iuarray);
		int32_t L_19 = V_5;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_20 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_2)->___iuarray);
		int32_t L_21 = V_5;
		int32_t L_22;
		L_22 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_20, L_21, ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_18, L_19, L_22, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		int32_t L_23 = V_5;
		V_5 = ((int32_t)il2cpp_codegen_add(L_23, 1));
	}

IL_0081:
	{
		int32_t L_24 = V_5;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_25 = V_3;
		int32_t L_26 = L_25.___iucount;
		if ((((int32_t)L_24) < ((int32_t)L_26)))
		{
			goto IL_005f;
		}
	}
	{
		int32_t L_27 = V_1;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_28 = V_3;
		IL2CPP_NATIVEARRAY_SET_ITEM(UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53, ((&___0_hulls))->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_27, 1)), (L_28));
		NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 L_29 = ___0_hulls;
		int32_t L_30 = V_1;
		int32_t* L_31 = ___1_hullCount;
		Tessellator_EraseHull_m99C74029D962F1EAB6D75DDBF856638D72B7BA03(L_29, L_30, L_31, NULL);
		return (bool)1;
	}
}
IL2CPP_EXTERN_C  bool Tessellator_MergeHulls_m9C43D5FB7E8BFA626169A2548C85E3FCF903751C_AdjustorThunk (RuntimeObject* __this, NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 ___0_hulls, int32_t* ___1_hullCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___2_points, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___3_evt, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	bool _returnValue;
	_returnValue = Tessellator_MergeHulls_m9C43D5FB7E8BFA626169A2548C85E3FCF903751C(_thisAdjusted, ___0_hulls, ___1_hullCount, ___2_points, ___3_evt, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_InsertUniqueEdge_m143D5A36C4A932DAB167592C3634691BBDA38220 (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_edges, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_e, int32_t* ___2_edgeCount, const RuntimeMethod* method) 
{
	TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434 V_0;
	memset((&V_0), 0, sizeof(V_0));
	bool V_1 = false;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	{
		il2cpp_codegen_initobj((&V_0), sizeof(TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434));
		V_1 = (bool)1;
		V_2 = 0;
		goto IL_0026;
	}

IL_000e:
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_0 = ___1_e;
		int32_t L_1 = V_2;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_2;
		L_2 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_1);
		int32_t L_3;
		L_3 = TessEdgeCompare_Compare_m29540C70B61ECC31030C7D3F52E8F3B534BEC37D((&V_0), L_0, L_2, NULL);
		if (L_3)
		{
			goto IL_0022;
		}
	}
	{
		V_1 = (bool)0;
	}

IL_0022:
	{
		int32_t L_4 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add(L_4, 1));
	}

IL_0026:
	{
		bool L_5 = V_1;
		if (!L_5)
		{
			goto IL_002e;
		}
	}
	{
		int32_t L_6 = V_2;
		int32_t* L_7 = ___2_edgeCount;
		int32_t L_8 = *((int32_t*)L_7);
		if ((((int32_t)L_6) < ((int32_t)L_8)))
		{
			goto IL_000e;
		}
	}

IL_002e:
	{
		bool L_9 = V_1;
		if (!L_9)
		{
			goto IL_0042;
		}
	}
	{
		int32_t* L_10 = ___2_edgeCount;
		int32_t* L_11 = ___2_edgeCount;
		int32_t L_12 = *((int32_t*)L_11);
		V_3 = L_12;
		int32_t L_13 = V_3;
		*((int32_t*)L_10) = (int32_t)((int32_t)il2cpp_codegen_add(L_13, 1));
		int32_t L_14 = V_3;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_15 = ___1_e;
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_14, (L_15));
	}

IL_0042:
	{
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_PrepareDelaunay_mC18519EEF84FC79C0C98F273D1AF0FCBE4CFDC1D (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_edges, int32_t ___1_edgeCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434_mBE4B56307E132AEA84ADF183CC238AA9ED176FA6_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_m9D79AD54D34744D093257128146409873295E2DB_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 V_1;
	memset((&V_1), 0, sizeof(V_1));
	int32_t V_2 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_3;
	memset((&V_3), 0, sizeof(V_3));
	int32_t V_4 = 0;
	TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434 V_5;
	memset((&V_5), 0, sizeof(V_5));
	int32_t V_6 = 0;
	UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 V_7;
	memset((&V_7), 0, sizeof(V_7));
	int32_t V_8 = 0;
	int32_t V_9 = 0;
	int32_t V_10 = 0;
	int32_t V_11 = 0;
	UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 V_12;
	memset((&V_12), 0, sizeof(V_12));
	UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 V_13;
	memset((&V_13), 0, sizeof(V_13));
	UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 V_14;
	memset((&V_14), 0, sizeof(V_14));
	int32_t V_15 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* G_B3_0 = NULL;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* G_B2_0 = NULL;
	int32_t G_B4_0 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* G_B4_1 = NULL;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* G_B6_0 = NULL;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* G_B5_0 = NULL;
	int32_t G_B7_0 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* G_B7_1 = NULL;
	{
		int32_t L_0 = __this->___m_CellCount;
		__this->___m_StarCount = ((int32_t)il2cpp_codegen_multiply(L_0, 3));
		int32_t L_1 = __this->___m_StarCount;
		int32_t L_2 = __this->___m_Allocator;
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099 L_3;
		memset((&L_3), 0, sizeof(L_3));
		NativeArray_1__ctor_m9D79AD54D34744D093257128146409873295E2DB((&L_3), L_1, L_2, 1, NativeArray_1__ctor_m9D79AD54D34744D093257128146409873295E2DB_RuntimeMethod_var);
		__this->___m_Stars = L_3;
		int32_t L_4 = __this->___m_StarCount;
		int32_t L_5 = __this->___m_StarCount;
		int32_t L_6 = __this->___m_Allocator;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_7;
		memset((&L_7), 0, sizeof(L_7));
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&L_7), ((int32_t)il2cpp_codegen_multiply(L_4, L_5)), L_6, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		__this->___m_SPArray = L_7;
		V_0 = 0;
		int32_t L_8 = __this->___m_StarCount;
		int32_t L_9 = __this->___m_Allocator;
		NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13((&V_1), L_8, L_9, 1, NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		V_2 = 0;
		goto IL_00ff;
	}

IL_0062:
	{
		int32_t L_10 = V_2;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_11;
		L_11 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_10);
		V_3 = L_11;
		int32_t L_12 = V_2;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_13;
		L_13 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_12);
		int32_t L_14 = L_13.___x;
		int32_t L_15 = V_2;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_16;
		L_16 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_15);
		int32_t L_17 = L_16.___y;
		if ((((int32_t)L_14) < ((int32_t)L_17)))
		{
			G_B3_0 = (&V_3);
			goto IL_0098;
		}
		G_B2_0 = (&V_3);
	}
	{
		int32_t L_18 = V_2;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_19;
		L_19 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_18);
		int32_t L_20 = L_19.___y;
		G_B4_0 = L_20;
		G_B4_1 = G_B2_0;
		goto IL_00a5;
	}

IL_0098:
	{
		int32_t L_21 = V_2;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_22;
		L_22 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_21);
		int32_t L_23 = L_22.___x;
		G_B4_0 = L_23;
		G_B4_1 = G_B3_0;
	}

IL_00a5:
	{
		G_B4_1->___x = G_B4_0;
		int32_t L_24 = V_2;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_25;
		L_25 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_24);
		int32_t L_26 = L_25.___x;
		int32_t L_27 = V_2;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_28;
		L_28 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_27);
		int32_t L_29 = L_28.___y;
		if ((((int32_t)L_26) > ((int32_t)L_29)))
		{
			G_B6_0 = (&V_3);
			goto IL_00d7;
		}
		G_B5_0 = (&V_3);
	}
	{
		int32_t L_30 = V_2;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_31;
		L_31 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_30);
		int32_t L_32 = L_31.___y;
		G_B7_0 = L_32;
		G_B7_1 = G_B5_0;
		goto IL_00e4;
	}

IL_00d7:
	{
		int32_t L_33 = V_2;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_34;
		L_34 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_33);
		int32_t L_35 = L_34.___x;
		G_B7_0 = L_35;
		G_B7_1 = G_B6_0;
	}

IL_00e4:
	{
		G_B7_1->___y = G_B7_0;
		int32_t L_36 = V_2;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_37 = V_3;
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___0_edges))->___m_Buffer, L_36, (L_37));
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_38 = V_1;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_39 = V_3;
		Tessellator_InsertUniqueEdge_m143D5A36C4A932DAB167592C3634691BBDA38220(L_38, L_39, (&V_0), NULL);
		int32_t L_40 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add(L_40, 1));
	}

IL_00ff:
	{
		int32_t L_41 = V_2;
		int32_t L_42 = ___1_edgeCount;
		if ((((int32_t)L_41) < ((int32_t)L_42)))
		{
			goto IL_0062;
		}
	}
	{
		int32_t L_43 = V_0;
		int32_t L_44 = __this->___m_Allocator;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_45;
		memset((&L_45), 0, sizeof(L_45));
		NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13((&L_45), L_43, L_44, 1, NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		__this->___m_Edges = L_45;
		V_4 = 0;
		goto IL_013a;
	}

IL_011e:
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_46 = (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)(&__this->___m_Edges);
		int32_t L_47 = V_4;
		int32_t L_48 = V_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_49;
		L_49 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&V_1))->___m_Buffer, L_48);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_46)->___m_Buffer, L_47, (L_49));
		int32_t L_50 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_add(L_50, 1));
	}

IL_013a:
	{
		int32_t L_51 = V_4;
		int32_t L_52 = V_0;
		if ((((int32_t)L_51) < ((int32_t)L_52)))
		{
			goto IL_011e;
		}
	}
	{
		NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2((&V_1), NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_53 = __this->___m_Edges;
		void* L_54;
		L_54 = NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D(L_53, NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_m25C40908D798F72BB7C4D9BFB9701455549FC47D_RuntimeMethod_var);
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_55 = (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)(&__this->___m_Edges);
		int32_t L_56;
		L_56 = IL2CPP_NATIVEARRAY_GET_LENGTH((L_55)->___m_Length);
		il2cpp_codegen_initobj((&V_5), sizeof(TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434));
		TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434 L_57 = V_5;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434_mBE4B56307E132AEA84ADF183CC238AA9ED176FA6(L_54, 0, ((int32_t)il2cpp_codegen_subtract(L_56, 1)), L_57, ModuleHandle_InsertionSort_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434_mBE4B56307E132AEA84ADF183CC238AA9ED176FA6_RuntimeMethod_var);
		V_6 = 0;
		goto IL_01c0;
	}

IL_0173:
	{
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_58 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_59 = V_6;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_60;
		L_60 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_58)->___m_Buffer, L_59);
		V_7 = L_60;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_61 = __this->___m_SPArray;
		int32_t L_62 = V_6;
		int32_t L_63 = __this->___m_StarCount;
		int32_t L_64 = __this->___m_StarCount;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 L_65;
		memset((&L_65), 0, sizeof(L_65));
		ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402((&L_65), L_61, ((int32_t)il2cpp_codegen_multiply(L_62, L_63)), L_64, ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402_RuntimeMethod_var);
		(&V_7)->___points = L_65;
		(&V_7)->___pointCount = 0;
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_66 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_67 = V_6;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_68 = V_7;
		IL2CPP_NATIVEARRAY_SET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_66)->___m_Buffer, L_67, (L_68));
		int32_t L_69 = V_6;
		V_6 = ((int32_t)il2cpp_codegen_add(L_69, 1));
	}

IL_01c0:
	{
		int32_t L_70 = V_6;
		int32_t L_71 = __this->___m_StarCount;
		if ((((int32_t)L_70) < ((int32_t)L_71)))
		{
			goto IL_0173;
		}
	}
	{
		V_8 = 0;
		goto IL_032e;
	}

IL_01d2:
	{
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* L_72 = (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57*)(&__this->___m_Cells);
		int32_t L_73 = V_8;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_74;
		L_74 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, (L_72)->___m_Buffer, L_73);
		int32_t L_75 = L_74.___x;
		V_9 = L_75;
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* L_76 = (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57*)(&__this->___m_Cells);
		int32_t L_77 = V_8;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_78;
		L_78 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, (L_76)->___m_Buffer, L_77);
		int32_t L_79 = L_78.___y;
		V_10 = L_79;
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* L_80 = (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57*)(&__this->___m_Cells);
		int32_t L_81 = V_8;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_82;
		L_82 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, (L_80)->___m_Buffer, L_81);
		int32_t L_83 = L_82.___z;
		V_11 = L_83;
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_84 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_85 = V_9;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_86;
		L_86 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_84)->___m_Buffer, L_85);
		V_12 = L_86;
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_87 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_88 = V_10;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_89;
		L_89 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_87)->___m_Buffer, L_88);
		V_13 = L_89;
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_90 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_91 = V_11;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_92;
		L_92 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_90)->___m_Buffer, L_91);
		V_14 = L_92;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_93 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_12)->___points);
		int32_t* L_94 = (int32_t*)(&(&V_12)->___pointCount);
		int32_t* L_95 = L_94;
		int32_t L_96 = *((int32_t*)L_95);
		V_15 = L_96;
		int32_t L_97 = V_15;
		*((int32_t*)L_95) = (int32_t)((int32_t)il2cpp_codegen_add(L_97, 1));
		int32_t L_98 = V_15;
		int32_t L_99 = V_10;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_93, L_98, L_99, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_100 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_12)->___points);
		int32_t* L_101 = (int32_t*)(&(&V_12)->___pointCount);
		int32_t* L_102 = L_101;
		int32_t L_103 = *((int32_t*)L_102);
		V_15 = L_103;
		int32_t L_104 = V_15;
		*((int32_t*)L_102) = (int32_t)((int32_t)il2cpp_codegen_add(L_104, 1));
		int32_t L_105 = V_15;
		int32_t L_106 = V_11;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_100, L_105, L_106, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_107 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_13)->___points);
		int32_t* L_108 = (int32_t*)(&(&V_13)->___pointCount);
		int32_t* L_109 = L_108;
		int32_t L_110 = *((int32_t*)L_109);
		V_15 = L_110;
		int32_t L_111 = V_15;
		*((int32_t*)L_109) = (int32_t)((int32_t)il2cpp_codegen_add(L_111, 1));
		int32_t L_112 = V_15;
		int32_t L_113 = V_11;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_107, L_112, L_113, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_114 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_13)->___points);
		int32_t* L_115 = (int32_t*)(&(&V_13)->___pointCount);
		int32_t* L_116 = L_115;
		int32_t L_117 = *((int32_t*)L_116);
		V_15 = L_117;
		int32_t L_118 = V_15;
		*((int32_t*)L_116) = (int32_t)((int32_t)il2cpp_codegen_add(L_118, 1));
		int32_t L_119 = V_15;
		int32_t L_120 = V_9;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_114, L_119, L_120, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_121 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_14)->___points);
		int32_t* L_122 = (int32_t*)(&(&V_14)->___pointCount);
		int32_t* L_123 = L_122;
		int32_t L_124 = *((int32_t*)L_123);
		V_15 = L_124;
		int32_t L_125 = V_15;
		*((int32_t*)L_123) = (int32_t)((int32_t)il2cpp_codegen_add(L_125, 1));
		int32_t L_126 = V_15;
		int32_t L_127 = V_9;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_121, L_126, L_127, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_128 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_14)->___points);
		int32_t* L_129 = (int32_t*)(&(&V_14)->___pointCount);
		int32_t* L_130 = L_129;
		int32_t L_131 = *((int32_t*)L_130);
		V_15 = L_131;
		int32_t L_132 = V_15;
		*((int32_t*)L_130) = (int32_t)((int32_t)il2cpp_codegen_add(L_132, 1));
		int32_t L_133 = V_15;
		int32_t L_134 = V_10;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_128, L_133, L_134, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_135 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_136 = V_9;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_137 = V_12;
		IL2CPP_NATIVEARRAY_SET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_135)->___m_Buffer, L_136, (L_137));
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_138 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_139 = V_10;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_140 = V_13;
		IL2CPP_NATIVEARRAY_SET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_138)->___m_Buffer, L_139, (L_140));
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_141 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_142 = V_11;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_143 = V_14;
		IL2CPP_NATIVEARRAY_SET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_141)->___m_Buffer, L_142, (L_143));
		int32_t L_144 = V_8;
		V_8 = ((int32_t)il2cpp_codegen_add(L_144, 1));
	}

IL_032e:
	{
		int32_t L_145 = V_8;
		int32_t L_146 = __this->___m_CellCount;
		if ((((int32_t)L_145) < ((int32_t)L_146)))
		{
			goto IL_01d2;
		}
	}
	{
		return;
	}
}
IL2CPP_EXTERN_C  void Tessellator_PrepareDelaunay_mC18519EEF84FC79C0C98F273D1AF0FCBE4CFDC1D_AdjustorThunk (RuntimeObject* __this, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_edges, int32_t ___1_edgeCount, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	Tessellator_PrepareDelaunay_mC18519EEF84FC79C0C98F273D1AF0FCBE4CFDC1D(_thisAdjusted, ___0_edges, ___1_edgeCount, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Tessellator_OppositeOf_mB6E82B82152D79C874C4BEB6962348B5E408BCEE (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_a, int32_t ___1_b, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	{
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_0 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_1 = ___1_b;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_2;
		L_2 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_0)->___m_Buffer, L_1);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 L_3 = L_2.___points;
		V_0 = L_3;
		V_1 = 1;
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_4 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_5 = ___1_b;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_6;
		L_6 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_4)->___m_Buffer, L_5);
		int32_t L_7 = L_6.___pointCount;
		V_2 = L_7;
		goto IL_0042;
	}

IL_0028:
	{
		int32_t L_8 = V_1;
		int32_t L_9;
		L_9 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252((&V_0), L_8, ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		int32_t L_10 = ___0_a;
		if ((!(((uint32_t)L_9) == ((uint32_t)L_10))))
		{
			goto IL_003e;
		}
	}
	{
		int32_t L_11 = V_1;
		int32_t L_12;
		L_12 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252((&V_0), ((int32_t)il2cpp_codegen_subtract(L_11, 1)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		return L_12;
	}

IL_003e:
	{
		int32_t L_13 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_13, 2));
	}

IL_0042:
	{
		int32_t L_14 = V_1;
		int32_t L_15 = V_2;
		if ((((int32_t)L_14) < ((int32_t)L_15)))
		{
			goto IL_0028;
		}
	}
	{
		return (-1);
	}
}
IL2CPP_EXTERN_C  int32_t Tessellator_OppositeOf_mB6E82B82152D79C874C4BEB6962348B5E408BCEE_AdjustorThunk (RuntimeObject* __this, int32_t ___0_a, int32_t ___1_b, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	int32_t _returnValue;
	_returnValue = Tessellator_OppositeOf_mB6E82B82152D79C874C4BEB6962348B5E408BCEE(_thisAdjusted, ___0_a, ___1_b, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Tessellator_FindConstraint_m20B8DD4CC9007571111316603CFBA28FAE0E1A4A (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_a, int32_t ___1_b, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_GetEqual_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375_m00A96EB8B356CCA03D3D724C514C6175681907A8_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_0;
	memset((&V_0), 0, sizeof(V_0));
	TestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375 V_1;
	memset((&V_1), 0, sizeof(V_1));
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* G_B2_0 = NULL;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* G_B1_0 = NULL;
	int32_t G_B3_0 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* G_B3_1 = NULL;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* G_B5_0 = NULL;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* G_B4_0 = NULL;
	int32_t G_B6_0 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* G_B6_1 = NULL;
	{
		int32_t L_0 = ___0_a;
		int32_t L_1 = ___1_b;
		if ((((int32_t)L_0) < ((int32_t)L_1)))
		{
			G_B2_0 = (&V_0);
			goto IL_0009;
		}
		G_B1_0 = (&V_0);
	}
	{
		int32_t L_2 = ___1_b;
		G_B3_0 = L_2;
		G_B3_1 = G_B1_0;
		goto IL_000a;
	}

IL_0009:
	{
		int32_t L_3 = ___0_a;
		G_B3_0 = L_3;
		G_B3_1 = G_B2_0;
	}

IL_000a:
	{
		G_B3_1->___x = G_B3_0;
		int32_t L_4 = ___0_a;
		int32_t L_5 = ___1_b;
		if ((((int32_t)L_4) > ((int32_t)L_5)))
		{
			G_B5_0 = (&V_0);
			goto IL_0018;
		}
		G_B4_0 = (&V_0);
	}
	{
		int32_t L_6 = ___1_b;
		G_B6_0 = L_6;
		G_B6_1 = G_B4_0;
		goto IL_0019;
	}

IL_0018:
	{
		int32_t L_7 = ___0_a;
		G_B6_0 = L_7;
		G_B6_1 = G_B5_0;
	}

IL_0019:
	{
		G_B6_1->___y = G_B6_0;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_8 = __this->___m_Edges;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_9 = (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)(&__this->___m_Edges);
		int32_t L_10;
		L_10 = IL2CPP_NATIVEARRAY_GET_LENGTH((L_9)->___m_Length);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_11 = V_0;
		il2cpp_codegen_initobj((&V_1), sizeof(TestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375));
		TestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375 L_12 = V_1;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_13;
		L_13 = ModuleHandle_GetEqual_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375_m00A96EB8B356CCA03D3D724C514C6175681907A8(L_8, L_10, L_11, L_12, ModuleHandle_GetEqual_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_TisTestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375_m00A96EB8B356CCA03D3D724C514C6175681907A8_RuntimeMethod_var);
		return L_13;
	}
}
IL2CPP_EXTERN_C  int32_t Tessellator_FindConstraint_m20B8DD4CC9007571111316603CFBA28FAE0E1A4A_AdjustorThunk (RuntimeObject* __this, int32_t ___0_a, int32_t ___1_b, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	int32_t _returnValue;
	_returnValue = Tessellator_FindConstraint_m20B8DD4CC9007571111316603CFBA28FAE0E1A4A(_thisAdjusted, ___0_a, ___1_b, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_AddTriangle_m056EC10F57F04B372B226616D055F3D238E2A489 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_i, int32_t ___1_j, int32_t ___2_k, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 V_0;
	memset((&V_0), 0, sizeof(V_0));
	UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 V_1;
	memset((&V_1), 0, sizeof(V_1));
	UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 V_2;
	memset((&V_2), 0, sizeof(V_2));
	int32_t V_3 = 0;
	{
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_0 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_1 = ___0_i;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_2;
		L_2 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_0)->___m_Buffer, L_1);
		V_0 = L_2;
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_3 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_4 = ___1_j;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_5;
		L_5 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_3)->___m_Buffer, L_4);
		V_1 = L_5;
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_6 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_7 = ___2_k;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_8;
		L_8 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_6)->___m_Buffer, L_7);
		V_2 = L_8;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_9 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_0)->___points);
		int32_t* L_10 = (int32_t*)(&(&V_0)->___pointCount);
		int32_t* L_11 = L_10;
		int32_t L_12 = *((int32_t*)L_11);
		V_3 = L_12;
		int32_t L_13 = V_3;
		*((int32_t*)L_11) = (int32_t)((int32_t)il2cpp_codegen_add(L_13, 1));
		int32_t L_14 = V_3;
		int32_t L_15 = ___1_j;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_9, L_14, L_15, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_16 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_0)->___points);
		int32_t* L_17 = (int32_t*)(&(&V_0)->___pointCount);
		int32_t* L_18 = L_17;
		int32_t L_19 = *((int32_t*)L_18);
		V_3 = L_19;
		int32_t L_20 = V_3;
		*((int32_t*)L_18) = (int32_t)((int32_t)il2cpp_codegen_add(L_20, 1));
		int32_t L_21 = V_3;
		int32_t L_22 = ___2_k;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_16, L_21, L_22, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_23 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_1)->___points);
		int32_t* L_24 = (int32_t*)(&(&V_1)->___pointCount);
		int32_t* L_25 = L_24;
		int32_t L_26 = *((int32_t*)L_25);
		V_3 = L_26;
		int32_t L_27 = V_3;
		*((int32_t*)L_25) = (int32_t)((int32_t)il2cpp_codegen_add(L_27, 1));
		int32_t L_28 = V_3;
		int32_t L_29 = ___2_k;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_23, L_28, L_29, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_30 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_1)->___points);
		int32_t* L_31 = (int32_t*)(&(&V_1)->___pointCount);
		int32_t* L_32 = L_31;
		int32_t L_33 = *((int32_t*)L_32);
		V_3 = L_33;
		int32_t L_34 = V_3;
		*((int32_t*)L_32) = (int32_t)((int32_t)il2cpp_codegen_add(L_34, 1));
		int32_t L_35 = V_3;
		int32_t L_36 = ___0_i;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_30, L_35, L_36, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_37 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_2)->___points);
		int32_t* L_38 = (int32_t*)(&(&V_2)->___pointCount);
		int32_t* L_39 = L_38;
		int32_t L_40 = *((int32_t*)L_39);
		V_3 = L_40;
		int32_t L_41 = V_3;
		*((int32_t*)L_39) = (int32_t)((int32_t)il2cpp_codegen_add(L_41, 1));
		int32_t L_42 = V_3;
		int32_t L_43 = ___0_i;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_37, L_42, L_43, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_44 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_2)->___points);
		int32_t* L_45 = (int32_t*)(&(&V_2)->___pointCount);
		int32_t* L_46 = L_45;
		int32_t L_47 = *((int32_t*)L_46);
		V_3 = L_47;
		int32_t L_48 = V_3;
		*((int32_t*)L_46) = (int32_t)((int32_t)il2cpp_codegen_add(L_48, 1));
		int32_t L_49 = V_3;
		int32_t L_50 = ___1_j;
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55(L_44, L_49, L_50, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_51 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_52 = ___0_i;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_53 = V_0;
		IL2CPP_NATIVEARRAY_SET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_51)->___m_Buffer, L_52, (L_53));
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_54 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_55 = ___1_j;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_56 = V_1;
		IL2CPP_NATIVEARRAY_SET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_54)->___m_Buffer, L_55, (L_56));
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_57 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_58 = ___2_k;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_59 = V_2;
		IL2CPP_NATIVEARRAY_SET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_57)->___m_Buffer, L_58, (L_59));
		return;
	}
}
IL2CPP_EXTERN_C  void Tessellator_AddTriangle_m056EC10F57F04B372B226616D055F3D238E2A489_AdjustorThunk (RuntimeObject* __this, int32_t ___0_i, int32_t ___1_j, int32_t ___2_k, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	Tessellator_AddTriangle_m056EC10F57F04B372B226616D055F3D238E2A489(_thisAdjusted, ___0_i, ___1_j, ___2_k, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_RemovePair_m510EF9D6AAC6C238EBC67C16661117381C7813B4 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_r, int32_t ___1_j, int32_t ___2_k, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 V_0;
	memset((&V_0), 0, sizeof(V_0));
	ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 V_1;
	memset((&V_1), 0, sizeof(V_1));
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	{
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_0 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_1 = ___0_r;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_2;
		L_2 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_0)->___m_Buffer, L_1);
		V_0 = L_2;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_3 = V_0;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 L_4 = L_3.___points;
		V_1 = L_4;
		V_2 = 1;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_5 = V_0;
		int32_t L_6 = L_5.___pointCount;
		V_3 = L_6;
		goto IL_0086;
	}

IL_001f:
	{
		int32_t L_7 = V_2;
		int32_t L_8;
		L_8 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252((&V_1), ((int32_t)il2cpp_codegen_subtract(L_7, 1)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		int32_t L_9 = ___1_j;
		if ((!(((uint32_t)L_8) == ((uint32_t)L_9))))
		{
			goto IL_0082;
		}
	}
	{
		int32_t L_10 = V_2;
		int32_t L_11;
		L_11 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252((&V_1), L_10, ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		int32_t L_12 = ___2_k;
		if ((!(((uint32_t)L_11) == ((uint32_t)L_12))))
		{
			goto IL_0082;
		}
	}
	{
		int32_t L_13 = V_2;
		int32_t L_14 = V_3;
		int32_t L_15;
		L_15 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252((&V_1), ((int32_t)il2cpp_codegen_subtract(L_14, 2)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55((&V_1), ((int32_t)il2cpp_codegen_subtract(L_13, 1)), L_15, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		int32_t L_16 = V_2;
		int32_t L_17 = V_3;
		int32_t L_18;
		L_18 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252((&V_1), ((int32_t)il2cpp_codegen_subtract(L_17, 1)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55((&V_1), L_16, L_18, ArraySlice_1_set_Item_mA7C2C9440F721136AF32C6D6D9A3211302A95E55_RuntimeMethod_var);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 L_19 = V_1;
		(&V_0)->___points = L_19;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_20 = V_0;
		int32_t L_21 = L_20.___pointCount;
		(&V_0)->___pointCount = ((int32_t)il2cpp_codegen_subtract(L_21, 2));
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_22 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_23 = ___0_r;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_24 = V_0;
		IL2CPP_NATIVEARRAY_SET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_22)->___m_Buffer, L_23, (L_24));
		return;
	}

IL_0082:
	{
		int32_t L_25 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add(L_25, 2));
	}

IL_0086:
	{
		int32_t L_26 = V_2;
		int32_t L_27 = V_3;
		if ((((int32_t)L_26) < ((int32_t)L_27)))
		{
			goto IL_001f;
		}
	}
	{
		return;
	}
}
IL2CPP_EXTERN_C  void Tessellator_RemovePair_m510EF9D6AAC6C238EBC67C16661117381C7813B4_AdjustorThunk (RuntimeObject* __this, int32_t ___0_r, int32_t ___1_j, int32_t ___2_k, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	Tessellator_RemovePair_m510EF9D6AAC6C238EBC67C16661117381C7813B4(_thisAdjusted, ___0_r, ___1_j, ___2_k, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_RemoveTriangle_m4B9D2A007809D00EE7610B870F6A1F74EFD21B00 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_i, int32_t ___1_j, int32_t ___2_k, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = ___0_i;
		int32_t L_1 = ___1_j;
		int32_t L_2 = ___2_k;
		Tessellator_RemovePair_m510EF9D6AAC6C238EBC67C16661117381C7813B4(__this, L_0, L_1, L_2, NULL);
		int32_t L_3 = ___1_j;
		int32_t L_4 = ___2_k;
		int32_t L_5 = ___0_i;
		Tessellator_RemovePair_m510EF9D6AAC6C238EBC67C16661117381C7813B4(__this, L_3, L_4, L_5, NULL);
		int32_t L_6 = ___2_k;
		int32_t L_7 = ___0_i;
		int32_t L_8 = ___1_j;
		Tessellator_RemovePair_m510EF9D6AAC6C238EBC67C16661117381C7813B4(__this, L_6, L_7, L_8, NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void Tessellator_RemoveTriangle_m4B9D2A007809D00EE7610B870F6A1F74EFD21B00_AdjustorThunk (RuntimeObject* __this, int32_t ___0_i, int32_t ___1_j, int32_t ___2_k, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	Tessellator_RemoveTriangle_m4B9D2A007809D00EE7610B870F6A1F74EFD21B00(_thisAdjusted, ___0_i, ___1_j, ___2_k, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_EdgeFlip_mC4C0DD9C08C3DB477698E335DCDEC76D0AEEE81A (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_i, int32_t ___1_j, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	{
		int32_t L_0 = ___0_i;
		int32_t L_1 = ___1_j;
		int32_t L_2;
		L_2 = Tessellator_OppositeOf_mB6E82B82152D79C874C4BEB6962348B5E408BCEE(__this, L_0, L_1, NULL);
		V_0 = L_2;
		int32_t L_3 = ___1_j;
		int32_t L_4 = ___0_i;
		int32_t L_5;
		L_5 = Tessellator_OppositeOf_mB6E82B82152D79C874C4BEB6962348B5E408BCEE(__this, L_3, L_4, NULL);
		V_1 = L_5;
		int32_t L_6 = ___0_i;
		int32_t L_7 = ___1_j;
		int32_t L_8 = V_0;
		Tessellator_RemoveTriangle_m4B9D2A007809D00EE7610B870F6A1F74EFD21B00(__this, L_6, L_7, L_8, NULL);
		int32_t L_9 = ___1_j;
		int32_t L_10 = ___0_i;
		int32_t L_11 = V_1;
		Tessellator_RemoveTriangle_m4B9D2A007809D00EE7610B870F6A1F74EFD21B00(__this, L_9, L_10, L_11, NULL);
		int32_t L_12 = ___0_i;
		int32_t L_13 = V_1;
		int32_t L_14 = V_0;
		Tessellator_AddTriangle_m056EC10F57F04B372B226616D055F3D238E2A489(__this, L_12, L_13, L_14, NULL);
		int32_t L_15 = ___1_j;
		int32_t L_16 = V_0;
		int32_t L_17 = V_1;
		Tessellator_AddTriangle_m056EC10F57F04B372B226616D055F3D238E2A489(__this, L_15, L_16, L_17, NULL);
		return;
	}
}
IL2CPP_EXTERN_C  void Tessellator_EdgeFlip_mC4C0DD9C08C3DB477698E335DCDEC76D0AEEE81A_AdjustorThunk (RuntimeObject* __this, int32_t ___0_i, int32_t ___1_j, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	Tessellator_EdgeFlip_mC4C0DD9C08C3DB477698E335DCDEC76D0AEEE81A(_thisAdjusted, ___0_i, ___1_j, method);
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_Flip_mBB5A8641BF0DB8D959F4ECC34DA80B9CAAC3229F (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_points, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___1_stack, int32_t* ___2_stackCount, int32_t ___3_a, int32_t ___4_b, int32_t ___5_x, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	{
		int32_t L_0 = ___3_a;
		int32_t L_1 = ___4_b;
		int32_t L_2;
		L_2 = Tessellator_OppositeOf_mB6E82B82152D79C874C4BEB6962348B5E408BCEE(__this, L_0, L_1, NULL);
		V_0 = L_2;
		int32_t L_3 = V_0;
		if ((((int32_t)L_3) >= ((int32_t)0)))
		{
			goto IL_0011;
		}
	}
	{
		return (bool)1;
	}

IL_0011:
	{
		int32_t L_4 = ___4_b;
		int32_t L_5 = ___3_a;
		if ((((int32_t)L_4) >= ((int32_t)L_5)))
		{
			goto IL_0025;
		}
	}
	{
		int32_t L_6 = ___3_a;
		int32_t L_7 = ___4_b;
		___3_a = L_7;
		___4_b = L_6;
		int32_t L_8 = ___5_x;
		int32_t L_9 = V_0;
		___5_x = L_9;
		V_0 = L_8;
	}

IL_0025:
	{
		int32_t L_10 = ___3_a;
		int32_t L_11 = ___4_b;
		int32_t L_12;
		L_12 = Tessellator_FindConstraint_m20B8DD4CC9007571111316603CFBA28FAE0E1A4A(__this, L_10, L_11, NULL);
		if ((((int32_t)L_12) == ((int32_t)(-1))))
		{
			goto IL_0034;
		}
	}
	{
		return (bool)1;
	}

IL_0034:
	{
		int32_t L_13 = ___3_a;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_14;
		L_14 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_13);
		int32_t L_15 = ___4_b;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_16;
		L_16 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_15);
		int32_t L_17 = ___5_x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_18;
		L_18 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_17);
		int32_t L_19 = V_0;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_20;
		L_20 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_19);
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		bool L_21;
		L_21 = ModuleHandle_IsInsideCircle_m7A080360A299D2F6BAF0390791DD36650D30AC2D(L_14, L_16, L_18, L_20, NULL);
		if (!L_21)
		{
			goto IL_008e;
		}
	}
	{
		int32_t* L_22 = ___2_stackCount;
		int32_t L_23 = *((int32_t*)L_22);
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_24 = ___1_stack;
		int32_t L_25;
		L_25 = IL2CPP_NATIVEARRAY_GET_LENGTH((L_24)->___m_Length);
		if ((((int32_t)((int32_t)il2cpp_codegen_add(2, L_23))) < ((int32_t)L_25)))
		{
			goto IL_006c;
		}
	}
	{
		return (bool)0;
	}

IL_006c:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_26 = ___1_stack;
		int32_t* L_27 = ___2_stackCount;
		int32_t* L_28 = ___2_stackCount;
		int32_t L_29 = *((int32_t*)L_28);
		V_1 = L_29;
		int32_t L_30 = V_1;
		*((int32_t*)L_27) = (int32_t)((int32_t)il2cpp_codegen_add(L_30, 1));
		int32_t L_31 = V_1;
		int32_t L_32 = ___3_a;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_26)->___m_Buffer, L_31, (L_32));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_33 = ___1_stack;
		int32_t* L_34 = ___2_stackCount;
		int32_t* L_35 = ___2_stackCount;
		int32_t L_36 = *((int32_t*)L_35);
		V_1 = L_36;
		int32_t L_37 = V_1;
		*((int32_t*)L_34) = (int32_t)((int32_t)il2cpp_codegen_add(L_37, 1));
		int32_t L_38 = V_1;
		int32_t L_39 = ___4_b;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_33)->___m_Buffer, L_38, (L_39));
	}

IL_008e:
	{
		return (bool)1;
	}
}
IL2CPP_EXTERN_C  bool Tessellator_Flip_mBB5A8641BF0DB8D959F4ECC34DA80B9CAAC3229F_AdjustorThunk (RuntimeObject* __this, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_points, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___1_stack, int32_t* ___2_stackCount, int32_t ___3_a, int32_t ___4_b, int32_t ___5_x, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	bool _returnValue;
	_returnValue = Tessellator_Flip_mBB5A8641BF0DB8D959F4ECC34DA80B9CAAC3229F(_thisAdjusted, ___0_points, ___1_stack, ___2_stackCount, ___3_a, ___4_b, ___5_x, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 Tessellator_GetCells_m737CD6BFBF6CDE13F2C88C9B1E0331051E9D6212 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t* ___0_count, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 V_3;
	memset((&V_3), 0, sizeof(V_3));
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	int32_t V_6 = 0;
	int32_t V_7 = 0;
	int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF V_8;
	memset((&V_8), 0, sizeof(V_8));
	int32_t V_9 = 0;
	{
		int32_t L_0 = __this->___m_NumPoints;
		int32_t L_1 = __this->___m_NumPoints;
		int32_t L_2 = __this->___m_Allocator;
		NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F((&V_0), ((int32_t)il2cpp_codegen_multiply(L_0, ((int32_t)il2cpp_codegen_add(L_1, 1)))), L_2, 1, NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F_RuntimeMethod_var);
		int32_t* L_3 = ___0_count;
		*((int32_t*)L_3) = (int32_t)0;
		V_1 = 0;
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_4 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_5;
		L_5 = IL2CPP_NATIVEARRAY_GET_LENGTH((L_4)->___m_Length);
		V_2 = L_5;
		goto IL_00c8;
	}

IL_0033:
	{
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_6 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_7 = V_1;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_8;
		L_8 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_6)->___m_Buffer, L_7);
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 L_9 = L_8.___points;
		V_3 = L_9;
		V_4 = 0;
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_10 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_11 = V_1;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_12;
		L_12 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_10)->___m_Buffer, L_11);
		int32_t L_13 = L_12.___pointCount;
		V_5 = L_13;
		goto IL_00be;
	}

IL_005d:
	{
		int32_t L_14 = V_4;
		int32_t L_15;
		L_15 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252((&V_3), L_14, ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		V_6 = L_15;
		int32_t L_16 = V_4;
		int32_t L_17;
		L_17 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252((&V_3), ((int32_t)il2cpp_codegen_add(L_16, 1)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		V_7 = L_17;
		int32_t L_18 = V_1;
		int32_t L_19 = V_6;
		int32_t L_20 = V_7;
		int32_t L_21;
		L_21 = math_min_m02D43DF516544C279AF660EA4731449C82991849_inline(L_19, L_20, NULL);
		if ((((int32_t)L_18) >= ((int32_t)L_21)))
		{
			goto IL_00b8;
		}
	}
	{
		il2cpp_codegen_initobj((&V_8), sizeof(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF));
		int32_t L_22 = V_1;
		(&V_8)->___x = L_22;
		int32_t L_23 = V_6;
		(&V_8)->___y = L_23;
		int32_t L_24 = V_7;
		(&V_8)->___z = L_24;
		int32_t* L_25 = ___0_count;
		int32_t* L_26 = ___0_count;
		int32_t L_27 = *((int32_t*)L_26);
		V_9 = L_27;
		int32_t L_28 = V_9;
		*((int32_t*)L_25) = (int32_t)((int32_t)il2cpp_codegen_add(L_28, 1));
		int32_t L_29 = V_9;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_30 = V_8;
		IL2CPP_NATIVEARRAY_SET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_0))->___m_Buffer, L_29, (L_30));
	}

IL_00b8:
	{
		int32_t L_31 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_add(L_31, 2));
	}

IL_00be:
	{
		int32_t L_32 = V_4;
		int32_t L_33 = V_5;
		if ((((int32_t)L_32) < ((int32_t)L_33)))
		{
			goto IL_005d;
		}
	}
	{
		int32_t L_34 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_34, 1));
	}

IL_00c8:
	{
		int32_t L_35 = V_1;
		int32_t L_36 = V_2;
		if ((((int32_t)L_35) < ((int32_t)L_36)))
		{
			goto IL_0033;
		}
	}
	{
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 L_37 = V_0;
		return L_37;
	}
}
IL2CPP_EXTERN_C  NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 Tessellator_GetCells_m737CD6BFBF6CDE13F2C88C9B1E0331051E9D6212_AdjustorThunk (RuntimeObject* __this, int32_t* ___0_count, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 _returnValue;
	_returnValue = Tessellator_GetCells_m737CD6BFBF6CDE13F2C88C9B1E0331051E9D6212(_thisAdjusted, ___0_count, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_ApplyDelaunay_m97F59A65E5BAA3573864BC238165FDB8D14A0AD0 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_points, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___1_edges, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	bool V_2 = false;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 V_5;
	memset((&V_5), 0, sizeof(V_5));
	int32_t V_6 = 0;
	int32_t V_7 = 0;
	int32_t V_8 = 0;
	int32_t V_9 = 0;
	int32_t V_10 = 0;
	int32_t V_11 = 0;
	int32_t V_12 = 0;
	int32_t V_13 = 0;
	int32_t V_14 = 0;
	UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 V_15;
	memset((&V_15), 0, sizeof(V_15));
	int32_t V_16 = 0;
	int32_t V_17 = 0;
	int32_t V_18 = 0;
	int32_t G_B35_0 = 0;
	int32_t G_B38_0 = 0;
	int32_t G_B41_0 = 0;
	int32_t G_B44_0 = 0;
	{
		int32_t L_0 = __this->___m_CellCount;
		if (L_0)
		{
			goto IL_000a;
		}
	}
	{
		return (bool)0;
	}

IL_000a:
	{
		int32_t L_1 = __this->___m_NumPoints;
		int32_t L_2 = __this->___m_NumPoints;
		int32_t L_3 = __this->___m_Allocator;
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&V_0), ((int32_t)il2cpp_codegen_multiply(L_1, ((int32_t)il2cpp_codegen_add(L_2, 1)))), L_3, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		V_1 = 0;
		V_2 = (bool)1;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_4 = ___1_edges;
		int32_t L_5 = __this->___m_NumEdges;
		Tessellator_PrepareDelaunay_mC18519EEF84FC79C0C98F273D1AF0FCBE4CFDC1D(__this, L_4, L_5, NULL);
		V_4 = 0;
		goto IL_0147;
	}

IL_0040:
	{
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_6 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_7 = V_4;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_8;
		L_8 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_6)->___m_Buffer, L_7);
		V_5 = L_8;
		V_6 = 1;
		goto IL_0133;
	}

IL_0057:
	{
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_9 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___points);
		int32_t L_10 = V_6;
		int32_t L_11;
		L_11 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_9, L_10, ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		V_7 = L_11;
		int32_t L_12 = V_7;
		int32_t L_13 = V_4;
		if ((((int32_t)L_12) < ((int32_t)L_13)))
		{
			goto IL_012d;
		}
	}
	{
		int32_t L_14 = V_4;
		int32_t L_15 = V_7;
		int32_t L_16;
		L_16 = Tessellator_FindConstraint_m20B8DD4CC9007571111316603CFBA28FAE0E1A4A(__this, L_14, L_15, NULL);
		if ((((int32_t)L_16) >= ((int32_t)0)))
		{
			goto IL_012d;
		}
	}
	{
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_17 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___points);
		int32_t L_18 = V_6;
		int32_t L_19;
		L_19 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_17, ((int32_t)il2cpp_codegen_subtract(L_18, 1)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		V_8 = L_19;
		V_9 = (-1);
		V_10 = 1;
		goto IL_00c6;
	}

IL_009a:
	{
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_20 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___points);
		int32_t L_21 = V_10;
		int32_t L_22;
		L_22 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_20, ((int32_t)il2cpp_codegen_subtract(L_21, 1)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		int32_t L_23 = V_7;
		if ((!(((uint32_t)L_22) == ((uint32_t)L_23))))
		{
			goto IL_00c0;
		}
	}
	{
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_24 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_5)->___points);
		int32_t L_25 = V_10;
		int32_t L_26;
		L_26 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_24, L_25, ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		V_9 = L_26;
		goto IL_00d1;
	}

IL_00c0:
	{
		int32_t L_27 = V_10;
		V_10 = ((int32_t)il2cpp_codegen_add(L_27, 2));
	}

IL_00c6:
	{
		int32_t L_28 = V_10;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_29 = V_5;
		int32_t L_30 = L_29.___pointCount;
		if ((((int32_t)L_28) < ((int32_t)L_30)))
		{
			goto IL_009a;
		}
	}

IL_00d1:
	{
		int32_t L_31 = V_9;
		if ((((int32_t)L_31) < ((int32_t)0)))
		{
			goto IL_012d;
		}
	}
	{
		int32_t L_32 = V_4;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_33;
		L_33 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_32);
		int32_t L_34 = V_7;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_35;
		L_35 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_34);
		int32_t L_36 = V_8;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_37;
		L_37 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_36);
		int32_t L_38 = V_9;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_39;
		L_39 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_38);
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		bool L_40;
		L_40 = ModuleHandle_IsInsideCircle_m7A080360A299D2F6BAF0390791DD36650D30AC2D(L_33, L_35, L_37, L_39, NULL);
		if (!L_40)
		{
			goto IL_012d;
		}
	}
	{
		int32_t L_41 = V_1;
		int32_t L_42;
		L_42 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&V_0))->___m_Length);
		if ((((int32_t)((int32_t)il2cpp_codegen_add(2, L_41))) < ((int32_t)L_42)))
		{
			goto IL_0111;
		}
	}
	{
		V_2 = (bool)0;
		goto IL_0141;
	}

IL_0111:
	{
		int32_t L_43 = V_1;
		int32_t L_44 = L_43;
		V_1 = ((int32_t)il2cpp_codegen_add(L_44, 1));
		int32_t L_45 = V_4;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, ((&V_0))->___m_Buffer, L_44, (L_45));
		int32_t L_46 = V_1;
		int32_t L_47 = L_46;
		V_1 = ((int32_t)il2cpp_codegen_add(L_47, 1));
		int32_t L_48 = V_7;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, ((&V_0))->___m_Buffer, L_47, (L_48));
	}

IL_012d:
	{
		int32_t L_49 = V_6;
		V_6 = ((int32_t)il2cpp_codegen_add(L_49, 2));
	}

IL_0133:
	{
		int32_t L_50 = V_6;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_51 = V_5;
		int32_t L_52 = L_51.___pointCount;
		if ((((int32_t)L_50) < ((int32_t)L_52)))
		{
			goto IL_0057;
		}
	}

IL_0141:
	{
		int32_t L_53 = V_4;
		V_4 = ((int32_t)il2cpp_codegen_add(L_53, 1));
	}

IL_0147:
	{
		bool L_54 = V_2;
		if (!L_54)
		{
			goto IL_0157;
		}
	}
	{
		int32_t L_55 = V_4;
		int32_t L_56 = __this->___m_NumPoints;
		if ((((int32_t)L_55) < ((int32_t)L_56)))
		{
			goto IL_0040;
		}
	}

IL_0157:
	{
		int32_t L_57 = __this->___m_NumPoints;
		int32_t L_58 = __this->___m_NumPoints;
		V_3 = ((int32_t)il2cpp_codegen_multiply(L_57, L_58));
		goto IL_029b;
	}

IL_016a:
	{
		int32_t L_59 = V_1;
		int32_t L_60;
		L_60 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&V_0))->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_59, 1)));
		V_11 = L_60;
		int32_t L_61 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_subtract(L_61, 1));
		int32_t L_62 = V_1;
		int32_t L_63;
		L_63 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&V_0))->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_62, 1)));
		V_12 = L_63;
		int32_t L_64 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_subtract(L_64, 1));
		V_13 = (-1);
		V_14 = (-1);
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_65 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		int32_t L_66 = V_12;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_67;
		L_67 = IL2CPP_NATIVEARRAY_GET_ITEM(UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4, (L_65)->___m_Buffer, L_66);
		V_15 = L_67;
		V_16 = 1;
		goto IL_01e2;
	}

IL_01a4:
	{
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_68 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_15)->___points);
		int32_t L_69 = V_16;
		int32_t L_70;
		L_70 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_68, ((int32_t)il2cpp_codegen_subtract(L_69, 1)), ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		V_17 = L_70;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* L_71 = (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03*)(&(&V_15)->___points);
		int32_t L_72 = V_16;
		int32_t L_73;
		L_73 = ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252(L_71, L_72, ArraySlice_1_get_Item_m3B707184EF2540392346924800E5C7234A4C4252_RuntimeMethod_var);
		V_18 = L_73;
		int32_t L_74 = V_17;
		int32_t L_75 = V_11;
		if ((!(((uint32_t)L_74) == ((uint32_t)L_75))))
		{
			goto IL_01d2;
		}
	}
	{
		int32_t L_76 = V_18;
		V_14 = L_76;
		goto IL_01dc;
	}

IL_01d2:
	{
		int32_t L_77 = V_18;
		int32_t L_78 = V_11;
		if ((!(((uint32_t)L_77) == ((uint32_t)L_78))))
		{
			goto IL_01dc;
		}
	}
	{
		int32_t L_79 = V_17;
		V_13 = L_79;
	}

IL_01dc:
	{
		int32_t L_80 = V_16;
		V_16 = ((int32_t)il2cpp_codegen_add(L_80, 2));
	}

IL_01e2:
	{
		int32_t L_81 = V_16;
		UStar_t44BAFB3CDE2A6D37FF4F48B038D7D920F8F47BD4 L_82 = V_15;
		int32_t L_83 = L_82.___pointCount;
		if ((((int32_t)L_81) < ((int32_t)L_83)))
		{
			goto IL_01a4;
		}
	}
	{
		int32_t L_84 = V_13;
		if ((((int32_t)L_84) < ((int32_t)0)))
		{
			goto IL_029b;
		}
	}
	{
		int32_t L_85 = V_14;
		if ((((int32_t)L_85) < ((int32_t)0)))
		{
			goto IL_029b;
		}
	}
	{
		int32_t L_86 = V_12;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_87;
		L_87 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_86);
		int32_t L_88 = V_11;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_89;
		L_89 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_88);
		int32_t L_90 = V_13;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_91;
		L_91 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_90);
		int32_t L_92 = V_14;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_93;
		L_93 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_92);
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		bool L_94;
		L_94 = ModuleHandle_IsInsideCircle_m7A080360A299D2F6BAF0390791DD36650D30AC2D(L_87, L_89, L_91, L_93, NULL);
		if (!L_94)
		{
			goto IL_029b;
		}
	}
	{
		int32_t L_95 = V_12;
		int32_t L_96 = V_11;
		Tessellator_EdgeFlip_mC4C0DD9C08C3DB477698E335DCDEC76D0AEEE81A(__this, L_95, L_96, NULL);
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_97 = ___0_points;
		int32_t L_98 = V_13;
		int32_t L_99 = V_12;
		int32_t L_100 = V_14;
		bool L_101;
		L_101 = Tessellator_Flip_mBB5A8641BF0DB8D959F4ECC34DA80B9CAAC3229F(__this, L_97, (&V_0), (&V_1), L_98, L_99, L_100, NULL);
		V_2 = L_101;
		bool L_102 = V_2;
		if (!L_102)
		{
			goto IL_025a;
		}
	}
	{
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_103 = ___0_points;
		int32_t L_104 = V_12;
		int32_t L_105 = V_14;
		int32_t L_106 = V_13;
		bool L_107;
		L_107 = Tessellator_Flip_mBB5A8641BF0DB8D959F4ECC34DA80B9CAAC3229F(__this, L_103, (&V_0), (&V_1), L_104, L_105, L_106, NULL);
		G_B35_0 = ((int32_t)(L_107));
		goto IL_025b;
	}

IL_025a:
	{
		G_B35_0 = 0;
	}

IL_025b:
	{
		V_2 = (bool)G_B35_0;
		bool L_108 = V_2;
		if (!L_108)
		{
			goto IL_0272;
		}
	}
	{
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_109 = ___0_points;
		int32_t L_110 = V_14;
		int32_t L_111 = V_11;
		int32_t L_112 = V_13;
		bool L_113;
		L_113 = Tessellator_Flip_mBB5A8641BF0DB8D959F4ECC34DA80B9CAAC3229F(__this, L_109, (&V_0), (&V_1), L_110, L_111, L_112, NULL);
		G_B38_0 = ((int32_t)(L_113));
		goto IL_0273;
	}

IL_0272:
	{
		G_B38_0 = 0;
	}

IL_0273:
	{
		V_2 = (bool)G_B38_0;
		bool L_114 = V_2;
		if (!L_114)
		{
			goto IL_028a;
		}
	}
	{
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_115 = ___0_points;
		int32_t L_116 = V_11;
		int32_t L_117 = V_13;
		int32_t L_118 = V_14;
		bool L_119;
		L_119 = Tessellator_Flip_mBB5A8641BF0DB8D959F4ECC34DA80B9CAAC3229F(__this, L_115, (&V_0), (&V_1), L_116, L_117, L_118, NULL);
		G_B41_0 = ((int32_t)(L_119));
		goto IL_028b;
	}

IL_028a:
	{
		G_B41_0 = 0;
	}

IL_028b:
	{
		V_2 = (bool)G_B41_0;
		bool L_120 = V_2;
		if (!L_120)
		{
			goto IL_0299;
		}
	}
	{
		int32_t L_121 = V_3;
		int32_t L_122 = ((int32_t)il2cpp_codegen_subtract(L_121, 1));
		V_3 = L_122;
		G_B44_0 = ((((int32_t)L_122) > ((int32_t)0))? 1 : 0);
		goto IL_029a;
	}

IL_0299:
	{
		G_B44_0 = 0;
	}

IL_029a:
	{
		V_2 = (bool)G_B44_0;
	}

IL_029b:
	{
		int32_t L_123 = V_1;
		bool L_124 = V_2;
		if (((int32_t)(((((int32_t)L_123) > ((int32_t)0))? 1 : 0)&(int32_t)L_124)))
		{
			goto IL_016a;
		}
	}
	{
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E((&V_0), NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		bool L_125 = V_2;
		return L_125;
	}
}
IL2CPP_EXTERN_C  bool Tessellator_ApplyDelaunay_m97F59A65E5BAA3573864BC238165FDB8D14A0AD0_AdjustorThunk (RuntimeObject* __this, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_points, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___1_edges, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	bool _returnValue;
	_returnValue = Tessellator_ApplyDelaunay_m97F59A65E5BAA3573864BC238165FDB8D14A0AD0(_thisAdjusted, ___0_points, ___1_edges, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t Tessellator_FindNeighbor_m3B762808E6088E8981D42BA431435A4B6EDC188F (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 ___0_cells, int32_t ___1_count, int32_t ___2_a, int32_t ___3_b, int32_t ___4_c, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_GetEqual_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1_mA2DC9A659A83000A07E39BAAFFA6588DF23C361A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF V_3;
	memset((&V_3), 0, sizeof(V_3));
	TestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1 V_4;
	memset((&V_4), 0, sizeof(V_4));
	{
		int32_t L_0 = ___2_a;
		V_0 = L_0;
		int32_t L_1 = ___3_b;
		V_1 = L_1;
		int32_t L_2 = ___4_c;
		V_2 = L_2;
		int32_t L_3 = ___3_b;
		int32_t L_4 = ___4_c;
		if ((((int32_t)L_3) >= ((int32_t)L_4)))
		{
			goto IL_001d;
		}
	}
	{
		int32_t L_5 = ___3_b;
		int32_t L_6 = ___2_a;
		if ((((int32_t)L_5) >= ((int32_t)L_6)))
		{
			goto IL_002a;
		}
	}
	{
		int32_t L_7 = ___3_b;
		V_0 = L_7;
		int32_t L_8 = ___4_c;
		V_1 = L_8;
		int32_t L_9 = ___2_a;
		V_2 = L_9;
		goto IL_002a;
	}

IL_001d:
	{
		int32_t L_10 = ___4_c;
		int32_t L_11 = ___2_a;
		if ((((int32_t)L_10) >= ((int32_t)L_11)))
		{
			goto IL_002a;
		}
	}
	{
		int32_t L_12 = ___4_c;
		V_0 = L_12;
		int32_t L_13 = ___2_a;
		V_1 = L_13;
		int32_t L_14 = ___3_b;
		V_2 = L_14;
	}

IL_002a:
	{
		int32_t L_15 = V_0;
		if ((((int32_t)L_15) >= ((int32_t)0)))
		{
			goto IL_0030;
		}
	}
	{
		return (-1);
	}

IL_0030:
	{
		int32_t L_16 = V_0;
		(&V_3)->___x = L_16;
		int32_t L_17 = V_1;
		(&V_3)->___y = L_17;
		int32_t L_18 = V_2;
		(&V_3)->___z = L_18;
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 L_19 = ___0_cells;
		int32_t L_20 = ___1_count;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_21 = V_3;
		il2cpp_codegen_initobj((&V_4), sizeof(TestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1));
		TestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1 L_22 = V_4;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_23;
		L_23 = ModuleHandle_GetEqual_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1_mA2DC9A659A83000A07E39BAAFFA6588DF23C361A(L_19, L_20, L_21, L_22, ModuleHandle_GetEqual_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1_mA2DC9A659A83000A07E39BAAFFA6588DF23C361A_RuntimeMethod_var);
		return L_23;
	}
}
IL2CPP_EXTERN_C  int32_t Tessellator_FindNeighbor_m3B762808E6088E8981D42BA431435A4B6EDC188F_AdjustorThunk (RuntimeObject* __this, NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 ___0_cells, int32_t ___1_count, int32_t ___2_a, int32_t ___3_b, int32_t ___4_c, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	int32_t _returnValue;
	_returnValue = Tessellator_FindNeighbor_m3B762808E6088E8981D42BA431435A4B6EDC188F(_thisAdjusted, ___0_cells, ___1_count, ___2_a, ___3_b, ___4_c, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 Tessellator_Constrain_m8215808ACAA44BFA3312A4F1F46ADE90D040DE2F (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t* ___0_count, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_InsertionSort_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE_mB73DA078075FCD273BA172C5E5D6EEDDBFA8279D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_m9322523E8F4F331EE08D7DE23A5F5E48B851AF00_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C V_2;
	memset((&V_2), 0, sizeof(V_2));
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C V_3;
	memset((&V_3), 0, sizeof(V_3));
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	int32_t V_6 = 0;
	int32_t V_7 = 0;
	int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF V_8;
	memset((&V_8), 0, sizeof(V_8));
	int32_t V_9 = 0;
	int32_t V_10 = 0;
	int32_t V_11 = 0;
	TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE V_12;
	memset((&V_12), 0, sizeof(V_12));
	int32_t V_13 = 0;
	int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF V_14;
	memset((&V_14), 0, sizeof(V_14));
	int32_t V_15 = 0;
	int32_t V_16 = 0;
	int32_t V_17 = 0;
	int32_t V_18 = 0;
	int32_t V_19 = 0;
	int32_t V_20 = 0;
	int32_t V_21 = 0;
	int32_t V_22 = 0;
	int32_t V_23 = 0;
	int32_t V_24 = 0;
	int32_t G_B15_0 = 0;
	int32_t G_B20_0 = 0;
	int32_t G_B22_0 = 0;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* G_B22_1 = NULL;
	int32_t G_B22_2 = 0;
	int32_t G_B21_0 = 0;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* G_B21_1 = NULL;
	int32_t G_B21_2 = 0;
	int32_t G_B23_0 = 0;
	int32_t G_B23_1 = 0;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* G_B23_2 = NULL;
	int32_t G_B23_3 = 0;
	{
		int32_t* L_0 = ___0_count;
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 L_1;
		L_1 = Tessellator_GetCells_m737CD6BFBF6CDE13F2C88C9B1E0331051E9D6212(__this, L_0, NULL);
		V_0 = L_1;
		int32_t* L_2 = ___0_count;
		int32_t L_3 = *((int32_t*)L_2);
		V_1 = L_3;
		V_7 = 0;
		goto IL_0094;
	}

IL_0013:
	{
		int32_t L_4 = V_7;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_5;
		L_5 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_0))->___m_Buffer, L_4);
		V_8 = L_5;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_6 = V_8;
		int32_t L_7 = L_6.___x;
		V_9 = L_7;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_8 = V_8;
		int32_t L_9 = L_8.___y;
		V_10 = L_9;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_10 = V_8;
		int32_t L_11 = L_10.___z;
		V_11 = L_11;
		int32_t L_12 = V_10;
		int32_t L_13 = V_11;
		if ((((int32_t)L_12) >= ((int32_t)L_13)))
		{
			goto IL_0062;
		}
	}
	{
		int32_t L_14 = V_10;
		int32_t L_15 = V_9;
		if ((((int32_t)L_14) >= ((int32_t)L_15)))
		{
			goto IL_0083;
		}
	}
	{
		int32_t L_16 = V_10;
		(&V_8)->___x = L_16;
		int32_t L_17 = V_11;
		(&V_8)->___y = L_17;
		int32_t L_18 = V_9;
		(&V_8)->___z = L_18;
		goto IL_0083;
	}

IL_0062:
	{
		int32_t L_19 = V_11;
		int32_t L_20 = V_9;
		if ((((int32_t)L_19) >= ((int32_t)L_20)))
		{
			goto IL_0083;
		}
	}
	{
		int32_t L_21 = V_11;
		(&V_8)->___x = L_21;
		int32_t L_22 = V_9;
		(&V_8)->___y = L_22;
		int32_t L_23 = V_10;
		(&V_8)->___z = L_23;
	}

IL_0083:
	{
		int32_t L_24 = V_7;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_25 = V_8;
		IL2CPP_NATIVEARRAY_SET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_0))->___m_Buffer, L_24, (L_25));
		int32_t L_26 = V_7;
		V_7 = ((int32_t)il2cpp_codegen_add(L_26, 1));
	}

IL_0094:
	{
		int32_t L_27 = V_7;
		int32_t L_28 = V_1;
		if ((((int32_t)L_27) < ((int32_t)L_28)))
		{
			goto IL_0013;
		}
	}
	{
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 L_29 = V_0;
		void* L_30;
		L_30 = NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_m9322523E8F4F331EE08D7DE23A5F5E48B851AF00(L_29, NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_m9322523E8F4F331EE08D7DE23A5F5E48B851AF00_RuntimeMethod_var);
		int32_t L_31 = __this->___m_CellCount;
		il2cpp_codegen_initobj((&V_12), sizeof(TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE));
		TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE L_32 = V_12;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_InsertionSort_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE_mB73DA078075FCD273BA172C5E5D6EEDDBFA8279D(L_30, 0, ((int32_t)il2cpp_codegen_subtract(L_31, 1)), L_32, ModuleHandle_InsertionSort_Tisint3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF_TisTessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE_mB73DA078075FCD273BA172C5E5D6EEDDBFA8279D_RuntimeMethod_var);
		int32_t L_33 = V_1;
		int32_t L_34 = __this->___m_Allocator;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_35;
		memset((&L_35), 0, sizeof(L_35));
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&L_35), L_33, L_34, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		__this->___m_Flags = L_35;
		int32_t L_36 = V_1;
		int32_t L_37 = __this->___m_Allocator;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_38;
		memset((&L_38), 0, sizeof(L_38));
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&L_38), ((int32_t)il2cpp_codegen_multiply(L_36, 3)), L_37, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		__this->___m_Neighbors = L_38;
		int32_t L_39 = V_1;
		int32_t L_40 = __this->___m_Allocator;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_41;
		memset((&L_41), 0, sizeof(L_41));
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&L_41), ((int32_t)il2cpp_codegen_multiply(L_39, 3)), L_40, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		__this->___m_Constraints = L_41;
		int32_t L_42 = V_1;
		int32_t L_43 = __this->___m_Allocator;
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&V_2), ((int32_t)il2cpp_codegen_multiply(L_42, 3)), L_43, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		int32_t L_44 = V_1;
		int32_t L_45 = __this->___m_Allocator;
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&V_3), ((int32_t)il2cpp_codegen_multiply(L_44, 3)), L_45, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		V_4 = 1;
		V_5 = 0;
		V_6 = 0;
		V_13 = 0;
		goto IL_0238;
	}

IL_012a:
	{
		int32_t L_46 = V_13;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_47;
		L_47 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_0))->___m_Buffer, L_46);
		V_14 = L_47;
		V_15 = 0;
		goto IL_022a;
	}

IL_013d:
	{
		int32_t L_48 = V_15;
		V_16 = L_48;
		int32_t L_49 = V_15;
		V_17 = ((int32_t)(((int32_t)il2cpp_codegen_add(L_49, 1))%3));
		int32_t L_50 = V_16;
		if (!L_50)
		{
			goto IL_0164;
		}
	}
	{
		int32_t L_51 = V_15;
		if ((((int32_t)L_51) == ((int32_t)1)))
		{
			goto IL_015b;
		}
	}
	{
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_52 = V_14;
		int32_t L_53 = L_52.___z;
		G_B15_0 = L_53;
		goto IL_016b;
	}

IL_015b:
	{
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_54 = V_14;
		int32_t L_55 = L_54.___y;
		G_B15_0 = L_55;
		goto IL_016b;
	}

IL_0164:
	{
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_56 = V_14;
		int32_t L_57 = L_56.___x;
		G_B15_0 = L_57;
	}

IL_016b:
	{
		V_16 = G_B15_0;
		int32_t L_58 = V_17;
		if (!L_58)
		{
			goto IL_0188;
		}
	}
	{
		int32_t L_59 = V_17;
		if ((((int32_t)L_59) == ((int32_t)1)))
		{
			goto IL_017f;
		}
	}
	{
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_60 = V_14;
		int32_t L_61 = L_60.___z;
		G_B20_0 = L_61;
		goto IL_018f;
	}

IL_017f:
	{
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_62 = V_14;
		int32_t L_63 = L_62.___y;
		G_B20_0 = L_63;
		goto IL_018f;
	}

IL_0188:
	{
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_64 = V_14;
		int32_t L_65 = L_64.___x;
		G_B20_0 = L_65;
	}

IL_018f:
	{
		V_17 = G_B20_0;
		int32_t L_66 = V_17;
		int32_t L_67 = V_16;
		int32_t L_68;
		L_68 = Tessellator_OppositeOf_mB6E82B82152D79C874C4BEB6962348B5E408BCEE(__this, L_66, L_67, NULL);
		V_18 = L_68;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_69 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Neighbors);
		int32_t L_70 = V_13;
		int32_t L_71 = V_15;
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 L_72 = V_0;
		int32_t* L_73 = ___0_count;
		int32_t L_74 = *((int32_t*)L_73);
		int32_t L_75 = V_17;
		int32_t L_76 = V_16;
		int32_t L_77 = V_18;
		int32_t L_78;
		L_78 = Tessellator_FindNeighbor_m3B762808E6088E8981D42BA431435A4B6EDC188F(__this, L_72, L_74, L_75, L_76, L_77, NULL);
		int32_t L_79 = L_78;
		V_20 = L_79;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_69)->___m_Buffer, ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_multiply(3, L_70)), L_71)), (L_79));
		int32_t L_80 = V_20;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_81 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Constraints);
		int32_t L_82 = V_13;
		int32_t L_83 = V_15;
		int32_t L_84 = V_16;
		int32_t L_85 = V_17;
		int32_t L_86;
		L_86 = Tessellator_FindConstraint_m20B8DD4CC9007571111316603CFBA28FAE0E1A4A(__this, L_84, L_85, NULL);
		if ((!(((uint32_t)(-1)) == ((uint32_t)L_86))))
		{
			G_B22_0 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_multiply(3, L_82)), L_83));
			G_B22_1 = L_81;
			G_B22_2 = L_80;
			goto IL_01e0;
		}
		G_B21_0 = ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_multiply(3, L_82)), L_83));
		G_B21_1 = L_81;
		G_B21_2 = L_80;
	}
	{
		G_B23_0 = 0;
		G_B23_1 = G_B21_0;
		G_B23_2 = G_B21_1;
		G_B23_3 = G_B21_2;
		goto IL_01e1;
	}

IL_01e0:
	{
		G_B23_0 = 1;
		G_B23_1 = G_B22_0;
		G_B23_2 = G_B22_1;
		G_B23_3 = G_B22_2;
	}

IL_01e1:
	{
		int32_t L_87 = G_B23_0;
		V_20 = L_87;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (G_B23_2)->___m_Buffer, G_B23_1, (L_87));
		int32_t L_88 = V_20;
		V_19 = L_88;
		if ((((int32_t)G_B23_3) >= ((int32_t)0)))
		{
			goto IL_0224;
		}
	}
	{
		int32_t L_89 = V_19;
		if (!L_89)
		{
			goto IL_0206;
		}
	}
	{
		int32_t L_90 = V_5;
		int32_t L_91 = L_90;
		V_5 = ((int32_t)il2cpp_codegen_add(L_91, 1));
		int32_t L_92 = V_13;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, ((&V_2))->___m_Buffer, L_91, (L_92));
		goto IL_0224;
	}

IL_0206:
	{
		int32_t L_93 = V_6;
		int32_t L_94 = L_93;
		V_6 = ((int32_t)il2cpp_codegen_add(L_94, 1));
		int32_t L_95 = V_13;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, ((&V_3))->___m_Buffer, L_94, (L_95));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_96 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Flags);
		int32_t L_97 = V_13;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_96)->___m_Buffer, L_97, (1));
	}

IL_0224:
	{
		int32_t L_98 = V_15;
		V_15 = ((int32_t)il2cpp_codegen_add(L_98, 1));
	}

IL_022a:
	{
		int32_t L_99 = V_15;
		if ((((int32_t)L_99) < ((int32_t)3)))
		{
			goto IL_013d;
		}
	}
	{
		int32_t L_100 = V_13;
		V_13 = ((int32_t)il2cpp_codegen_add(L_100, 1));
	}

IL_0238:
	{
		int32_t L_101 = V_13;
		int32_t L_102 = V_1;
		if ((((int32_t)L_101) < ((int32_t)L_102)))
		{
			goto IL_012a;
		}
	}
	{
		goto IL_033a;
	}

IL_0245:
	{
		int32_t L_103 = V_6;
		int32_t L_104;
		L_104 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&V_3))->___m_Buffer, ((int32_t)il2cpp_codegen_subtract(L_103, 1)));
		V_21 = L_104;
		int32_t L_105 = V_6;
		V_6 = ((int32_t)il2cpp_codegen_subtract(L_105, 1));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_106 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Flags);
		int32_t L_107 = V_21;
		int32_t L_108;
		L_108 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_106)->___m_Buffer, L_107);
		int32_t L_109 = V_4;
		if ((((int32_t)L_108) == ((int32_t)((-L_109)))))
		{
			goto IL_0303;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_110 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Flags);
		int32_t L_111 = V_21;
		int32_t L_112 = V_4;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_110)->___m_Buffer, L_111, (L_112));
		int32_t L_113 = V_21;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_114;
		L_114 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_0))->___m_Buffer, L_113);
		V_22 = 0;
		goto IL_02fe;
	}

IL_028b:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_115 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Neighbors);
		int32_t L_116 = V_21;
		int32_t L_117 = V_22;
		int32_t L_118;
		L_118 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_115)->___m_Buffer, ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_multiply(3, L_116)), L_117)));
		V_23 = L_118;
		int32_t L_119 = V_23;
		if ((((int32_t)L_119) < ((int32_t)0)))
		{
			goto IL_02f8;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_120 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Flags);
		int32_t L_121 = V_23;
		int32_t L_122;
		L_122 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_120)->___m_Buffer, L_121);
		if (L_122)
		{
			goto IL_02f8;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_123 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Constraints);
		int32_t L_124 = V_21;
		int32_t L_125 = V_22;
		int32_t L_126;
		L_126 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_123)->___m_Buffer, ((int32_t)il2cpp_codegen_add(((int32_t)il2cpp_codegen_multiply(3, L_124)), L_125)));
		if (!L_126)
		{
			goto IL_02d9;
		}
	}
	{
		int32_t L_127 = V_5;
		int32_t L_128 = L_127;
		V_5 = ((int32_t)il2cpp_codegen_add(L_128, 1));
		int32_t L_129 = V_23;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, ((&V_2))->___m_Buffer, L_128, (L_129));
		goto IL_02f8;
	}

IL_02d9:
	{
		int32_t L_130 = V_6;
		int32_t L_131 = L_130;
		V_6 = ((int32_t)il2cpp_codegen_add(L_131, 1));
		int32_t L_132 = V_23;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, ((&V_3))->___m_Buffer, L_131, (L_132));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_133 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Flags);
		int32_t L_134 = V_23;
		int32_t L_135 = V_4;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_133)->___m_Buffer, L_134, (L_135));
	}

IL_02f8:
	{
		int32_t L_136 = V_22;
		V_22 = ((int32_t)il2cpp_codegen_add(L_136, 1));
	}

IL_02fe:
	{
		int32_t L_137 = V_22;
		if ((((int32_t)L_137) < ((int32_t)3)))
		{
			goto IL_028b;
		}
	}

IL_0303:
	{
		int32_t L_138 = V_6;
		if ((((int32_t)L_138) > ((int32_t)0)))
		{
			goto IL_0245;
		}
	}
	{
		V_24 = 0;
		goto IL_0328;
	}

IL_0310:
	{
		int32_t L_139 = V_24;
		int32_t L_140 = V_24;
		int32_t L_141;
		L_141 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&V_2))->___m_Buffer, L_140);
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, ((&V_3))->___m_Buffer, L_139, (L_141));
		int32_t L_142 = V_24;
		V_24 = ((int32_t)il2cpp_codegen_add(L_142, 1));
	}

IL_0328:
	{
		int32_t L_143 = V_24;
		int32_t L_144 = V_5;
		if ((((int32_t)L_143) < ((int32_t)L_144)))
		{
			goto IL_0310;
		}
	}
	{
		int32_t L_145 = V_5;
		V_6 = L_145;
		V_5 = 0;
		int32_t L_146 = V_4;
		V_4 = ((-L_146));
	}

IL_033a:
	{
		int32_t L_147 = V_6;
		if ((((int32_t)L_147) > ((int32_t)0)))
		{
			goto IL_0303;
		}
	}
	{
		int32_t L_148 = V_5;
		if ((((int32_t)L_148) > ((int32_t)0)))
		{
			goto IL_0303;
		}
	}
	{
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E((&V_3), NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E((&V_2), NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 L_149 = V_0;
		return L_149;
	}
}
IL2CPP_EXTERN_C  NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 Tessellator_Constrain_m8215808ACAA44BFA3312A4F1F46ADE90D040DE2F_AdjustorThunk (RuntimeObject* __this, int32_t* ___0_count, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 _returnValue;
	_returnValue = Tessellator_Constrain_m8215808ACAA44BFA3312A4F1F46ADE90D040DE2F(_thisAdjusted, ___0_count, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 Tessellator_RemoveExterior_m9D5D1813823280A5BDBAF36CFBE713280079011F (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t* ___0_cellCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 V_1;
	memset((&V_1), 0, sizeof(V_1));
	NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 V_2;
	memset((&V_2), 0, sizeof(V_2));
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	{
		V_0 = 0;
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 L_0;
		L_0 = Tessellator_Constrain_m8215808ACAA44BFA3312A4F1F46ADE90D040DE2F(__this, (&V_0), NULL);
		V_1 = L_0;
		int32_t L_1 = V_0;
		int32_t L_2 = __this->___m_Allocator;
		NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F((&V_2), L_1, L_2, 1, NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F_RuntimeMethod_var);
		int32_t* L_3 = ___0_cellCount;
		*((int32_t*)L_3) = (int32_t)0;
		V_3 = 0;
		goto IL_004f;
	}

IL_0021:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_4 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Flags);
		int32_t L_5 = V_3;
		int32_t L_6;
		L_6 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_4)->___m_Buffer, L_5);
		if ((!(((uint32_t)L_6) == ((uint32_t)(-1)))))
		{
			goto IL_004b;
		}
	}
	{
		int32_t* L_7 = ___0_cellCount;
		int32_t* L_8 = ___0_cellCount;
		int32_t L_9 = *((int32_t*)L_8);
		V_4 = L_9;
		int32_t L_10 = V_4;
		*((int32_t*)L_7) = (int32_t)((int32_t)il2cpp_codegen_add(L_10, 1));
		int32_t L_11 = V_4;
		int32_t L_12 = V_3;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_13;
		L_13 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_1))->___m_Buffer, L_12);
		IL2CPP_NATIVEARRAY_SET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_2))->___m_Buffer, L_11, (L_13));
	}

IL_004b:
	{
		int32_t L_14 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_add(L_14, 1));
	}

IL_004f:
	{
		int32_t L_15 = V_3;
		int32_t L_16 = V_0;
		if ((((int32_t)L_15) < ((int32_t)L_16)))
		{
			goto IL_0021;
		}
	}
	{
		NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213((&V_1), NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213_RuntimeMethod_var);
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 L_17 = V_2;
		return L_17;
	}
}
IL2CPP_EXTERN_C  NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 Tessellator_RemoveExterior_m9D5D1813823280A5BDBAF36CFBE713280079011F_AdjustorThunk (RuntimeObject* __this, int32_t* ___0_cellCount, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 _returnValue;
	_returnValue = Tessellator_RemoveExterior_m9D5D1813823280A5BDBAF36CFBE713280079011F(_thisAdjusted, ___0_cellCount, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 Tessellator_RemoveInterior_m9D9D80F21881D933B53DF8CC4FEA4B6E4C7B45A8 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_cellCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 V_1;
	memset((&V_1), 0, sizeof(V_1));
	NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 V_2;
	memset((&V_2), 0, sizeof(V_2));
	int32_t V_3 = 0;
	{
		V_0 = 0;
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 L_0;
		L_0 = Tessellator_Constrain_m8215808ACAA44BFA3312A4F1F46ADE90D040DE2F(__this, (&V_0), NULL);
		V_1 = L_0;
		int32_t L_1 = V_0;
		int32_t L_2 = __this->___m_Allocator;
		NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F((&V_2), L_1, L_2, 1, NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F_RuntimeMethod_var);
		___0_cellCount = 0;
		V_3 = 0;
		goto IL_0049;
	}

IL_0021:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_3 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Flags);
		int32_t L_4 = V_3;
		int32_t L_5;
		L_5 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_3)->___m_Buffer, L_4);
		if ((!(((uint32_t)L_5) == ((uint32_t)1))))
		{
			goto IL_0045;
		}
	}
	{
		int32_t L_6 = ___0_cellCount;
		int32_t L_7 = L_6;
		___0_cellCount = ((int32_t)il2cpp_codegen_add(L_7, 1));
		int32_t L_8 = V_3;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_9;
		L_9 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_1))->___m_Buffer, L_8);
		IL2CPP_NATIVEARRAY_SET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_2))->___m_Buffer, L_7, (L_9));
	}

IL_0045:
	{
		int32_t L_10 = V_3;
		V_3 = ((int32_t)il2cpp_codegen_add(L_10, 1));
	}

IL_0049:
	{
		int32_t L_11 = V_3;
		int32_t L_12 = V_0;
		if ((((int32_t)L_11) < ((int32_t)L_12)))
		{
			goto IL_0021;
		}
	}
	{
		NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213((&V_1), NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213_RuntimeMethod_var);
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 L_13 = V_2;
		return L_13;
	}
}
IL2CPP_EXTERN_C  NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 Tessellator_RemoveInterior_m9D9D80F21881D933B53DF8CC4FEA4B6E4C7B45A8_AdjustorThunk (RuntimeObject* __this, int32_t ___0_cellCount, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 _returnValue;
	_returnValue = Tessellator_RemoveInterior_m9D9D80F21881D933B53DF8CC4FEA4B6E4C7B45A8(_thisAdjusted, ___0_cellCount, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_Triangulate_m285C63134AA7BD188AA87A6E3734923DDD4C8FF5 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_points, int32_t ___1_pointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___2_edges, int32_t ___3_edgeCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_InsertionSort_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F_m1706B12E442DF1715DFA736CA4077E4896F0F251_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_mD7FAFF405DB2912073D4F221E3403DEF24972B52_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m44CBE8EDE8CD7B71350BF815EE8BB232511E7D79_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m9D682D26EB442C42FBAB528F6F5F90AE5C216E8C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_m56963AF6292CEE1271AFDE037CEFD1B70C5050D4_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mEB7F36BB585F82EDD8F8C88166579082DFA402BF_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	NativeArray_1_t97EAB41C5774F97823C769B51FBCAC8DE508B75D V_2;
	memset((&V_2), 0, sizeof(V_2));
	int32_t V_3 = 0;
	bool V_4 = false;
	float V_5 = 0.0f;
	UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 V_6;
	memset((&V_6), 0, sizeof(V_6));
	int32_t V_7 = 0;
	UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 V_8;
	memset((&V_8), 0, sizeof(V_8));
	int32_t V_9 = 0;
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_10;
	memset((&V_10), 0, sizeof(V_10));
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_11;
	memset((&V_11), 0, sizeof(V_11));
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_12;
	memset((&V_12), 0, sizeof(V_12));
	UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 V_13;
	memset((&V_13), 0, sizeof(V_13));
	UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 V_14;
	memset((&V_14), 0, sizeof(V_14));
	UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 V_15;
	memset((&V_15), 0, sizeof(V_15));
	UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 V_16;
	memset((&V_16), 0, sizeof(V_16));
	TessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F V_17;
	memset((&V_17), 0, sizeof(V_17));
	int32_t V_18 = 0;
	int32_t V_19 = 0;
	int32_t V_20 = 0;
	{
		int32_t L_0 = ___3_edgeCount;
		__this->___m_NumEdges = L_0;
		int32_t L_1 = ___3_edgeCount;
		__this->___m_NumHulls = ((int32_t)il2cpp_codegen_multiply(L_1, 2));
		int32_t L_2 = ___1_pointCount;
		__this->___m_NumPoints = L_2;
		__this->___m_CellCount = 0;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_3 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxTriangleCount;
		int32_t L_4 = __this->___m_Allocator;
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 L_5;
		memset((&L_5), 0, sizeof(L_5));
		NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F((&L_5), L_3, L_4, 1, NativeArray_1__ctor_mEFB2363DF23CE325BB07F64D5297DE7530D4A83F_RuntimeMethod_var);
		__this->___m_Cells = L_5;
		int32_t L_6 = __this->___m_NumHulls;
		int32_t L_7 = __this->___m_NumHulls;
		int32_t L_8 = __this->___m_Allocator;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_9;
		memset((&L_9), 0, sizeof(L_9));
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&L_9), ((int32_t)il2cpp_codegen_multiply(L_6, ((int32_t)il2cpp_codegen_add(L_7, 1)))), L_8, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		__this->___m_ILArray = L_9;
		int32_t L_10 = __this->___m_NumHulls;
		int32_t L_11 = __this->___m_NumHulls;
		int32_t L_12 = __this->___m_Allocator;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_13;
		memset((&L_13), 0, sizeof(L_13));
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&L_13), ((int32_t)il2cpp_codegen_multiply(L_10, ((int32_t)il2cpp_codegen_add(L_11, 1)))), L_12, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		__this->___m_IUArray = L_13;
		int32_t L_14 = __this->___m_NumPoints;
		int32_t L_15 = __this->___m_Allocator;
		NativeArray_1__ctor_mEB7F36BB585F82EDD8F8C88166579082DFA402BF((&V_0), ((int32_t)il2cpp_codegen_multiply(L_14, 8)), L_15, 1, NativeArray_1__ctor_mEB7F36BB585F82EDD8F8C88166579082DFA402BF_RuntimeMethod_var);
		V_1 = 0;
		int32_t L_16 = __this->___m_NumPoints;
		int32_t L_17 = __this->___m_NumEdges;
		int32_t L_18 = __this->___m_Allocator;
		NativeArray_1__ctor_m56963AF6292CEE1271AFDE037CEFD1B70C5050D4((&V_2), ((int32_t)il2cpp_codegen_add(L_16, ((int32_t)il2cpp_codegen_multiply(L_17, 2)))), L_18, 1, NativeArray_1__ctor_m56963AF6292CEE1271AFDE037CEFD1B70C5050D4_RuntimeMethod_var);
		V_3 = 0;
		V_7 = 0;
		goto IL_00ff;
	}

IL_00b5:
	{
		il2cpp_codegen_initobj((&V_8), sizeof(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2));
		int32_t L_19 = V_7;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_20;
		L_20 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_19);
		(&V_8)->___a = L_20;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_21 = (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*)(&(&V_8)->___b);
		il2cpp_codegen_initobj(L_21, sizeof(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA));
		int32_t L_22 = V_7;
		(&V_8)->___idx = L_22;
		(&V_8)->___type = 0;
		int32_t L_23 = V_3;
		int32_t L_24 = L_23;
		V_3 = ((int32_t)il2cpp_codegen_add(L_24, 1));
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_25 = V_8;
		IL2CPP_NATIVEARRAY_SET_ITEM(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, ((&V_2))->___m_Buffer, L_24, (L_25));
		int32_t L_26 = V_7;
		V_7 = ((int32_t)il2cpp_codegen_add(L_26, 1));
	}

IL_00ff:
	{
		int32_t L_27 = V_7;
		int32_t L_28 = __this->___m_NumPoints;
		if ((((int32_t)L_27) < ((int32_t)L_28)))
		{
			goto IL_00b5;
		}
	}
	{
		V_9 = 0;
		goto IL_024b;
	}

IL_0111:
	{
		int32_t L_29 = V_9;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_30;
		L_30 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, ((&___2_edges))->___m_Buffer, L_29);
		V_10 = L_30;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_31 = V_10;
		int32_t L_32 = L_31.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_33;
		L_33 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_32);
		V_11 = L_33;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_34 = V_10;
		int32_t L_35 = L_34.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_36;
		L_36 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_35);
		V_12 = L_36;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_37 = V_11;
		float L_38 = L_37.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_39 = V_12;
		float L_40 = L_39.___x;
		if ((!(((float)L_38) < ((float)L_40))))
		{
			goto IL_01c3;
		}
	}
	{
		il2cpp_codegen_initobj((&V_13), sizeof(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2));
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_41 = V_11;
		(&V_13)->___a = L_41;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_42 = V_12;
		(&V_13)->___b = L_42;
		int32_t L_43 = V_9;
		(&V_13)->___idx = L_43;
		(&V_13)->___type = 2;
		il2cpp_codegen_initobj((&V_14), sizeof(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2));
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_44 = V_12;
		(&V_14)->___a = L_44;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_45 = V_11;
		(&V_14)->___b = L_45;
		int32_t L_46 = V_9;
		(&V_14)->___idx = L_46;
		(&V_14)->___type = 1;
		int32_t L_47 = V_3;
		int32_t L_48 = L_47;
		V_3 = ((int32_t)il2cpp_codegen_add(L_48, 1));
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_49 = V_13;
		IL2CPP_NATIVEARRAY_SET_ITEM(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, ((&V_2))->___m_Buffer, L_48, (L_49));
		int32_t L_50 = V_3;
		int32_t L_51 = L_50;
		V_3 = ((int32_t)il2cpp_codegen_add(L_51, 1));
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_52 = V_14;
		IL2CPP_NATIVEARRAY_SET_ITEM(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, ((&V_2))->___m_Buffer, L_51, (L_52));
		goto IL_0245;
	}

IL_01c3:
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_53 = V_11;
		float L_54 = L_53.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_55 = V_12;
		float L_56 = L_55.___x;
		if ((!(((float)L_54) > ((float)L_56))))
		{
			goto IL_0245;
		}
	}
	{
		il2cpp_codegen_initobj((&V_15), sizeof(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2));
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_57 = V_12;
		(&V_15)->___a = L_57;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_58 = V_11;
		(&V_15)->___b = L_58;
		int32_t L_59 = V_9;
		(&V_15)->___idx = L_59;
		(&V_15)->___type = 2;
		il2cpp_codegen_initobj((&V_16), sizeof(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2));
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_60 = V_11;
		(&V_16)->___a = L_60;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_61 = V_12;
		(&V_16)->___b = L_61;
		int32_t L_62 = V_9;
		(&V_16)->___idx = L_62;
		(&V_16)->___type = 1;
		int32_t L_63 = V_3;
		int32_t L_64 = L_63;
		V_3 = ((int32_t)il2cpp_codegen_add(L_64, 1));
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_65 = V_15;
		IL2CPP_NATIVEARRAY_SET_ITEM(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, ((&V_2))->___m_Buffer, L_64, (L_65));
		int32_t L_66 = V_3;
		int32_t L_67 = L_66;
		V_3 = ((int32_t)il2cpp_codegen_add(L_67, 1));
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_68 = V_16;
		IL2CPP_NATIVEARRAY_SET_ITEM(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, ((&V_2))->___m_Buffer, L_67, (L_68));
	}

IL_0245:
	{
		int32_t L_69 = V_9;
		V_9 = ((int32_t)il2cpp_codegen_add(L_69, 1));
	}

IL_024b:
	{
		int32_t L_70 = V_9;
		int32_t L_71 = __this->___m_NumEdges;
		if ((((int32_t)L_70) < ((int32_t)L_71)))
		{
			goto IL_0111;
		}
	}
	{
		NativeArray_1_t97EAB41C5774F97823C769B51FBCAC8DE508B75D L_72 = V_2;
		void* L_73;
		L_73 = NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_mD7FAFF405DB2912073D4F221E3403DEF24972B52(L_72, NativeArrayUnsafeUtility_GetUnsafeBufferPointerWithoutChecks_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_mD7FAFF405DB2912073D4F221E3403DEF24972B52_RuntimeMethod_var);
		int32_t L_74 = V_3;
		il2cpp_codegen_initobj((&V_17), sizeof(TessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F));
		TessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F L_75 = V_17;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_InsertionSort_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F_m1706B12E442DF1715DFA736CA4077E4896F0F251(L_73, 0, ((int32_t)il2cpp_codegen_subtract(L_74, 1)), L_75, ModuleHandle_InsertionSort_TisUEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2_TisTessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F_m1706B12E442DF1715DFA736CA4077E4896F0F251_RuntimeMethod_var);
		V_4 = (bool)1;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_76;
		L_76 = IL2CPP_NATIVEARRAY_GET_ITEM(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, ((&V_2))->___m_Buffer, 0);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_77 = L_76.___a;
		float L_78 = L_77.___x;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_79;
		L_79 = IL2CPP_NATIVEARRAY_GET_ITEM(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, ((&V_2))->___m_Buffer, 0);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_80 = L_79.___a;
		float L_81 = L_80.___x;
		float L_82;
		L_82 = math_abs_m3D9508B36B045BFE7B89C6C69AD34596264E4FE1_inline(L_81, NULL);
		float L_83;
		L_83 = math_pow_m2B2C611A37952CFB13BB0AE800A6A601A2E4A49B_inline((2.0f), (-16.0f), NULL);
		V_5 = ((float)il2cpp_codegen_subtract(L_78, ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_add((1.0f), L_82)), L_83))));
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_84 = (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*)(&(&V_6)->___a);
		float L_85 = V_5;
		L_84->___x = L_85;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_86 = (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*)(&(&V_6)->___a);
		L_86->___y = (1.0f);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_87 = (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*)(&(&V_6)->___b);
		float L_88 = V_5;
		L_87->___x = L_88;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* L_89 = (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA*)(&(&V_6)->___b);
		L_89->___y = (0.0f);
		(&V_6)->___idx = (-1);
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_90 = __this->___m_ILArray;
		int32_t L_91 = __this->___m_NumHulls;
		int32_t L_92 = __this->___m_NumHulls;
		int32_t L_93 = __this->___m_NumHulls;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 L_94;
		memset((&L_94), 0, sizeof(L_94));
		ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402((&L_94), L_90, ((int32_t)il2cpp_codegen_multiply(L_91, L_92)), L_93, ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402_RuntimeMethod_var);
		(&V_6)->___ilarray = L_94;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_95 = __this->___m_IUArray;
		int32_t L_96 = __this->___m_NumHulls;
		int32_t L_97 = __this->___m_NumHulls;
		int32_t L_98 = __this->___m_NumHulls;
		ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03 L_99;
		memset((&L_99), 0, sizeof(L_99));
		ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402((&L_99), L_95, ((int32_t)il2cpp_codegen_multiply(L_96, L_97)), L_98, ArraySlice_1__ctor_m3ED8C6166DA2D4BF2ED02AD6C61E08CD80F61402_RuntimeMethod_var);
		(&V_6)->___iuarray = L_99;
		(&V_6)->___ilcount = 0;
		(&V_6)->___iucount = 0;
		int32_t L_100 = V_1;
		int32_t L_101 = L_100;
		V_1 = ((int32_t)il2cpp_codegen_add(L_101, 1));
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_102 = V_6;
		IL2CPP_NATIVEARRAY_SET_ITEM(UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53, ((&V_0))->___m_Buffer, L_101, (L_102));
		V_18 = 0;
		int32_t L_103 = V_3;
		V_19 = L_103;
		goto IL_03e6;
	}

IL_036c:
	{
		int32_t L_104 = V_18;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_105;
		L_105 = IL2CPP_NATIVEARRAY_GET_ITEM(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, ((&V_2))->___m_Buffer, L_104);
		int32_t L_106 = L_105.___type;
		V_20 = L_106;
		int32_t L_107 = V_20;
		if (!L_107)
		{
			goto IL_0387;
		}
	}
	{
		int32_t L_108 = V_20;
		if ((((int32_t)L_108) == ((int32_t)2)))
		{
			goto IL_03b0;
		}
	}
	{
		goto IL_03c7;
	}

IL_0387:
	{
		NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 L_109 = V_0;
		int32_t L_110 = V_1;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_111 = ___0_points;
		int32_t L_112 = V_18;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_113;
		L_113 = IL2CPP_NATIVEARRAY_GET_ITEM(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, ((&V_2))->___m_Buffer, L_112);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_114 = L_113.___a;
		int32_t L_115 = V_18;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_116;
		L_116 = IL2CPP_NATIVEARRAY_GET_ITEM(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, ((&V_2))->___m_Buffer, L_115);
		int32_t L_117 = L_116.___idx;
		bool L_118;
		L_118 = Tessellator_AddPoint_m182743F67F59E43CBD839CFDC1D0ADFE3F3B8299(__this, L_109, L_110, L_111, L_114, L_117, NULL);
		V_4 = L_118;
		goto IL_03dc;
	}

IL_03b0:
	{
		NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 L_119 = V_0;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_120 = ___0_points;
		int32_t L_121 = V_18;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_122;
		L_122 = IL2CPP_NATIVEARRAY_GET_ITEM(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, ((&V_2))->___m_Buffer, L_121);
		bool L_123;
		L_123 = Tessellator_SplitHulls_m0E1DD4AC9AA526B11A5FF0729A50A17299A16A81(__this, L_119, (&V_1), L_120, L_122, NULL);
		V_4 = L_123;
		goto IL_03dc;
	}

IL_03c7:
	{
		NativeArray_1_t6ABBADA721FBEBC4D07ACCDF57099DDE6CBC9F89 L_124 = V_0;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_125 = ___0_points;
		int32_t L_126 = V_18;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_127;
		L_127 = IL2CPP_NATIVEARRAY_GET_ITEM(UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2, ((&V_2))->___m_Buffer, L_126);
		bool L_128;
		L_128 = Tessellator_MergeHulls_m9C43D5FB7E8BFA626169A2548C85E3FCF903751C(__this, L_124, (&V_1), L_125, L_127, NULL);
		V_4 = L_128;
	}

IL_03dc:
	{
		bool L_129 = V_4;
		if (!L_129)
		{
			goto IL_03ec;
		}
	}
	{
		int32_t L_130 = V_18;
		V_18 = ((int32_t)il2cpp_codegen_add(L_130, 1));
	}

IL_03e6:
	{
		int32_t L_131 = V_18;
		int32_t L_132 = V_19;
		if ((((int32_t)L_131) < ((int32_t)L_132)))
		{
			goto IL_036c;
		}
	}

IL_03ec:
	{
		NativeArray_1_Dispose_m44CBE8EDE8CD7B71350BF815EE8BB232511E7D79((&V_2), NativeArray_1_Dispose_m44CBE8EDE8CD7B71350BF815EE8BB232511E7D79_RuntimeMethod_var);
		NativeArray_1_Dispose_m9D682D26EB442C42FBAB528F6F5F90AE5C216E8C((&V_0), NativeArray_1_Dispose_m9D682D26EB442C42FBAB528F6F5F90AE5C216E8C_RuntimeMethod_var);
		bool L_133 = V_4;
		return L_133;
	}
}
IL2CPP_EXTERN_C  bool Tessellator_Triangulate_m285C63134AA7BD188AA87A6E3734923DDD4C8FF5_AdjustorThunk (RuntimeObject* __this, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_points, int32_t ___1_pointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___2_edges, int32_t ___3_edgeCount, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	bool _returnValue;
	_returnValue = Tessellator_Triangulate_m285C63134AA7BD188AA87A6E3734923DDD4C8FF5(_thisAdjusted, ___0_points, ___1_pointCount, ___2_edges, ___3_edgeCount, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool Tessellator_Tessellate_m84DB7B38E7EC9AB5155F7EEDBC3382CF1092EC5E (int32_t ___0_allocator, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___1_pgPoints, int32_t ___2_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___3_pgEdges, int32_t ___4_pgEdgeCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___5_outputVertices, int32_t* ___6_vertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___7_outputIndices, int32_t* ___8_indexCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239 V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	bool V_3 = false;
	NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 V_4;
	memset((&V_4), 0, sizeof(V_4));
	int32_t V_5 = 0;
	uint16_t V_6 = 0;
	uint16_t V_7 = 0;
	uint16_t V_8 = 0;
	int32_t V_9 = 0;
	int32_t V_10 = 0;
	int32_t G_B3_0 = 0;
	int32_t G_B14_0 = 0;
	{
		il2cpp_codegen_initobj((&V_0), sizeof(Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239));
		int32_t L_0 = ___0_allocator;
		Tessellator_SetAllocator_mC4F00FD3CD85AA582F89050F805A50236365B47A_inline((&V_0), L_0, NULL);
		V_1 = 0;
		V_2 = 0;
		V_3 = (bool)1;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_1 = ___1_pgPoints;
		int32_t L_2 = ___2_pgPointCount;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_3 = ___3_pgEdges;
		int32_t L_4 = ___4_pgEdgeCount;
		bool L_5;
		L_5 = Tessellator_Triangulate_m285C63134AA7BD188AA87A6E3734923DDD4C8FF5((&V_0), L_1, L_2, L_3, L_4, NULL);
		V_3 = L_5;
		bool L_6 = V_3;
		if (!L_6)
		{
			goto IL_0031;
		}
	}
	{
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_7 = ___1_pgPoints;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_8 = ___3_pgEdges;
		bool L_9;
		L_9 = Tessellator_ApplyDelaunay_m97F59A65E5BAA3573864BC238165FDB8D14A0AD0((&V_0), L_7, L_8, NULL);
		G_B3_0 = ((int32_t)(L_9));
		goto IL_0032;
	}

IL_0031:
	{
		G_B3_0 = 0;
	}

IL_0032:
	{
		V_3 = (bool)G_B3_0;
		bool L_10 = V_3;
		if (!L_10)
		{
			goto IL_015e;
		}
	}
	{
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57 L_11;
		L_11 = Tessellator_RemoveExterior_m9D5D1813823280A5BDBAF36CFBE713280079011F((&V_0), (&V_2), NULL);
		V_4 = L_11;
		V_5 = 0;
		goto IL_0117;
	}

IL_004c:
	{
		int32_t L_12 = V_5;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_13;
		L_13 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_4))->___m_Buffer, L_12);
		int32_t L_14 = L_13.___x;
		V_6 = (uint16_t)((int32_t)(uint16_t)L_14);
		int32_t L_15 = V_5;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_16;
		L_16 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_4))->___m_Buffer, L_15);
		int32_t L_17 = L_16.___y;
		V_7 = (uint16_t)((int32_t)(uint16_t)L_17);
		int32_t L_18 = V_5;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_19;
		L_19 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_4))->___m_Buffer, L_18);
		int32_t L_20 = L_19.___z;
		V_8 = (uint16_t)((int32_t)(uint16_t)L_20);
		uint16_t L_21 = V_6;
		uint16_t L_22 = V_7;
		if ((((int32_t)L_21) == ((int32_t)L_22)))
		{
			goto IL_00d6;
		}
	}
	{
		uint16_t L_23 = V_7;
		uint16_t L_24 = V_8;
		if ((((int32_t)L_23) == ((int32_t)L_24)))
		{
			goto IL_00d6;
		}
	}
	{
		uint16_t L_25 = V_6;
		uint16_t L_26 = V_8;
		if ((((int32_t)L_25) == ((int32_t)L_26)))
		{
			goto IL_00d6;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_27 = ___7_outputIndices;
		int32_t* L_28 = ___8_indexCount;
		int32_t* L_29 = ___8_indexCount;
		int32_t L_30 = *((int32_t*)L_29);
		V_9 = L_30;
		int32_t L_31 = V_9;
		*((int32_t*)L_28) = (int32_t)((int32_t)il2cpp_codegen_add(L_31, 1));
		int32_t L_32 = V_9;
		uint16_t L_33 = V_6;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_27)->___m_Buffer, L_32, (L_33));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_34 = ___7_outputIndices;
		int32_t* L_35 = ___8_indexCount;
		int32_t* L_36 = ___8_indexCount;
		int32_t L_37 = *((int32_t*)L_36);
		V_9 = L_37;
		int32_t L_38 = V_9;
		*((int32_t*)L_35) = (int32_t)((int32_t)il2cpp_codegen_add(L_38, 1));
		int32_t L_39 = V_9;
		uint16_t L_40 = V_8;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_34)->___m_Buffer, L_39, (L_40));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_41 = ___7_outputIndices;
		int32_t* L_42 = ___8_indexCount;
		int32_t* L_43 = ___8_indexCount;
		int32_t L_44 = *((int32_t*)L_43);
		V_9 = L_44;
		int32_t L_45 = V_9;
		*((int32_t*)L_42) = (int32_t)((int32_t)il2cpp_codegen_add(L_45, 1));
		int32_t L_46 = V_9;
		uint16_t L_47 = V_7;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_41)->___m_Buffer, L_46, (L_47));
	}

IL_00d6:
	{
		int32_t L_48 = V_5;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_49;
		L_49 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_4))->___m_Buffer, L_48);
		int32_t L_50 = L_49.___x;
		int32_t L_51 = V_5;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_52;
		L_52 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_4))->___m_Buffer, L_51);
		int32_t L_53 = L_52.___y;
		int32_t L_54;
		L_54 = math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline(L_50, L_53, NULL);
		int32_t L_55 = V_5;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_56;
		L_56 = IL2CPP_NATIVEARRAY_GET_ITEM(int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF, ((&V_4))->___m_Buffer, L_55);
		int32_t L_57 = L_56.___z;
		int32_t L_58;
		L_58 = math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline(L_54, L_57, NULL);
		int32_t L_59 = V_1;
		int32_t L_60;
		L_60 = math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline(L_58, L_59, NULL);
		V_1 = L_60;
		int32_t L_61 = V_5;
		V_5 = ((int32_t)il2cpp_codegen_add(L_61, 1));
	}

IL_0117:
	{
		int32_t L_62 = V_5;
		int32_t L_63 = V_2;
		if ((((int32_t)L_62) < ((int32_t)L_63)))
		{
			goto IL_004c;
		}
	}
	{
		int32_t L_64 = V_1;
		if (L_64)
		{
			goto IL_0125;
		}
	}
	{
		G_B14_0 = 0;
		goto IL_0128;
	}

IL_0125:
	{
		int32_t L_65 = V_1;
		G_B14_0 = ((int32_t)il2cpp_codegen_add(L_65, 1));
	}

IL_0128:
	{
		V_1 = G_B14_0;
		V_10 = 0;
		goto IL_0152;
	}

IL_012e:
	{
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_66 = ___5_outputVertices;
		int32_t* L_67 = ___6_vertexCount;
		int32_t* L_68 = ___6_vertexCount;
		int32_t L_69 = *((int32_t*)L_68);
		V_9 = L_69;
		int32_t L_70 = V_9;
		*((int32_t*)L_67) = (int32_t)((int32_t)il2cpp_codegen_add(L_70, 1));
		int32_t L_71 = V_9;
		int32_t L_72 = V_10;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_73;
		L_73 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___1_pgPoints))->___m_Buffer, L_72);
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_66)->___m_Buffer, L_71, (L_73));
		int32_t L_74 = V_10;
		V_10 = ((int32_t)il2cpp_codegen_add(L_74, 1));
	}

IL_0152:
	{
		int32_t L_75 = V_10;
		int32_t L_76 = V_1;
		if ((((int32_t)L_75) < ((int32_t)L_76)))
		{
			goto IL_012e;
		}
	}
	{
		NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213((&V_4), NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213_RuntimeMethod_var);
	}

IL_015e:
	{
		Tessellator_Cleanup_m3B1B149B79AC4098E89B70A7AC57CA8D41309293((&V_0), NULL);
		bool L_77 = V_3;
		return L_77;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void Tessellator_Cleanup_m3B1B149B79AC4098E89B70A7AC57CA8D41309293 (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m1ACF94B84372AD81EEE7228152F8E1770B09180B_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_get_IsCreated_m448EBF5E1AF8055E179079DE8883B7F449125BAB_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_get_IsCreated_m5BE85069615B49772C9DB202004FA2FD36F418F2_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_get_IsCreated_mB43459BFDEF78038051D817E8A57FF1DF3C3D738_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_0 = (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)(&__this->___m_Edges);
		bool L_1;
		L_1 = NativeArray_1_get_IsCreated_m5BE85069615B49772C9DB202004FA2FD36F418F2_inline(L_0, NativeArray_1_get_IsCreated_m5BE85069615B49772C9DB202004FA2FD36F418F2_RuntimeMethod_var);
		if (!L_1)
		{
			goto IL_0018;
		}
	}
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_2 = (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)(&__this->___m_Edges);
		NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2(L_2, NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
	}

IL_0018:
	{
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_3 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		bool L_4;
		L_4 = NativeArray_1_get_IsCreated_mB43459BFDEF78038051D817E8A57FF1DF3C3D738_inline(L_3, NativeArray_1_get_IsCreated_mB43459BFDEF78038051D817E8A57FF1DF3C3D738_RuntimeMethod_var);
		if (!L_4)
		{
			goto IL_0030;
		}
	}
	{
		NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* L_5 = (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099*)(&__this->___m_Stars);
		NativeArray_1_Dispose_m1ACF94B84372AD81EEE7228152F8E1770B09180B(L_5, NativeArray_1_Dispose_m1ACF94B84372AD81EEE7228152F8E1770B09180B_RuntimeMethod_var);
	}

IL_0030:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_6 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_SPArray);
		bool L_7;
		L_7 = NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_inline(L_6, NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_RuntimeMethod_var);
		if (!L_7)
		{
			goto IL_0048;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_8 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_SPArray);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E(L_8, NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
	}

IL_0048:
	{
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* L_9 = (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57*)(&__this->___m_Cells);
		bool L_10;
		L_10 = NativeArray_1_get_IsCreated_m448EBF5E1AF8055E179079DE8883B7F449125BAB_inline(L_9, NativeArray_1_get_IsCreated_m448EBF5E1AF8055E179079DE8883B7F449125BAB_RuntimeMethod_var);
		if (!L_10)
		{
			goto IL_0060;
		}
	}
	{
		NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* L_11 = (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57*)(&__this->___m_Cells);
		NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213(L_11, NativeArray_1_Dispose_m0015D099CB0B1F5A98810933273CC400B0BD4213_RuntimeMethod_var);
	}

IL_0060:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_12 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_ILArray);
		bool L_13;
		L_13 = NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_inline(L_12, NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_RuntimeMethod_var);
		if (!L_13)
		{
			goto IL_0078;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_14 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_ILArray);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E(L_14, NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
	}

IL_0078:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_15 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_IUArray);
		bool L_16;
		L_16 = NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_inline(L_15, NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_RuntimeMethod_var);
		if (!L_16)
		{
			goto IL_0090;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_17 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_IUArray);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E(L_17, NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
	}

IL_0090:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_18 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Flags);
		bool L_19;
		L_19 = NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_inline(L_18, NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_RuntimeMethod_var);
		if (!L_19)
		{
			goto IL_00a8;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_20 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Flags);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E(L_20, NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
	}

IL_00a8:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_21 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Neighbors);
		bool L_22;
		L_22 = NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_inline(L_21, NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_RuntimeMethod_var);
		if (!L_22)
		{
			goto IL_00c0;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_23 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Neighbors);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E(L_23, NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
	}

IL_00c0:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_24 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Constraints);
		bool L_25;
		L_25 = NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_inline(L_24, NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_RuntimeMethod_var);
		if (!L_25)
		{
			goto IL_00d8;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_26 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___m_Constraints);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E(L_26, NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
	}

IL_00d8:
	{
		return;
	}
}
IL2CPP_EXTERN_C  void Tessellator_Cleanup_m3B1B149B79AC4098E89B70A7AC57CA8D41309293_AdjustorThunk (RuntimeObject* __this, const RuntimeMethod* method)
{
	Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239*>(__this + _offset);
	Tessellator_Cleanup_m3B1B149B79AC4098E89B70A7AC57CA8D41309293(_thisAdjusted, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TestHullPointL_Test_m13DD2824D7E78DA3A4EF948C678CD51A88F5A716 (TestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3* __this, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_h, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_p, float* ___2_t, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		float* L_0 = ___2_t;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_1 = ___0_h;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = L_1.___a;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_3 = ___0_h;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = L_3.___b;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_5 = ___1_p;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		float L_6;
		L_6 = ModuleHandle_OrientFast_m39D34C2844061E3607200824ADE00A8CA5680634(L_2, L_4, L_5, NULL);
		*((float*)L_0) = (float)L_6;
		float* L_7 = ___2_t;
		float L_8 = *((float*)L_7);
		return (bool)((((float)L_8) < ((float)(0.0f)))? 1 : 0);
	}
}
IL2CPP_EXTERN_C  bool TestHullPointL_Test_m13DD2824D7E78DA3A4EF948C678CD51A88F5A716_AdjustorThunk (RuntimeObject* __this, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_h, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_p, float* ___2_t, const RuntimeMethod* method)
{
	TestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<TestHullPointL_t66C05D60E7E5706E74F989DAA68FA199428F92D3*>(__this + _offset);
	bool _returnValue;
	_returnValue = TestHullPointL_Test_m13DD2824D7E78DA3A4EF948C678CD51A88F5A716(_thisAdjusted, ___0_h, ___1_p, ___2_t, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TestHullPointU_Test_m2BBE9B65EB95E4ABA928A86A055086CED902517B (TestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436* __this, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_h, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_p, float* ___2_t, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		float* L_0 = ___2_t;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_1 = ___0_h;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = L_1.___a;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_3 = ___0_h;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = L_3.___b;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_5 = ___1_p;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		float L_6;
		L_6 = ModuleHandle_OrientFast_m39D34C2844061E3607200824ADE00A8CA5680634(L_2, L_4, L_5, NULL);
		*((float*)L_0) = (float)L_6;
		float* L_7 = ___2_t;
		float L_8 = *((float*)L_7);
		return (bool)((((float)L_8) > ((float)(0.0f)))? 1 : 0);
	}
}
IL2CPP_EXTERN_C  bool TestHullPointU_Test_m2BBE9B65EB95E4ABA928A86A055086CED902517B_AdjustorThunk (RuntimeObject* __this, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_h, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_p, float* ___2_t, const RuntimeMethod* method)
{
	TestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<TestHullPointU_t809413979EC88BF272FDF3283CD621EC515DC436*>(__this + _offset);
	bool _returnValue;
	_returnValue = TestHullPointU_Test_m2BBE9B65EB95E4ABA928A86A055086CED902517B(_thisAdjusted, ___0_h, ___1_p, ___2_t, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TestHullEventLe_Test_m93D489EB67F59C91419FF51EE01931CB1BB0A529 (TestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D* __this, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_h, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___1_p, float* ___2_t, const RuntimeMethod* method) 
{
	{
		float* L_0 = ___2_t;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_1 = ___0_h;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_2 = ___1_p;
		float L_3;
		L_3 = Tessellator_FindSplit_mFEA20FADFD2F4401DA02191FE3C6F4462F37B9B5(L_1, L_2, NULL);
		*((float*)L_0) = (float)L_3;
		float* L_4 = ___2_t;
		float L_5 = *((float*)L_4);
		return (bool)((((int32_t)((!(((float)L_5) <= ((float)(0.0f))))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
IL2CPP_EXTERN_C  bool TestHullEventLe_Test_m93D489EB67F59C91419FF51EE01931CB1BB0A529_AdjustorThunk (RuntimeObject* __this, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_h, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___1_p, float* ___2_t, const RuntimeMethod* method)
{
	TestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<TestHullEventLe_t66CB3555FA32DA29B628633855B1A0F2CEB6242D*>(__this + _offset);
	bool _returnValue;
	_returnValue = TestHullEventLe_Test_m93D489EB67F59C91419FF51EE01931CB1BB0A529(_thisAdjusted, ___0_h, ___1_p, ___2_t, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TestHullEventE_Test_mB58E3071967F89B4EA751EEBD5FE56EAD6B40F85 (TestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155* __this, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_h, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___1_p, float* ___2_t, const RuntimeMethod* method) 
{
	{
		float* L_0 = ___2_t;
		UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 L_1 = ___0_h;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_2 = ___1_p;
		float L_3;
		L_3 = Tessellator_FindSplit_mFEA20FADFD2F4401DA02191FE3C6F4462F37B9B5(L_1, L_2, NULL);
		*((float*)L_0) = (float)L_3;
		float* L_4 = ___2_t;
		float L_5 = *((float*)L_4);
		return (bool)((((float)L_5) == ((float)(0.0f)))? 1 : 0);
	}
}
IL2CPP_EXTERN_C  bool TestHullEventE_Test_mB58E3071967F89B4EA751EEBD5FE56EAD6B40F85_AdjustorThunk (RuntimeObject* __this, UHull_t042A8827A0CEE132C9302730F1CC1C2206B18B53 ___0_h, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___1_p, float* ___2_t, const RuntimeMethod* method)
{
	TestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<TestHullEventE_tFEF79D93DB3C2ADE0B128AA19F5B833553EA6155*>(__this + _offset);
	bool _returnValue;
	_returnValue = TestHullEventE_Test_mB58E3071967F89B4EA751EEBD5FE56EAD6B40F85(_thisAdjusted, ___0_h, ___1_p, ___2_t, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TestEdgePointE_Test_mE27BE906A78058D6E43C2EBC14C95B164554AC5E (TestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375* __this, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___0_h, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_p, float* ___2_t, const RuntimeMethod* method) 
{
	TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		il2cpp_codegen_initobj((&V_0), sizeof(TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434));
		float* L_0 = ___2_t;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_1 = ___0_h;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_2 = ___1_p;
		int32_t L_3;
		L_3 = TessEdgeCompare_Compare_m29540C70B61ECC31030C7D3F52E8F3B534BEC37D((&V_0), L_1, L_2, NULL);
		*((float*)L_0) = (float)((float)L_3);
		float* L_4 = ___2_t;
		float L_5 = *((float*)L_4);
		return (bool)((((float)L_5) == ((float)(0.0f)))? 1 : 0);
	}
}
IL2CPP_EXTERN_C  bool TestEdgePointE_Test_mE27BE906A78058D6E43C2EBC14C95B164554AC5E_AdjustorThunk (RuntimeObject* __this, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___0_h, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_p, float* ___2_t, const RuntimeMethod* method)
{
	TestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<TestEdgePointE_t07682085F4A93FFB8D7AE6B7E23C1906A6906375*>(__this + _offset);
	bool _returnValue;
	_returnValue = TestEdgePointE_Test_mE27BE906A78058D6E43C2EBC14C95B164554AC5E(_thisAdjusted, ___0_h, ___1_p, ___2_t, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool TestCellE_Test_mF4632944A15C6F5DEEB3A19A5DC35FF16FB31C2D (TestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1* __this, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___0_h, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___1_p, float* ___2_t, const RuntimeMethod* method) 
{
	TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		il2cpp_codegen_initobj((&V_0), sizeof(TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE));
		float* L_0 = ___2_t;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_1 = ___0_h;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_2 = ___1_p;
		int32_t L_3;
		L_3 = TessCellCompare_Compare_m1CA8ED338230EF907349884C7B60CCE3559BA57A((&V_0), L_1, L_2, NULL);
		*((float*)L_0) = (float)((float)L_3);
		float* L_4 = ___2_t;
		float L_5 = *((float*)L_4);
		return (bool)((((float)L_5) == ((float)(0.0f)))? 1 : 0);
	}
}
IL2CPP_EXTERN_C  bool TestCellE_Test_mF4632944A15C6F5DEEB3A19A5DC35FF16FB31C2D_AdjustorThunk (RuntimeObject* __this, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___0_h, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___1_p, float* ___2_t, const RuntimeMethod* method)
{
	TestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<TestCellE_t5EB77B2936FBA2E942781804AF27F57B100133B1*>(__this + _offset);
	bool _returnValue;
	_returnValue = TestCellE_Test_mF4632944A15C6F5DEEB3A19A5DC35FF16FB31C2D(_thisAdjusted, ___0_h, ___1_p, ___2_t, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t XCompare_Compare_m07A9D6C40F60E0E5AEBAEC1E27A8C95F2E7017A3 (XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B* __this, double ___0_a, double ___1_b, const RuntimeMethod* method) 
{
	{
		double L_0 = ___0_a;
		double L_1 = ___1_b;
		if ((((double)L_0) < ((double)L_1)))
		{
			goto IL_0006;
		}
	}
	{
		return 1;
	}

IL_0006:
	{
		return (-1);
	}
}
IL2CPP_EXTERN_C  int32_t XCompare_Compare_m07A9D6C40F60E0E5AEBAEC1E27A8C95F2E7017A3_AdjustorThunk (RuntimeObject* __this, double ___0_a, double ___1_b, const RuntimeMethod* method)
{
	XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B*>(__this + _offset);
	int32_t _returnValue;
	_returnValue = XCompare_Compare_m07A9D6C40F60E0E5AEBAEC1E27A8C95F2E7017A3(_thisAdjusted, ___0_a, ___1_b, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t IntersectionCompare_Compare_mCE1F00DE6559846CB71839148F1BAF54DB6260EF (IntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489* __this, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___0_a, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_b, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_InsertionSort_TisDouble_tE150EF3D1D43DEE85D533810AB4C742307EEDE5F_TisXCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B_mD9DFBCA0EC70F5BF558FBC5C79E929BB2316EFB7_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_0;
	memset((&V_0), 0, sizeof(V_0));
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_1;
	memset((&V_1), 0, sizeof(V_1));
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_2;
	memset((&V_2), 0, sizeof(V_2));
	int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A V_3;
	memset((&V_3), 0, sizeof(V_3));
	double* V_4 = NULL;
	XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B V_5;
	memset((&V_5), 0, sizeof(V_5));
	int32_t V_6 = 0;
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_0 = (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)(&__this->___edges);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_1 = ___0_a;
		int32_t L_2 = L_1.___x;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_3;
		L_3 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_0)->___m_Buffer, L_2);
		V_0 = L_3;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_4 = (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)(&__this->___edges);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_5 = ___0_a;
		int32_t L_6 = L_5.___y;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_7;
		L_7 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_4)->___m_Buffer, L_6);
		V_1 = L_7;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_8 = (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)(&__this->___edges);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_9 = ___1_b;
		int32_t L_10 = L_9.___x;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_11;
		L_11 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_8)->___m_Buffer, L_10);
		V_2 = L_11;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_12 = (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)(&__this->___edges);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_13 = ___1_b;
		int32_t L_14 = L_13.___y;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_15;
		L_15 = IL2CPP_NATIVEARRAY_GET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_12)->___m_Buffer, L_14);
		V_3 = L_15;
		U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0* L_16 = (U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0*)(&__this->___xvasort);
		double* L_17 = (double*)(&L_16->___FixedElementField);
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_18 = (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7*)(&__this->___points);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_19 = V_0;
		int32_t L_20 = L_19.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_21;
		L_21 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_18)->___m_Buffer, L_20);
		double L_22 = L_21.___x;
		*((double*)L_17) = (double)L_22;
		U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0* L_23 = (U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0*)(&__this->___xvasort);
		double* L_24 = (double*)(&L_23->___FixedElementField);
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_25 = (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7*)(&__this->___points);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_26 = V_0;
		int32_t L_27 = L_26.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_28;
		L_28 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_25)->___m_Buffer, L_27);
		double L_29 = L_28.___x;
		*((double*)((double*)il2cpp_codegen_add((intptr_t)L_24, 8))) = (double)L_29;
		U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0* L_30 = (U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0*)(&__this->___xvasort);
		double* L_31 = (double*)(&L_30->___FixedElementField);
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_32 = (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7*)(&__this->___points);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_33 = V_1;
		int32_t L_34 = L_33.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_35;
		L_35 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_32)->___m_Buffer, L_34);
		double L_36 = L_35.___x;
		*((double*)((double*)il2cpp_codegen_add((intptr_t)L_31, ((intptr_t)il2cpp_codegen_multiply(((intptr_t)2), 8))))) = (double)L_36;
		U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0* L_37 = (U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0*)(&__this->___xvasort);
		double* L_38 = (double*)(&L_37->___FixedElementField);
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_39 = (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7*)(&__this->___points);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_40 = V_1;
		int32_t L_41 = L_40.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_42;
		L_42 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_39)->___m_Buffer, L_41);
		double L_43 = L_42.___x;
		*((double*)((double*)il2cpp_codegen_add((intptr_t)L_38, ((intptr_t)il2cpp_codegen_multiply(((intptr_t)3), 8))))) = (double)L_43;
		U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29* L_44 = (U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29*)(&__this->___xvbsort);
		double* L_45 = (double*)(&L_44->___FixedElementField);
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_46 = (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7*)(&__this->___points);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_47 = V_2;
		int32_t L_48 = L_47.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_49;
		L_49 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_46)->___m_Buffer, L_48);
		double L_50 = L_49.___x;
		*((double*)L_45) = (double)L_50;
		U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29* L_51 = (U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29*)(&__this->___xvbsort);
		double* L_52 = (double*)(&L_51->___FixedElementField);
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_53 = (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7*)(&__this->___points);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_54 = V_2;
		int32_t L_55 = L_54.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_56;
		L_56 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_53)->___m_Buffer, L_55);
		double L_57 = L_56.___x;
		*((double*)((double*)il2cpp_codegen_add((intptr_t)L_52, 8))) = (double)L_57;
		U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29* L_58 = (U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29*)(&__this->___xvbsort);
		double* L_59 = (double*)(&L_58->___FixedElementField);
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_60 = (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7*)(&__this->___points);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_61 = V_3;
		int32_t L_62 = L_61.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_63;
		L_63 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_60)->___m_Buffer, L_62);
		double L_64 = L_63.___x;
		*((double*)((double*)il2cpp_codegen_add((intptr_t)L_59, ((intptr_t)il2cpp_codegen_multiply(((intptr_t)2), 8))))) = (double)L_64;
		U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29* L_65 = (U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29*)(&__this->___xvbsort);
		double* L_66 = (double*)(&L_65->___FixedElementField);
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_67 = (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7*)(&__this->___points);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_68 = V_3;
		int32_t L_69 = L_68.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_70;
		L_70 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_67)->___m_Buffer, L_69);
		double L_71 = L_70.___x;
		*((double*)((double*)il2cpp_codegen_add((intptr_t)L_66, ((intptr_t)il2cpp_codegen_multiply(((intptr_t)3), 8))))) = (double)L_71;
		U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0* L_72 = (U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0*)(&__this->___xvasort);
		double* L_73 = (double*)(&L_72->___FixedElementField);
		V_4 = L_73;
		double* L_74 = V_4;
		il2cpp_codegen_initobj((&V_5), sizeof(XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B));
		XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B L_75 = V_5;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_InsertionSort_TisDouble_tE150EF3D1D43DEE85D533810AB4C742307EEDE5F_TisXCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B_mD9DFBCA0EC70F5BF558FBC5C79E929BB2316EFB7((void*)((uintptr_t)L_74), 0, 3, L_75, ModuleHandle_InsertionSort_TisDouble_tE150EF3D1D43DEE85D533810AB4C742307EEDE5F_TisXCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B_mD9DFBCA0EC70F5BF558FBC5C79E929BB2316EFB7_RuntimeMethod_var);
		V_4 = (double*)((uintptr_t)0);
		U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29* L_76 = (U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29*)(&__this->___xvbsort);
		double* L_77 = (double*)(&L_76->___FixedElementField);
		V_4 = L_77;
		double* L_78 = V_4;
		il2cpp_codegen_initobj((&V_5), sizeof(XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B));
		XCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B L_79 = V_5;
		ModuleHandle_InsertionSort_TisDouble_tE150EF3D1D43DEE85D533810AB4C742307EEDE5F_TisXCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B_mD9DFBCA0EC70F5BF558FBC5C79E929BB2316EFB7((void*)((uintptr_t)L_78), 0, 3, L_79, ModuleHandle_InsertionSort_TisDouble_tE150EF3D1D43DEE85D533810AB4C742307EEDE5F_TisXCompare_tE81FF959DAAE2A358A64BEC48EA7BC85ABF3BD1B_mD9DFBCA0EC70F5BF558FBC5C79E929BB2316EFB7_RuntimeMethod_var);
		V_4 = (double*)((uintptr_t)0);
		V_6 = 0;
		goto IL_021f;
	}

IL_01bf:
	{
		U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0* L_80 = (U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0*)(&__this->___xvasort);
		double* L_81 = (double*)(&L_80->___FixedElementField);
		int32_t L_82 = V_6;
		double L_83 = *((double*)((double*)il2cpp_codegen_add((intptr_t)L_81, ((intptr_t)il2cpp_codegen_multiply(((intptr_t)L_82), 8)))));
		U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29* L_84 = (U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29*)(&__this->___xvbsort);
		double* L_85 = (double*)(&L_84->___FixedElementField);
		int32_t L_86 = V_6;
		double L_87 = *((double*)((double*)il2cpp_codegen_add((intptr_t)L_85, ((intptr_t)il2cpp_codegen_multiply(((intptr_t)L_86), 8)))));
		if ((((double)((double)il2cpp_codegen_subtract(L_83, L_87))) == ((double)(0.0))))
		{
			goto IL_0219;
		}
	}
	{
		U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0* L_88 = (U3CxvasortU3Ee__FixedBuffer_t79DE72BBEB4757EE616BB011D62D7EAD6D3519E0*)(&__this->___xvasort);
		double* L_89 = (double*)(&L_88->___FixedElementField);
		int32_t L_90 = V_6;
		double L_91 = *((double*)((double*)il2cpp_codegen_add((intptr_t)L_89, ((intptr_t)il2cpp_codegen_multiply(((intptr_t)L_90), 8)))));
		U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29* L_92 = (U3CxvbsortU3Ee__FixedBuffer_tB79D6FDE211F7AC2E9EADF73CAF439599E5FCC29*)(&__this->___xvbsort);
		double* L_93 = (double*)(&L_92->___FixedElementField);
		int32_t L_94 = V_6;
		double L_95 = *((double*)((double*)il2cpp_codegen_add((intptr_t)L_93, ((intptr_t)il2cpp_codegen_multiply(((intptr_t)L_94), 8)))));
		if ((((double)L_91) < ((double)L_95)))
		{
			goto IL_0217;
		}
	}
	{
		return 1;
	}

IL_0217:
	{
		return (-1);
	}

IL_0219:
	{
		int32_t L_96 = V_6;
		V_6 = ((int32_t)il2cpp_codegen_add(L_96, 1));
	}

IL_021f:
	{
		int32_t L_97 = V_6;
		if ((((int32_t)L_97) < ((int32_t)4)))
		{
			goto IL_01bf;
		}
	}
	{
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_98 = (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7*)(&__this->___points);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_99 = V_0;
		int32_t L_100 = L_99.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_101;
		L_101 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_98)->___m_Buffer, L_100);
		double L_102 = L_101.___y;
		NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7* L_103 = (NativeArray_1_tC5C4512CB4AB460748938A48BEBFEE21884292B7*)(&__this->___points);
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_104 = V_0;
		int32_t L_105 = L_104.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_106;
		L_106 = IL2CPP_NATIVEARRAY_GET_ITEM(double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA, (L_103)->___m_Buffer, L_105);
		double L_107 = L_106.___y;
		if ((((double)L_102) < ((double)L_107)))
		{
			goto IL_0254;
		}
	}
	{
		return 1;
	}

IL_0254:
	{
		return (-1);
	}
}
IL2CPP_EXTERN_C  int32_t IntersectionCompare_Compare_mCE1F00DE6559846CB71839148F1BAF54DB6260EF_AdjustorThunk (RuntimeObject* __this, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___0_a, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_b, const RuntimeMethod* method)
{
	IntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<IntersectionCompare_tC72A2D1811BA0D8D07A0E45F6BA2FF83DE4F1489*>(__this + _offset);
	int32_t _returnValue;
	_returnValue = IntersectionCompare_Compare_mCE1F00DE6559846CB71839148F1BAF54DB6260EF(_thisAdjusted, ___0_a, ___1_b, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TessEventCompare_Compare_mFBC498906F6BF3279BB6843DC8C7D12B9D4522C1 (TessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F* __this, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___0_a, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___1_b, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	int32_t V_1 = 0;
	float V_2 = 0.0f;
	{
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_0 = ___0_a;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_1 = L_0.___a;
		float L_2 = L_1.___x;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_3 = ___1_b;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = L_3.___a;
		float L_5 = L_4.___x;
		V_0 = ((float)il2cpp_codegen_subtract(L_2, L_5));
		float L_6 = V_0;
		if ((((float)(0.0f)) == ((float)L_6)))
		{
			goto IL_002c;
		}
	}
	{
		float L_7 = V_0;
		if ((((float)L_7) > ((float)(0.0f))))
		{
			goto IL_002a;
		}
	}
	{
		return (-1);
	}

IL_002a:
	{
		return 1;
	}

IL_002c:
	{
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_8 = ___0_a;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_9 = L_8.___a;
		float L_10 = L_9.___y;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_11 = ___1_b;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_12 = L_11.___a;
		float L_13 = L_12.___y;
		V_0 = ((float)il2cpp_codegen_subtract(L_10, L_13));
		float L_14 = V_0;
		if ((((float)(0.0f)) == ((float)L_14)))
		{
			goto IL_0058;
		}
	}
	{
		float L_15 = V_0;
		if ((((float)L_15) > ((float)(0.0f))))
		{
			goto IL_0056;
		}
	}
	{
		return (-1);
	}

IL_0056:
	{
		return 1;
	}

IL_0058:
	{
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_16 = ___0_a;
		int32_t L_17 = L_16.___type;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_18 = ___1_b;
		int32_t L_19 = L_18.___type;
		V_1 = ((int32_t)il2cpp_codegen_subtract(L_17, L_19));
		int32_t L_20 = V_1;
		if (!L_20)
		{
			goto IL_006b;
		}
	}
	{
		int32_t L_21 = V_1;
		return L_21;
	}

IL_006b:
	{
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_22 = ___0_a;
		int32_t L_23 = L_22.___type;
		if (!L_23)
		{
			goto IL_009f;
		}
	}
	{
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_24 = ___0_a;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_25 = L_24.___a;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_26 = ___0_a;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_27 = L_26.___b;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_28 = ___1_b;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_29 = L_28.___b;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		float L_30;
		L_30 = ModuleHandle_OrientFast_m39D34C2844061E3607200824ADE00A8CA5680634(L_25, L_27, L_29, NULL);
		V_2 = L_30;
		float L_31 = V_2;
		if ((((float)(0.0f)) == ((float)L_31)))
		{
			goto IL_009f;
		}
	}
	{
		float L_32 = V_2;
		if ((((float)L_32) > ((float)(0.0f))))
		{
			goto IL_009d;
		}
	}
	{
		return (-1);
	}

IL_009d:
	{
		return 1;
	}

IL_009f:
	{
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_33 = ___0_a;
		int32_t L_34 = L_33.___idx;
		UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 L_35 = ___1_b;
		int32_t L_36 = L_35.___idx;
		return ((int32_t)il2cpp_codegen_subtract(L_34, L_36));
	}
}
IL2CPP_EXTERN_C  int32_t TessEventCompare_Compare_mFBC498906F6BF3279BB6843DC8C7D12B9D4522C1_AdjustorThunk (RuntimeObject* __this, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___0_a, UEvent_t6B46070B7BC816FDF53E67775BD4EA5508B807C2 ___1_b, const RuntimeMethod* method)
{
	TessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<TessEventCompare_t286A68412E43ED2680CC0D5FF7189FADAB1FBC4F*>(__this + _offset);
	int32_t _returnValue;
	_returnValue = TessEventCompare_Compare_mFBC498906F6BF3279BB6843DC8C7D12B9D4522C1(_thisAdjusted, ___0_a, ___1_b, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TessEdgeCompare_Compare_m29540C70B61ECC31030C7D3F52E8F3B534BEC37D (TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434* __this, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___0_a, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_b, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_0 = ___0_a;
		int32_t L_1 = L_0.___x;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_2 = ___1_b;
		int32_t L_3 = L_2.___x;
		V_0 = ((int32_t)il2cpp_codegen_subtract(L_1, L_3));
		int32_t L_4 = V_0;
		if (!L_4)
		{
			goto IL_0013;
		}
	}
	{
		int32_t L_5 = V_0;
		return L_5;
	}

IL_0013:
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_6 = ___0_a;
		int32_t L_7 = L_6.___y;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_8 = ___1_b;
		int32_t L_9 = L_8.___y;
		V_0 = ((int32_t)il2cpp_codegen_subtract(L_7, L_9));
		int32_t L_10 = V_0;
		return L_10;
	}
}
IL2CPP_EXTERN_C  int32_t TessEdgeCompare_Compare_m29540C70B61ECC31030C7D3F52E8F3B534BEC37D_AdjustorThunk (RuntimeObject* __this, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___0_a, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_b, const RuntimeMethod* method)
{
	TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<TessEdgeCompare_t41229EB788BF2503A67B087C78F734EADDE71434*>(__this + _offset);
	int32_t _returnValue;
	_returnValue = TessEdgeCompare_Compare_m29540C70B61ECC31030C7D3F52E8F3B534BEC37D(_thisAdjusted, ___0_a, ___1_b, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TessCellCompare_Compare_m1CA8ED338230EF907349884C7B60CCE3559BA57A (TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE* __this, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___0_a, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___1_b, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_0 = ___0_a;
		int32_t L_1 = L_0.___x;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_2 = ___1_b;
		int32_t L_3 = L_2.___x;
		V_0 = ((int32_t)il2cpp_codegen_subtract(L_1, L_3));
		int32_t L_4 = V_0;
		if (!L_4)
		{
			goto IL_0013;
		}
	}
	{
		int32_t L_5 = V_0;
		return L_5;
	}

IL_0013:
	{
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_6 = ___0_a;
		int32_t L_7 = L_6.___y;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_8 = ___1_b;
		int32_t L_9 = L_8.___y;
		V_0 = ((int32_t)il2cpp_codegen_subtract(L_7, L_9));
		int32_t L_10 = V_0;
		if (!L_10)
		{
			goto IL_0026;
		}
	}
	{
		int32_t L_11 = V_0;
		return L_11;
	}

IL_0026:
	{
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_12 = ___0_a;
		int32_t L_13 = L_12.___z;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_14 = ___1_b;
		int32_t L_15 = L_14.___z;
		V_0 = ((int32_t)il2cpp_codegen_subtract(L_13, L_15));
		int32_t L_16 = V_0;
		return L_16;
	}
}
IL2CPP_EXTERN_C  int32_t TessCellCompare_Compare_m1CA8ED338230EF907349884C7B60CCE3559BA57A_AdjustorThunk (RuntimeObject* __this, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___0_a, int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF ___1_b, const RuntimeMethod* method)
{
	TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<TessCellCompare_tC18A10A741079B0B69C186B257E59D25768908BE*>(__this + _offset);
	int32_t _returnValue;
	_returnValue = TessCellCompare_Compare_m1CA8ED338230EF907349884C7B60CCE3559BA57A(_thisAdjusted, ___0_a, ___1_b, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TessJunctionCompare_Compare_m212C2AE3DCBD9AB1C8FA5E503811F8E573E6285A (TessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249* __this, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___0_a, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_b, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_0 = ___0_a;
		int32_t L_1 = L_0.___x;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_2 = ___1_b;
		int32_t L_3 = L_2.___x;
		V_0 = ((int32_t)il2cpp_codegen_subtract(L_1, L_3));
		int32_t L_4 = V_0;
		if (!L_4)
		{
			goto IL_0013;
		}
	}
	{
		int32_t L_5 = V_0;
		return L_5;
	}

IL_0013:
	{
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_6 = ___0_a;
		int32_t L_7 = L_6.___y;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_8 = ___1_b;
		int32_t L_9 = L_8.___y;
		V_0 = ((int32_t)il2cpp_codegen_subtract(L_7, L_9));
		int32_t L_10 = V_0;
		return L_10;
	}
}
IL2CPP_EXTERN_C  int32_t TessJunctionCompare_Compare_m212C2AE3DCBD9AB1C8FA5E503811F8E573E6285A_AdjustorThunk (RuntimeObject* __this, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___0_a, int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A ___1_b, const RuntimeMethod* method)
{
	TessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<TessJunctionCompare_tBB128A7D2EB479A4CCFE1AB7ECD6A2F284762249*>(__this + _offset);
	int32_t _returnValue;
	_returnValue = TessJunctionCompare_Compare_m212C2AE3DCBD9AB1C8FA5E503811F8E573E6285A(_thisAdjusted, ___0_a, ___1_b, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t DelaEdgeCompare_Compare_m9D63142C6EBC894B7DAD24EBE3A38FDD5678BEF2 (DelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B* __this, int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___0_a, int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___1_b, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_0 = ___0_a;
		int32_t L_1 = L_0.___x;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_2 = ___1_b;
		int32_t L_3 = L_2.___x;
		V_0 = ((int32_t)il2cpp_codegen_subtract(L_1, L_3));
		int32_t L_4 = V_0;
		if (!L_4)
		{
			goto IL_0013;
		}
	}
	{
		int32_t L_5 = V_0;
		return L_5;
	}

IL_0013:
	{
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_6 = ___0_a;
		int32_t L_7 = L_6.___y;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_8 = ___1_b;
		int32_t L_9 = L_8.___y;
		V_0 = ((int32_t)il2cpp_codegen_subtract(L_7, L_9));
		int32_t L_10 = V_0;
		if (!L_10)
		{
			goto IL_0026;
		}
	}
	{
		int32_t L_11 = V_0;
		return L_11;
	}

IL_0026:
	{
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_12 = ___0_a;
		int32_t L_13 = L_12.___z;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_14 = ___1_b;
		int32_t L_15 = L_14.___z;
		V_0 = ((int32_t)il2cpp_codegen_subtract(L_13, L_15));
		int32_t L_16 = V_0;
		if (!L_16)
		{
			goto IL_0039;
		}
	}
	{
		int32_t L_17 = V_0;
		return L_17;
	}

IL_0039:
	{
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_18 = ___0_a;
		int32_t L_19 = L_18.___w;
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_20 = ___1_b;
		int32_t L_21 = L_20.___w;
		V_0 = ((int32_t)il2cpp_codegen_subtract(L_19, L_21));
		int32_t L_22 = V_0;
		return L_22;
	}
}
IL2CPP_EXTERN_C  int32_t DelaEdgeCompare_Compare_m9D63142C6EBC894B7DAD24EBE3A38FDD5678BEF2_AdjustorThunk (RuntimeObject* __this, int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___0_a, int4_tBA77D4945786DE82C3A487B33955EA1004996052 ___1_b, const RuntimeMethod* method)
{
	DelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<DelaEdgeCompare_tB840B82782097F179823018C8C3F86D79167714B*>(__this + _offset);
	int32_t _returnValue;
	_returnValue = DelaEdgeCompare_Compare_m9D63142C6EBC894B7DAD24EBE3A38FDD5678BEF2(_thisAdjusted, ___0_a, ___1_b, method);
	return _returnValue;
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38 TessLink_CreateLink_m1E7D2D1DD89E196BF1CBBDC76B508021F81B2FB8 (int32_t ___0_count, int32_t ___1_allocator, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38 V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	{
		il2cpp_codegen_initobj((&V_0), sizeof(TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38));
		int32_t L_0 = ___0_count;
		int32_t L_1 = ___1_allocator;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_2;
		memset((&L_2), 0, sizeof(L_2));
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&L_2), L_0, L_1, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		(&V_0)->___roots = L_2;
		int32_t L_3 = ___0_count;
		int32_t L_4 = ___1_allocator;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_5;
		memset((&L_5), 0, sizeof(L_5));
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&L_5), L_3, L_4, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		(&V_0)->___ranks = L_5;
		V_1 = 0;
		goto IL_004a;
	}

IL_002a:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_6 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&(&V_0)->___roots);
		int32_t L_7 = V_1;
		int32_t L_8 = V_1;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_6)->___m_Buffer, L_7, (L_8));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_9 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&(&V_0)->___ranks);
		int32_t L_10 = V_1;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_9)->___m_Buffer, L_10, (0));
		int32_t L_11 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_11, 1));
	}

IL_004a:
	{
		int32_t L_12 = V_1;
		int32_t L_13 = ___0_count;
		if ((((int32_t)L_12) < ((int32_t)L_13)))
		{
			goto IL_002a;
		}
	}
	{
		TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38 L_14 = V_0;
		return L_14;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TessLink_DestroyLink_m96AD3C95F393DABD8862EC3CE5F8EEEB905B1CAD (TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38 ___0_link, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_0 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&(&___0_link)->___ranks);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E(L_0, NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_1 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&(&___0_link)->___roots);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E(L_1, NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR int32_t TessLink_Find_mAD567324D6131379359E9A266D2AC30A31F0226E (TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38* __this, int32_t ___0_x, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	{
		int32_t L_0 = ___0_x;
		V_0 = L_0;
		goto IL_0012;
	}

IL_0004:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_1 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___roots);
		int32_t L_2 = ___0_x;
		int32_t L_3;
		L_3 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_1)->___m_Buffer, L_2);
		___0_x = L_3;
	}

IL_0012:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_4 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___roots);
		int32_t L_5 = ___0_x;
		int32_t L_6;
		L_6 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_4)->___m_Buffer, L_5);
		int32_t L_7 = ___0_x;
		if ((!(((uint32_t)L_6) == ((uint32_t)L_7))))
		{
			goto IL_0004;
		}
	}
	{
		goto IL_003d;
	}

IL_0023:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_8 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___roots);
		int32_t L_9 = V_0;
		int32_t L_10;
		L_10 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_8)->___m_Buffer, L_9);
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_11 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___roots);
		int32_t L_12 = V_0;
		int32_t L_13 = ___0_x;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_11)->___m_Buffer, L_12, (L_13));
		V_0 = L_10;
	}

IL_003d:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_14 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___roots);
		int32_t L_15 = V_0;
		int32_t L_16;
		L_16 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_14)->___m_Buffer, L_15);
		int32_t L_17 = ___0_x;
		if ((!(((uint32_t)L_16) == ((uint32_t)L_17))))
		{
			goto IL_0023;
		}
	}
	{
		int32_t L_18 = ___0_x;
		return L_18;
	}
}
IL2CPP_EXTERN_C  int32_t TessLink_Find_mAD567324D6131379359E9A266D2AC30A31F0226E_AdjustorThunk (RuntimeObject* __this, int32_t ___0_x, const RuntimeMethod* method)
{
	TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38*>(__this + _offset);
	int32_t _returnValue;
	_returnValue = TessLink_Find_mAD567324D6131379359E9A266D2AC30A31F0226E(_thisAdjusted, ___0_x, method);
	return _returnValue;
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void TessLink_Link_m549C4DE253753727A94A94BC9BC7EF6B417DC9E0 (TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38* __this, int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) 
{
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	{
		int32_t L_0 = ___0_x;
		int32_t L_1;
		L_1 = TessLink_Find_mAD567324D6131379359E9A266D2AC30A31F0226E(__this, L_0, NULL);
		V_0 = L_1;
		int32_t L_2 = ___1_y;
		int32_t L_3;
		L_3 = TessLink_Find_mAD567324D6131379359E9A266D2AC30A31F0226E(__this, L_2, NULL);
		V_1 = L_3;
		int32_t L_4 = V_0;
		int32_t L_5 = V_1;
		if ((!(((uint32_t)L_4) == ((uint32_t)L_5))))
		{
			goto IL_0015;
		}
	}
	{
		return;
	}

IL_0015:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_6 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___ranks);
		int32_t L_7 = V_0;
		int32_t L_8;
		L_8 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_6)->___m_Buffer, L_7);
		V_2 = L_8;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_9 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___ranks);
		int32_t L_10 = V_1;
		int32_t L_11;
		L_11 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_9)->___m_Buffer, L_10);
		V_3 = L_11;
		int32_t L_12 = V_2;
		int32_t L_13 = V_3;
		if ((((int32_t)L_12) >= ((int32_t)L_13)))
		{
			goto IL_0041;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_14 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___roots);
		int32_t L_15 = V_0;
		int32_t L_16 = V_1;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_14)->___m_Buffer, L_15, (L_16));
		return;
	}

IL_0041:
	{
		int32_t L_17 = V_3;
		int32_t L_18 = V_2;
		if ((((int32_t)L_17) >= ((int32_t)L_18)))
		{
			goto IL_0053;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_19 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___roots);
		int32_t L_20 = V_1;
		int32_t L_21 = V_0;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_19)->___m_Buffer, L_20, (L_21));
		return;
	}

IL_0053:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_22 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___roots);
		int32_t L_23 = V_1;
		int32_t L_24 = V_0;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_22)->___m_Buffer, L_23, (L_24));
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_25 = (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)(&__this->___ranks);
		int32_t L_26 = V_0;
		V_4 = L_26;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_27 = L_25;
		int32_t L_28 = V_4;
		int32_t L_29;
		L_29 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_27)->___m_Buffer, L_28);
		V_5 = ((int32_t)il2cpp_codegen_add(L_29, 1));
		int32_t L_30 = V_4;
		int32_t L_31 = V_5;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_27)->___m_Buffer, L_30, (L_31));
		return;
	}
}
IL2CPP_EXTERN_C  void TessLink_Link_m549C4DE253753727A94A94BC9BC7EF6B417DC9E0_AdjustorThunk (RuntimeObject* __this, int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method)
{
	TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38* _thisAdjusted;
	int32_t _offset = 1;
	_thisAdjusted = reinterpret_cast<TessLink_tB36FA873ED8F645C11850647C5EAECC581B60D38*>(__this + _offset);
	TessLink_Link_m549C4DE253753727A94A94BC9BC7EF6B417DC9E0(_thisAdjusted, ___0_x, ___1_y, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float ModuleHandle_OrientFast_m39D34C2844061E3607200824ADE00A8CA5680634 (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_a, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_b, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_c, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	float V_1 = 0.0f;
	{
		V_0 = (1.11022302E-16f);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___1_b;
		float L_1 = L_0.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = ___0_a;
		float L_3 = L_2.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = ___2_c;
		float L_5 = L_4.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6 = ___1_b;
		float L_7 = L_6.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_8 = ___1_b;
		float L_9 = L_8.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_10 = ___0_a;
		float L_11 = L_10.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_12 = ___2_c;
		float L_13 = L_12.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_14 = ___1_b;
		float L_15 = L_14.___y;
		V_1 = ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(L_1, L_3)), ((float)il2cpp_codegen_subtract(L_5, L_7)))), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(L_9, L_11)), ((float)il2cpp_codegen_subtract(L_13, L_15))))));
		float L_16 = V_1;
		float L_17;
		L_17 = math_abs_m3D9508B36B045BFE7B89C6C69AD34596264E4FE1_inline(L_16, NULL);
		float L_18 = V_0;
		if ((!(((float)L_17) < ((float)L_18))))
		{
			goto IL_004d;
		}
	}
	{
		return (0.0f);
	}

IL_004d:
	{
		float L_19 = V_1;
		return L_19;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR double ModuleHandle_OrientFastDouble_mABC4A67B5FBB79701003AF2B4367E67DA4E021AA (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_a, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_b, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___2_c, const RuntimeMethod* method) 
{
	double V_0 = 0.0;
	double V_1 = 0.0;
	{
		V_0 = (1.1102230246251565E-16);
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_0 = ___1_b;
		double L_1 = L_0.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_2 = ___0_a;
		double L_3 = L_2.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_4 = ___2_c;
		double L_5 = L_4.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_6 = ___1_b;
		double L_7 = L_6.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_8 = ___1_b;
		double L_9 = L_8.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_10 = ___0_a;
		double L_11 = L_10.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_12 = ___2_c;
		double L_13 = L_12.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_14 = ___1_b;
		double L_15 = L_14.___y;
		V_1 = ((double)il2cpp_codegen_subtract(((double)il2cpp_codegen_multiply(((double)il2cpp_codegen_subtract(L_1, L_3)), ((double)il2cpp_codegen_subtract(L_5, L_7)))), ((double)il2cpp_codegen_multiply(((double)il2cpp_codegen_subtract(L_9, L_11)), ((double)il2cpp_codegen_subtract(L_13, L_15))))));
		double L_16 = V_1;
		double L_17;
		L_17 = math_abs_mDF669CF3AF2C60713E8E118578461CDA050DAFD0_inline(L_16, NULL);
		double L_18 = V_0;
		if ((!(((double)L_17) < ((double)L_18))))
		{
			goto IL_0055;
		}
	}
	{
		return (0.0);
	}

IL_0055:
	{
		double L_19 = V_1;
		return L_19;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 ModuleHandle_CircumCircle_m55302C4846463A91AB57830760699DC95BF4AC0B (UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD ___0_tri, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	float V_1 = 0.0f;
	float V_2 = 0.0f;
	float V_3 = 0.0f;
	float V_4 = 0.0f;
	float V_5 = 0.0f;
	float V_6 = 0.0f;
	float V_7 = 0.0f;
	float V_8 = 0.0f;
	float V_9 = 0.0f;
	float V_10 = 0.0f;
	UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 V_11;
	memset((&V_11), 0, sizeof(V_11));
	{
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_0 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_1 = L_0.___va;
		float L_2 = L_1.___x;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_3 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = L_3.___va;
		float L_5 = L_4.___x;
		V_0 = ((float)il2cpp_codegen_multiply(L_2, L_5));
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_6 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_7 = L_6.___vb;
		float L_8 = L_7.___x;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_9 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_10 = L_9.___vb;
		float L_11 = L_10.___x;
		V_1 = ((float)il2cpp_codegen_multiply(L_8, L_11));
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_12 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_13 = L_12.___vc;
		float L_14 = L_13.___x;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_15 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_16 = L_15.___vc;
		float L_17 = L_16.___x;
		V_2 = ((float)il2cpp_codegen_multiply(L_14, L_17));
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_18 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_19 = L_18.___va;
		float L_20 = L_19.___y;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_21 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_22 = L_21.___va;
		float L_23 = L_22.___y;
		V_3 = ((float)il2cpp_codegen_multiply(L_20, L_23));
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_24 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_25 = L_24.___vb;
		float L_26 = L_25.___y;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_27 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_28 = L_27.___vb;
		float L_29 = L_28.___y;
		V_4 = ((float)il2cpp_codegen_multiply(L_26, L_29));
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_30 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_31 = L_30.___vc;
		float L_32 = L_31.___y;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_33 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_34 = L_33.___vc;
		float L_35 = L_34.___y;
		V_5 = ((float)il2cpp_codegen_multiply(L_32, L_35));
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_36 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_37 = L_36.___vb;
		float L_38 = L_37.___x;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_39 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_40 = L_39.___va;
		float L_41 = L_40.___x;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_42 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_43 = L_42.___vc;
		float L_44 = L_43.___y;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_45 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_46 = L_45.___va;
		float L_47 = L_46.___y;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_48 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_49 = L_48.___vb;
		float L_50 = L_49.___y;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_51 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_52 = L_51.___va;
		float L_53 = L_52.___y;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_54 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_55 = L_54.___vc;
		float L_56 = L_55.___x;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_57 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_58 = L_57.___va;
		float L_59 = L_58.___x;
		V_6 = ((float)il2cpp_codegen_multiply((2.0f), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(L_38, L_41)), ((float)il2cpp_codegen_subtract(L_44, L_47)))), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(L_50, L_53)), ((float)il2cpp_codegen_subtract(L_56, L_59))))))));
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_60 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_61 = L_60.___vc;
		float L_62 = L_61.___y;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_63 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_64 = L_63.___va;
		float L_65 = L_64.___y;
		float L_66 = V_1;
		float L_67 = V_0;
		float L_68 = V_4;
		float L_69 = V_3;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_70 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_71 = L_70.___va;
		float L_72 = L_71.___y;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_73 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_74 = L_73.___vb;
		float L_75 = L_74.___y;
		float L_76 = V_2;
		float L_77 = V_0;
		float L_78 = V_5;
		float L_79 = V_3;
		float L_80 = V_6;
		V_7 = ((float)(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(L_62, L_65)), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_66, L_67)), L_68)), L_69)))), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(L_72, L_75)), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_76, L_77)), L_78)), L_79))))))/L_80));
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_81 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_82 = L_81.___va;
		float L_83 = L_82.___x;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_84 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_85 = L_84.___vc;
		float L_86 = L_85.___x;
		float L_87 = V_1;
		float L_88 = V_0;
		float L_89 = V_4;
		float L_90 = V_3;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_91 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_92 = L_91.___vb;
		float L_93 = L_92.___x;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_94 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_95 = L_94.___va;
		float L_96 = L_95.___x;
		float L_97 = V_2;
		float L_98 = V_0;
		float L_99 = V_5;
		float L_100 = V_3;
		float L_101 = V_6;
		V_8 = ((float)(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(L_83, L_86)), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_87, L_88)), L_89)), L_90)))), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(L_93, L_96)), ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_add(((float)il2cpp_codegen_subtract(L_97, L_98)), L_99)), L_100))))))/L_101));
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_102 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_103 = L_102.___va;
		float L_104 = L_103.___x;
		float L_105 = V_7;
		V_9 = ((float)il2cpp_codegen_subtract(L_104, L_105));
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_106 = ___0_tri;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_107 = L_106.___va;
		float L_108 = L_107.___y;
		float L_109 = V_8;
		V_10 = ((float)il2cpp_codegen_subtract(L_108, L_109));
		il2cpp_codegen_initobj((&V_11), sizeof(UCircle_t68411F86930A7056CDBAB9E208076A3075D15218));
		float L_110 = V_7;
		float L_111 = V_8;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_112;
		memset((&L_112), 0, sizeof(L_112));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_112), L_110, L_111, NULL);
		(&V_11)->___center = L_112;
		float L_113 = V_9;
		float L_114 = V_9;
		float L_115 = V_10;
		float L_116 = V_10;
		float L_117;
		L_117 = math_sqrt_mEF31DE7BD0179009683C5D7B0C58E6571B30CF4A_inline(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_113, L_114)), ((float)il2cpp_codegen_multiply(L_115, L_116)))), NULL);
		(&V_11)->___radius = L_117;
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_118 = V_11;
		return L_118;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ModuleHandle_IsInsideCircle_m9EADD14E649CC57BF2A7D62D1CE8B0EF83943804 (UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 ___0_c, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_v, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___1_v;
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_1 = ___0_c;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = L_1.___center;
		float L_3;
		L_3 = math_distance_mE5E0FFDD103E710A4CB23360BFCAFD0AF2E1EFA9_inline(L_0, L_2, NULL);
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_4 = ___0_c;
		float L_5 = L_4.___radius;
		return (bool)((((float)L_3) < ((float)L_5))? 1 : 0);
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float ModuleHandle_TriangleArea_m40B327CC9176416944F14D245D0F49DD5CB2CEA0 (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_va, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_vb, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_vc, const RuntimeMethod* method) 
{
	float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E V_0;
	memset((&V_0), 0, sizeof(V_0));
	float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E V_1;
	memset((&V_1), 0, sizeof(V_1));
	float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E V_2;
	memset((&V_2), 0, sizeof(V_2));
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_va;
		float L_1 = L_0.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = ___0_va;
		float L_3 = L_2.___y;
		float3__ctor_mC61002CD0EC13D7C37D846D021A78C028FB80DB9_inline((&V_0), L_1, L_3, (0.0f), NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = ___1_vb;
		float L_5 = L_4.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6 = ___1_vb;
		float L_7 = L_6.___y;
		float3__ctor_mC61002CD0EC13D7C37D846D021A78C028FB80DB9_inline((&V_1), L_5, L_7, (0.0f), NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_8 = ___2_vc;
		float L_9 = L_8.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_10 = ___2_vc;
		float L_11 = L_10.___y;
		float3__ctor_mC61002CD0EC13D7C37D846D021A78C028FB80DB9_inline((&V_2), L_9, L_11, (0.0f), NULL);
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_12 = V_0;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_13 = V_1;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_14;
		L_14 = float3_op_Subtraction_mB6036E9849D95650D6E73DA0D179CD7B61E696F2_inline(L_12, L_13, NULL);
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_15 = V_0;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_16 = V_2;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_17;
		L_17 = float3_op_Subtraction_mB6036E9849D95650D6E73DA0D179CD7B61E696F2_inline(L_15, L_16, NULL);
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_18;
		L_18 = math_cross_m4CA2DAE150C6381B0D05E8AA9E48E88CF6157180_inline(L_14, L_17, NULL);
		float L_19 = L_18.___z;
		float L_20;
		L_20 = math_abs_m3D9508B36B045BFE7B89C6C69AD34596264E4FE1_inline(L_19, NULL);
		return ((float)il2cpp_codegen_multiply(L_20, (0.5f)));
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float ModuleHandle_Sign_mAD4C03A02763F90C0B6BB07F6A9A11DC00B59294 (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_p1, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_p2, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_p3, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_p1;
		float L_1 = L_0.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = ___2_p3;
		float L_3 = L_2.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = ___1_p2;
		float L_5 = L_4.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6 = ___2_p3;
		float L_7 = L_6.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_8 = ___1_p2;
		float L_9 = L_8.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_10 = ___2_p3;
		float L_11 = L_10.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_12 = ___0_p1;
		float L_13 = L_12.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_14 = ___2_p3;
		float L_15 = L_14.___y;
		return ((float)il2cpp_codegen_subtract(((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(L_1, L_3)), ((float)il2cpp_codegen_subtract(L_5, L_7)))), ((float)il2cpp_codegen_multiply(((float)il2cpp_codegen_subtract(L_9, L_11)), ((float)il2cpp_codegen_subtract(L_13, L_15))))));
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ModuleHandle_IsInsideTriangle_m014222929EBBBFF8B3FCF265D1AB1302CE8DD9B5 (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_pt, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_v1, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_v2, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___3_v3, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	float V_1 = 0.0f;
	bool V_2 = false;
	bool V_3 = false;
	float G_B3_0 = 0.0f;
	float G_B1_0 = 0.0f;
	float G_B2_0 = 0.0f;
	int32_t G_B4_0 = 0;
	float G_B4_1 = 0.0f;
	int32_t G_B8_0 = 0;
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_pt;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_1 = ___1_v1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = ___2_v2;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		float L_3;
		L_3 = ModuleHandle_Sign_mAD4C03A02763F90C0B6BB07F6A9A11DC00B59294(L_0, L_1, L_2, NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = ___0_pt;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_5 = ___2_v2;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6 = ___3_v3;
		float L_7;
		L_7 = ModuleHandle_Sign_mAD4C03A02763F90C0B6BB07F6A9A11DC00B59294(L_4, L_5, L_6, NULL);
		V_0 = L_7;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_8 = ___0_pt;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_9 = ___3_v3;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_10 = ___1_v1;
		float L_11;
		L_11 = ModuleHandle_Sign_mAD4C03A02763F90C0B6BB07F6A9A11DC00B59294(L_8, L_9, L_10, NULL);
		V_1 = L_11;
		float L_12 = L_3;
		if ((((float)L_12) < ((float)(0.0f))))
		{
			G_B3_0 = L_12;
			goto IL_0034;
		}
		G_B1_0 = L_12;
	}
	{
		float L_13 = V_0;
		if ((((float)L_13) < ((float)(0.0f))))
		{
			G_B3_0 = G_B1_0;
			goto IL_0034;
		}
		G_B2_0 = G_B1_0;
	}
	{
		float L_14 = V_1;
		G_B4_0 = ((((float)L_14) < ((float)(0.0f)))? 1 : 0);
		G_B4_1 = G_B2_0;
		goto IL_0035;
	}

IL_0034:
	{
		G_B4_0 = 1;
		G_B4_1 = G_B3_0;
	}

IL_0035:
	{
		V_2 = (bool)G_B4_0;
		if ((((float)G_B4_1) > ((float)(0.0f))))
		{
			goto IL_004f;
		}
	}
	{
		float L_15 = V_0;
		if ((((float)L_15) > ((float)(0.0f))))
		{
			goto IL_004f;
		}
	}
	{
		float L_16 = V_1;
		G_B8_0 = ((((float)L_16) > ((float)(0.0f)))? 1 : 0);
		goto IL_0050;
	}

IL_004f:
	{
		G_B8_0 = 1;
	}

IL_0050:
	{
		V_3 = (bool)G_B8_0;
		bool L_17 = V_2;
		bool L_18 = V_3;
		return (bool)((((int32_t)((int32_t)((int32_t)L_17&(int32_t)L_18))) == ((int32_t)0))? 1 : 0);
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ModuleHandle_IsInsideTriangleApproximate_mF5C0D5E914AA32D2FE47DFD536A53DC7E3D741A0 (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_pt, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_v1, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_v2, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___3_v3, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float V_0 = 0.0f;
	float V_1 = 0.0f;
	float V_2 = 0.0f;
	float V_3 = 0.0f;
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___1_v1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_1 = ___2_v2;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = ___3_v3;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		float L_3;
		L_3 = ModuleHandle_TriangleArea_m40B327CC9176416944F14D245D0F49DD5CB2CEA0(L_0, L_1, L_2, NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = ___0_pt;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_5 = ___1_v1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6 = ___2_v2;
		float L_7;
		L_7 = ModuleHandle_TriangleArea_m40B327CC9176416944F14D245D0F49DD5CB2CEA0(L_4, L_5, L_6, NULL);
		V_0 = L_7;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_8 = ___0_pt;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_9 = ___2_v2;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_10 = ___3_v3;
		float L_11;
		L_11 = ModuleHandle_TriangleArea_m40B327CC9176416944F14D245D0F49DD5CB2CEA0(L_8, L_9, L_10, NULL);
		V_1 = L_11;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_12 = ___0_pt;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_13 = ___3_v3;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_14 = ___1_v1;
		float L_15;
		L_15 = ModuleHandle_TriangleArea_m40B327CC9176416944F14D245D0F49DD5CB2CEA0(L_12, L_13, L_14, NULL);
		V_2 = L_15;
		V_3 = (1.11022302E-16f);
		float L_16 = V_0;
		float L_17 = V_1;
		float L_18 = V_2;
		float L_19;
		L_19 = fabsf(((float)il2cpp_codegen_subtract(L_3, ((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(L_16, L_17)), L_18)))));
		float L_20 = V_3;
		return (bool)((((float)L_19) < ((float)L_20))? 1 : 0);
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR bool ModuleHandle_IsInsideCircle_m7A080360A299D2F6BAF0390791DD36650D30AC2D (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_a, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_b, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___2_c, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___3_p, const RuntimeMethod* method) 
{
	float V_0 = 0.0f;
	float V_1 = 0.0f;
	float V_2 = 0.0f;
	float V_3 = 0.0f;
	float V_4 = 0.0f;
	float V_5 = 0.0f;
	float V_6 = 0.0f;
	float V_7 = 0.0f;
	float V_8 = 0.0f;
	float V_9 = 0.0f;
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_10;
	memset((&V_10), 0, sizeof(V_10));
	float V_11 = 0.0f;
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_a;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_1 = ___0_a;
		float L_2;
		L_2 = math_dot_mF673D3E5B7D267C0A8569B678D05BDCCB667D04D_inline(L_0, L_1, NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_3 = ___1_b;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = ___1_b;
		float L_5;
		L_5 = math_dot_mF673D3E5B7D267C0A8569B678D05BDCCB667D04D_inline(L_3, L_4, NULL);
		V_0 = L_5;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6 = ___2_c;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_7 = ___2_c;
		float L_8;
		L_8 = math_dot_mF673D3E5B7D267C0A8569B678D05BDCCB667D04D_inline(L_6, L_7, NULL);
		V_1 = L_8;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_9 = ___0_a;
		float L_10 = L_9.___x;
		V_2 = L_10;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_11 = ___0_a;
		float L_12 = L_11.___y;
		V_3 = L_12;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_13 = ___1_b;
		float L_14 = L_13.___x;
		V_4 = L_14;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_15 = ___1_b;
		float L_16 = L_15.___y;
		V_5 = L_16;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_17 = ___2_c;
		float L_18 = L_17.___x;
		V_6 = L_18;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_19 = ___2_c;
		float L_20 = L_19.___y;
		V_7 = L_20;
		float L_21 = L_2;
		float L_22 = V_7;
		float L_23 = V_5;
		float L_24 = V_0;
		float L_25 = V_3;
		float L_26 = V_7;
		float L_27 = V_1;
		float L_28 = V_5;
		float L_29 = V_3;
		float L_30 = V_2;
		float L_31 = V_7;
		float L_32 = V_5;
		float L_33 = V_4;
		float L_34 = V_3;
		float L_35 = V_7;
		float L_36 = V_6;
		float L_37 = V_5;
		float L_38 = V_3;
		V_8 = ((float)(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_21, ((float)il2cpp_codegen_subtract(L_22, L_23)))), ((float)il2cpp_codegen_multiply(L_24, ((float)il2cpp_codegen_subtract(L_25, L_26)))))), ((float)il2cpp_codegen_multiply(L_27, ((float)il2cpp_codegen_subtract(L_28, L_29))))))/((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_30, ((float)il2cpp_codegen_subtract(L_31, L_32)))), ((float)il2cpp_codegen_multiply(L_33, ((float)il2cpp_codegen_subtract(L_34, L_35)))))), ((float)il2cpp_codegen_multiply(L_36, ((float)il2cpp_codegen_subtract(L_37, L_38))))))));
		float L_39 = V_6;
		float L_40 = V_4;
		float L_41 = V_0;
		float L_42 = V_2;
		float L_43 = V_6;
		float L_44 = V_1;
		float L_45 = V_4;
		float L_46 = V_2;
		float L_47 = V_3;
		float L_48 = V_6;
		float L_49 = V_4;
		float L_50 = V_5;
		float L_51 = V_2;
		float L_52 = V_6;
		float L_53 = V_7;
		float L_54 = V_4;
		float L_55 = V_2;
		V_9 = ((float)(((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_21, ((float)il2cpp_codegen_subtract(L_39, L_40)))), ((float)il2cpp_codegen_multiply(L_41, ((float)il2cpp_codegen_subtract(L_42, L_43)))))), ((float)il2cpp_codegen_multiply(L_44, ((float)il2cpp_codegen_subtract(L_45, L_46))))))/((float)il2cpp_codegen_add(((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_47, ((float)il2cpp_codegen_subtract(L_48, L_49)))), ((float)il2cpp_codegen_multiply(L_50, ((float)il2cpp_codegen_subtract(L_51, L_52)))))), ((float)il2cpp_codegen_multiply(L_53, ((float)il2cpp_codegen_subtract(L_54, L_55))))))));
		il2cpp_codegen_initobj((&V_10), sizeof(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA));
		float L_56 = V_8;
		(&V_10)->___x = ((float)(L_56/(2.0f)));
		float L_57 = V_9;
		(&V_10)->___y = ((float)(L_57/(2.0f)));
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_58 = ___0_a;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_59 = V_10;
		float L_60;
		L_60 = math_distance_mE5E0FFDD103E710A4CB23360BFCAFD0AF2E1EFA9_inline(L_58, L_59, NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_61 = ___3_p;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_62 = V_10;
		float L_63;
		L_63 = math_distance_mE5E0FFDD103E710A4CB23360BFCAFD0AF2E1EFA9_inline(L_61, L_62, NULL);
		V_11 = L_63;
		float L_64 = V_11;
		return (bool)((((float)((float)il2cpp_codegen_subtract(L_60, L_64))) > ((float)(9.99999975E-06f)))? 1 : 0);
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_BuildTriangles_m48C3ED6D6EEFF398B32541E7685F1332A0040BA6 (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_vertices, int32_t ___1_vertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___2_indices, int32_t ___3_indexCount, NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5* ___4_triangles, int32_t* ___5_triangleCount, float* ___6_maxArea, float* ___7_avgArea, float* ___8_minArea, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD V_1;
	memset((&V_1), 0, sizeof(V_1));
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	{
		V_0 = 0;
		goto IL_00d1;
	}

IL_0007:
	{
		il2cpp_codegen_initobj((&V_1), sizeof(UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD));
		int32_t L_0 = V_0;
		int32_t L_1;
		L_1 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&___2_indices))->___m_Buffer, L_0);
		V_2 = L_1;
		int32_t L_2 = V_0;
		int32_t L_3;
		L_3 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&___2_indices))->___m_Buffer, ((int32_t)il2cpp_codegen_add(L_2, 1)));
		V_3 = L_3;
		int32_t L_4 = V_0;
		int32_t L_5;
		L_5 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&___2_indices))->___m_Buffer, ((int32_t)il2cpp_codegen_add(L_4, 2)));
		V_4 = L_5;
		int32_t L_6 = V_2;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_7;
		L_7 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_vertices))->___m_Buffer, L_6);
		(&V_1)->___va = L_7;
		int32_t L_8 = V_3;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_9;
		L_9 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_vertices))->___m_Buffer, L_8);
		(&V_1)->___vb = L_9;
		int32_t L_10 = V_4;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_11;
		L_11 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_vertices))->___m_Buffer, L_10);
		(&V_1)->___vc = L_11;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_12 = V_1;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_13;
		L_13 = ModuleHandle_CircumCircle_m55302C4846463A91AB57830760699DC95BF4AC0B(L_12, NULL);
		(&V_1)->___c = L_13;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_14 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_15 = L_14.___va;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_16 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_17 = L_16.___vb;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_18 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_19 = L_18.___vc;
		float L_20;
		L_20 = ModuleHandle_TriangleArea_m40B327CC9176416944F14D245D0F49DD5CB2CEA0(L_15, L_17, L_19, NULL);
		(&V_1)->___area = L_20;
		float* L_21 = ___6_maxArea;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_22 = V_1;
		float L_23 = L_22.___area;
		float* L_24 = ___6_maxArea;
		float L_25 = *((float*)L_24);
		float L_26;
		L_26 = math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline(L_23, L_25, NULL);
		*((float*)L_21) = (float)L_26;
		float* L_27 = ___8_minArea;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_28 = V_1;
		float L_29 = L_28.___area;
		float* L_30 = ___8_minArea;
		float L_31 = *((float*)L_30);
		float L_32;
		L_32 = math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline(L_29, L_31, NULL);
		*((float*)L_27) = (float)L_32;
		float* L_33 = ___7_avgArea;
		float* L_34 = ___7_avgArea;
		float L_35 = *((float*)L_34);
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_36 = V_1;
		float L_37 = L_36.___area;
		*((float*)L_33) = (float)((float)il2cpp_codegen_add(L_35, L_37));
		NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5* L_38 = ___4_triangles;
		int32_t* L_39 = ___5_triangleCount;
		int32_t* L_40 = ___5_triangleCount;
		int32_t L_41 = *((int32_t*)L_40);
		V_5 = L_41;
		int32_t L_42 = V_5;
		*((int32_t*)L_39) = (int32_t)((int32_t)il2cpp_codegen_add(L_42, 1));
		int32_t L_43 = V_5;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_44 = V_1;
		IL2CPP_NATIVEARRAY_SET_ITEM(UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD, (L_38)->___m_Buffer, L_43, (L_44));
		int32_t L_45 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_45, 3));
	}

IL_00d1:
	{
		int32_t L_46 = V_0;
		int32_t L_47 = ___3_indexCount;
		if ((((int32_t)L_46) < ((int32_t)L_47)))
		{
			goto IL_0007;
		}
	}
	{
		float* L_48 = ___7_avgArea;
		float* L_49 = ___7_avgArea;
		float L_50 = *((float*)L_49);
		int32_t* L_51 = ___5_triangleCount;
		int32_t L_52 = *((int32_t*)L_51);
		*((float*)L_48) = (float)((float)(L_50/((float)L_52)));
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_BuildTriangles_m2C767A1D0CBE89D726305D210EB2416DE1DA98CD (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_vertices, int32_t ___1_vertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___2_indices, int32_t ___3_indexCount, NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5* ___4_triangles, int32_t* ___5_triangleCount, float* ___6_maxArea, float* ___7_avgArea, float* ___8_minArea, float* ___9_maxEdge, float* ___10_avgEdge, float* ___11_minEdge, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD V_1;
	memset((&V_1), 0, sizeof(V_1));
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	float V_5 = 0.0f;
	float V_6 = 0.0f;
	float V_7 = 0.0f;
	int32_t V_8 = 0;
	{
		V_0 = 0;
		goto IL_0173;
	}

IL_0007:
	{
		il2cpp_codegen_initobj((&V_1), sizeof(UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD));
		int32_t L_0 = V_0;
		int32_t L_1;
		L_1 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&___2_indices))->___m_Buffer, L_0);
		V_2 = L_1;
		int32_t L_2 = V_0;
		int32_t L_3;
		L_3 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&___2_indices))->___m_Buffer, ((int32_t)il2cpp_codegen_add(L_2, 1)));
		V_3 = L_3;
		int32_t L_4 = V_0;
		int32_t L_5;
		L_5 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&___2_indices))->___m_Buffer, ((int32_t)il2cpp_codegen_add(L_4, 2)));
		V_4 = L_5;
		int32_t L_6 = V_2;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_7;
		L_7 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_vertices))->___m_Buffer, L_6);
		(&V_1)->___va = L_7;
		int32_t L_8 = V_3;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_9;
		L_9 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_vertices))->___m_Buffer, L_8);
		(&V_1)->___vb = L_9;
		int32_t L_10 = V_4;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_11;
		L_11 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_vertices))->___m_Buffer, L_10);
		(&V_1)->___vc = L_11;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_12 = V_1;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_13;
		L_13 = ModuleHandle_CircumCircle_m55302C4846463A91AB57830760699DC95BF4AC0B(L_12, NULL);
		(&V_1)->___c = L_13;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_14 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_15 = L_14.___va;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_16 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_17 = L_16.___vb;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_18 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_19 = L_18.___vc;
		float L_20;
		L_20 = ModuleHandle_TriangleArea_m40B327CC9176416944F14D245D0F49DD5CB2CEA0(L_15, L_17, L_19, NULL);
		(&V_1)->___area = L_20;
		float* L_21 = ___6_maxArea;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_22 = V_1;
		float L_23 = L_22.___area;
		float* L_24 = ___6_maxArea;
		float L_25 = *((float*)L_24);
		float L_26;
		L_26 = math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline(L_23, L_25, NULL);
		*((float*)L_21) = (float)L_26;
		float* L_27 = ___8_minArea;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_28 = V_1;
		float L_29 = L_28.___area;
		float* L_30 = ___8_minArea;
		float L_31 = *((float*)L_30);
		float L_32;
		L_32 = math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline(L_29, L_31, NULL);
		*((float*)L_27) = (float)L_32;
		float* L_33 = ___7_avgArea;
		float* L_34 = ___7_avgArea;
		float L_35 = *((float*)L_34);
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_36 = V_1;
		float L_37 = L_36.___area;
		*((float*)L_33) = (float)((float)il2cpp_codegen_add(L_35, L_37));
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_38 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_39 = L_38.___va;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_40 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_41 = L_40.___vb;
		float L_42;
		L_42 = math_distance_mE5E0FFDD103E710A4CB23360BFCAFD0AF2E1EFA9_inline(L_39, L_41, NULL);
		V_5 = L_42;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_43 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_44 = L_43.___vb;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_45 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_46 = L_45.___vc;
		float L_47;
		L_47 = math_distance_mE5E0FFDD103E710A4CB23360BFCAFD0AF2E1EFA9_inline(L_44, L_46, NULL);
		V_6 = L_47;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_48 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_49 = L_48.___vc;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_50 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_51 = L_50.___va;
		float L_52;
		L_52 = math_distance_mE5E0FFDD103E710A4CB23360BFCAFD0AF2E1EFA9_inline(L_49, L_51, NULL);
		V_7 = L_52;
		float* L_53 = ___9_maxEdge;
		float L_54 = V_5;
		float* L_55 = ___9_maxEdge;
		float L_56 = *((float*)L_55);
		float L_57;
		L_57 = math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline(L_54, L_56, NULL);
		*((float*)L_53) = (float)L_57;
		float* L_58 = ___9_maxEdge;
		float L_59 = V_6;
		float* L_60 = ___9_maxEdge;
		float L_61 = *((float*)L_60);
		float L_62;
		L_62 = math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline(L_59, L_61, NULL);
		*((float*)L_58) = (float)L_62;
		float* L_63 = ___9_maxEdge;
		float L_64 = V_7;
		float* L_65 = ___9_maxEdge;
		float L_66 = *((float*)L_65);
		float L_67;
		L_67 = math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline(L_64, L_66, NULL);
		*((float*)L_63) = (float)L_67;
		float* L_68 = ___11_minEdge;
		float L_69 = V_5;
		float* L_70 = ___11_minEdge;
		float L_71 = *((float*)L_70);
		float L_72;
		L_72 = math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline(L_69, L_71, NULL);
		*((float*)L_68) = (float)L_72;
		float* L_73 = ___11_minEdge;
		float L_74 = V_6;
		float* L_75 = ___11_minEdge;
		float L_76 = *((float*)L_75);
		float L_77;
		L_77 = math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline(L_74, L_76, NULL);
		*((float*)L_73) = (float)L_77;
		float* L_78 = ___11_minEdge;
		float L_79 = V_7;
		float* L_80 = ___11_minEdge;
		float L_81 = *((float*)L_80);
		float L_82;
		L_82 = math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline(L_79, L_81, NULL);
		*((float*)L_78) = (float)L_82;
		float* L_83 = ___10_avgEdge;
		float* L_84 = ___10_avgEdge;
		float L_85 = *((float*)L_84);
		float L_86 = V_5;
		*((float*)L_83) = (float)((float)il2cpp_codegen_add(L_85, L_86));
		float* L_87 = ___10_avgEdge;
		float* L_88 = ___10_avgEdge;
		float L_89 = *((float*)L_88);
		float L_90 = V_6;
		*((float*)L_87) = (float)((float)il2cpp_codegen_add(L_89, L_90));
		float* L_91 = ___10_avgEdge;
		float* L_92 = ___10_avgEdge;
		float L_93 = *((float*)L_92);
		float L_94 = V_7;
		*((float*)L_91) = (float)((float)il2cpp_codegen_add(L_93, L_94));
		NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5* L_95 = ___4_triangles;
		int32_t* L_96 = ___5_triangleCount;
		int32_t* L_97 = ___5_triangleCount;
		int32_t L_98 = *((int32_t*)L_97);
		V_8 = L_98;
		int32_t L_99 = V_8;
		*((int32_t*)L_96) = (int32_t)((int32_t)il2cpp_codegen_add(L_99, 1));
		int32_t L_100 = V_8;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_101 = V_1;
		IL2CPP_NATIVEARRAY_SET_ITEM(UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD, (L_95)->___m_Buffer, L_100, (L_101));
		int32_t L_102 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_102, 3));
	}

IL_0173:
	{
		int32_t L_103 = V_0;
		int32_t L_104 = ___3_indexCount;
		if ((((int32_t)L_103) < ((int32_t)L_104)))
		{
			goto IL_0007;
		}
	}
	{
		float* L_105 = ___7_avgArea;
		float* L_106 = ___7_avgArea;
		float L_107 = *((float*)L_106);
		int32_t* L_108 = ___5_triangleCount;
		int32_t L_109 = *((int32_t*)L_108);
		*((float*)L_105) = (float)((float)(L_107/((float)L_109)));
		float* L_110 = ___10_avgEdge;
		float* L_111 = ___10_avgEdge;
		float L_112 = *((float*)L_111);
		int32_t L_113 = ___3_indexCount;
		*((float*)L_110) = (float)((float)(L_112/((float)L_113)));
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_BuildTrianglesAndEdges_m902E978EB29E4C37FCA0B80D66E30B677CADDD31 (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_vertices, int32_t ___1_vertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___2_indices, int32_t ___3_indexCount, NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5* ___4_triangles, int32_t* ___5_triangleCount, NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* ___6_delaEdges, int32_t* ___7_delaEdgeCount, float* ___8_maxArea, float* ___9_avgArea, float* ___10_minArea, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD V_1;
	memset((&V_1), 0, sizeof(V_1));
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	{
		V_0 = 0;
		goto IL_0169;
	}

IL_0007:
	{
		il2cpp_codegen_initobj((&V_1), sizeof(UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD));
		int32_t L_0 = V_0;
		int32_t L_1;
		L_1 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&___2_indices))->___m_Buffer, L_0);
		V_2 = L_1;
		int32_t L_2 = V_0;
		int32_t L_3;
		L_3 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&___2_indices))->___m_Buffer, ((int32_t)il2cpp_codegen_add(L_2, 1)));
		V_3 = L_3;
		int32_t L_4 = V_0;
		int32_t L_5;
		L_5 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, ((&___2_indices))->___m_Buffer, ((int32_t)il2cpp_codegen_add(L_4, 2)));
		V_4 = L_5;
		int32_t L_6 = V_2;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_7;
		L_7 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_vertices))->___m_Buffer, L_6);
		(&V_1)->___va = L_7;
		int32_t L_8 = V_3;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_9;
		L_9 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_vertices))->___m_Buffer, L_8);
		(&V_1)->___vb = L_9;
		int32_t L_10 = V_4;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_11;
		L_11 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_vertices))->___m_Buffer, L_10);
		(&V_1)->___vc = L_11;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_12 = V_1;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		UCircle_t68411F86930A7056CDBAB9E208076A3075D15218 L_13;
		L_13 = ModuleHandle_CircumCircle_m55302C4846463A91AB57830760699DC95BF4AC0B(L_12, NULL);
		(&V_1)->___c = L_13;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_14 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_15 = L_14.___va;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_16 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_17 = L_16.___vb;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_18 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_19 = L_18.___vc;
		float L_20;
		L_20 = ModuleHandle_TriangleArea_m40B327CC9176416944F14D245D0F49DD5CB2CEA0(L_15, L_17, L_19, NULL);
		(&V_1)->___area = L_20;
		float* L_21 = ___8_maxArea;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_22 = V_1;
		float L_23 = L_22.___area;
		float* L_24 = ___8_maxArea;
		float L_25 = *((float*)L_24);
		float L_26;
		L_26 = math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline(L_23, L_25, NULL);
		*((float*)L_21) = (float)L_26;
		float* L_27 = ___10_minArea;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_28 = V_1;
		float L_29 = L_28.___area;
		float* L_30 = ___10_minArea;
		float L_31 = *((float*)L_30);
		float L_32;
		L_32 = math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline(L_29, L_31, NULL);
		*((float*)L_27) = (float)L_32;
		float* L_33 = ___9_avgArea;
		float* L_34 = ___9_avgArea;
		float L_35 = *((float*)L_34);
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_36 = V_1;
		float L_37 = L_36.___area;
		*((float*)L_33) = (float)((float)il2cpp_codegen_add(L_35, L_37));
		int32_t L_38 = V_2;
		int32_t L_39 = V_3;
		int32_t L_40 = V_4;
		int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF L_41;
		memset((&L_41), 0, sizeof(L_41));
		int3__ctor_mE478318DE4CA648614FEF2C1DD438C0455284BF2_inline((&L_41), L_38, L_39, L_40, NULL);
		(&V_1)->___indices = L_41;
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_42 = ___6_delaEdges;
		int32_t* L_43 = ___7_delaEdgeCount;
		int32_t* L_44 = ___7_delaEdgeCount;
		int32_t L_45 = *((int32_t*)L_44);
		V_5 = L_45;
		int32_t L_46 = V_5;
		*((int32_t*)L_43) = (int32_t)((int32_t)il2cpp_codegen_add(L_46, 1));
		int32_t L_47 = V_5;
		int32_t L_48 = V_2;
		int32_t L_49 = V_3;
		int32_t L_50;
		L_50 = math_min_m02D43DF516544C279AF660EA4731449C82991849_inline(L_48, L_49, NULL);
		int32_t L_51 = V_2;
		int32_t L_52 = V_3;
		int32_t L_53;
		L_53 = math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline(L_51, L_52, NULL);
		int32_t* L_54 = ___5_triangleCount;
		int32_t L_55 = *((int32_t*)L_54);
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_56;
		memset((&L_56), 0, sizeof(L_56));
		int4__ctor_m4E8D71A09721E26F7FCCE82EA8AD699062EE6216_inline((&L_56), L_50, L_53, L_55, (-1), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_42)->___m_Buffer, L_47, (L_56));
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_57 = ___6_delaEdges;
		int32_t* L_58 = ___7_delaEdgeCount;
		int32_t* L_59 = ___7_delaEdgeCount;
		int32_t L_60 = *((int32_t*)L_59);
		V_5 = L_60;
		int32_t L_61 = V_5;
		*((int32_t*)L_58) = (int32_t)((int32_t)il2cpp_codegen_add(L_61, 1));
		int32_t L_62 = V_5;
		int32_t L_63 = V_3;
		int32_t L_64 = V_4;
		int32_t L_65;
		L_65 = math_min_m02D43DF516544C279AF660EA4731449C82991849_inline(L_63, L_64, NULL);
		int32_t L_66 = V_3;
		int32_t L_67 = V_4;
		int32_t L_68;
		L_68 = math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline(L_66, L_67, NULL);
		int32_t* L_69 = ___5_triangleCount;
		int32_t L_70 = *((int32_t*)L_69);
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_71;
		memset((&L_71), 0, sizeof(L_71));
		int4__ctor_m4E8D71A09721E26F7FCCE82EA8AD699062EE6216_inline((&L_71), L_65, L_68, L_70, (-1), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_57)->___m_Buffer, L_62, (L_71));
		NativeArray_1_tBCDB44165F65D6BEE48CAD34C04286D158C1A200* L_72 = ___6_delaEdges;
		int32_t* L_73 = ___7_delaEdgeCount;
		int32_t* L_74 = ___7_delaEdgeCount;
		int32_t L_75 = *((int32_t*)L_74);
		V_5 = L_75;
		int32_t L_76 = V_5;
		*((int32_t*)L_73) = (int32_t)((int32_t)il2cpp_codegen_add(L_76, 1));
		int32_t L_77 = V_5;
		int32_t L_78 = V_4;
		int32_t L_79 = V_2;
		int32_t L_80;
		L_80 = math_min_m02D43DF516544C279AF660EA4731449C82991849_inline(L_78, L_79, NULL);
		int32_t L_81 = V_4;
		int32_t L_82 = V_2;
		int32_t L_83;
		L_83 = math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline(L_81, L_82, NULL);
		int32_t* L_84 = ___5_triangleCount;
		int32_t L_85 = *((int32_t*)L_84);
		int4_tBA77D4945786DE82C3A487B33955EA1004996052 L_86;
		memset((&L_86), 0, sizeof(L_86));
		int4__ctor_m4E8D71A09721E26F7FCCE82EA8AD699062EE6216_inline((&L_86), L_80, L_83, L_85, (-1), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int4_tBA77D4945786DE82C3A487B33955EA1004996052, (L_72)->___m_Buffer, L_77, (L_86));
		NativeArray_1_t949918E734BDA97DE9BC71119C34E3CC11B1F8D5* L_87 = ___4_triangles;
		int32_t* L_88 = ___5_triangleCount;
		int32_t* L_89 = ___5_triangleCount;
		int32_t L_90 = *((int32_t*)L_89);
		V_5 = L_90;
		int32_t L_91 = V_5;
		*((int32_t*)L_88) = (int32_t)((int32_t)il2cpp_codegen_add(L_91, 1));
		int32_t L_92 = V_5;
		UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD L_93 = V_1;
		IL2CPP_NATIVEARRAY_SET_ITEM(UTriangle_tCD210F61D627BAB81A1CFFEC7076C3FBB9A6D7CD, (L_87)->___m_Buffer, L_92, (L_93));
		int32_t L_94 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_94, 3));
	}

IL_0169:
	{
		int32_t L_95 = V_0;
		int32_t L_96 = ___3_indexCount;
		if ((((int32_t)L_95) < ((int32_t)L_96)))
		{
			goto IL_0007;
		}
	}
	{
		float* L_97 = ___9_avgArea;
		float* L_98 = ___9_avgArea;
		float L_99 = *((float*)L_98);
		int32_t* L_100 = ___5_triangleCount;
		int32_t L_101 = *((int32_t*)L_100);
		*((float*)L_97) = (float)((float)(L_99/((float)L_101)));
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_CopyGraph_mD198F917465F876C1D09639EED8A2C2600ADF7EB (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_srcPoints, int32_t ___1_srcPointCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___2_dstPoints, int32_t* ___3_dstPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___4_srcEdges, int32_t ___5_srcEdgeCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___6_dstEdges, int32_t* ___7_dstEdgeCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		int32_t* L_0 = ___7_dstEdgeCount;
		int32_t L_1 = ___5_srcEdgeCount;
		*((int32_t*)L_0) = (int32_t)L_1;
		int32_t* L_2 = ___3_dstPointCount;
		int32_t L_3 = ___1_srcPointCount;
		*((int32_t*)L_2) = (int32_t)L_3;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_4 = ___4_srcEdges;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_5 = ___6_dstEdges;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_6 = (*(NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)L_5);
		int32_t L_7 = ___5_srcEdgeCount;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C(L_4, L_6, L_7, ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C_RuntimeMethod_var);
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_8 = ___0_srcPoints;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_9 = ___2_dstPoints;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_10 = (*(NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*)L_9);
		int32_t L_11 = ___1_srcPointCount;
		ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F(L_8, L_10, L_11, ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_CopyGeometry_m41B14E71387642F5CDDA4F2C8C2C173FA9FF5E3C (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___0_srcIndices, int32_t ___1_srcIndexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___2_dstIndices, int32_t* ___3_dstIndexCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___4_srcVertices, int32_t ___5_srcVertexCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___6_dstVertices, int32_t* ___7_dstVertexCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_Copy_TisInt32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_m08EAF9EE4BD7B3611121EEBB1CA1AC40D9C29874_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		int32_t* L_0 = ___3_dstIndexCount;
		int32_t L_1 = ___1_srcIndexCount;
		*((int32_t*)L_0) = (int32_t)L_1;
		int32_t* L_2 = ___7_dstVertexCount;
		int32_t L_3 = ___5_srcVertexCount;
		*((int32_t*)L_2) = (int32_t)L_3;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_4 = ___0_srcIndices;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_5 = ___2_dstIndices;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_6 = (*(NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)L_5);
		int32_t L_7 = ___1_srcIndexCount;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_Copy_TisInt32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_m08EAF9EE4BD7B3611121EEBB1CA1AC40D9C29874(L_4, L_6, L_7, ModuleHandle_Copy_TisInt32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_m08EAF9EE4BD7B3611121EEBB1CA1AC40D9C29874_RuntimeMethod_var);
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_8 = ___4_srcVertices;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_9 = ___6_dstVertices;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_10 = (*(NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*)L_9);
		int32_t L_11 = ___5_srcVertexCount;
		ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F(L_8, L_10, L_11, ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_TransferOutput_mE69BFB90D12C2CA71E368EC00347F5C1DA21BDAD (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___0_srcEdges, int32_t ___1_srcEdgeCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___2_dstEdges, int32_t* ___3_dstEdgeCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C ___4_srcIndices, int32_t ___5_srcIndexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___6_dstIndices, int32_t* ___7_dstIndexCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___8_srcVertices, int32_t ___9_srcVertexCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___10_dstVertices, int32_t* ___11_dstVertexCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_Copy_TisInt32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_m08EAF9EE4BD7B3611121EEBB1CA1AC40D9C29874_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		int32_t* L_0 = ___3_dstEdgeCount;
		int32_t L_1 = ___1_srcEdgeCount;
		*((int32_t*)L_0) = (int32_t)L_1;
		int32_t* L_2 = ___7_dstIndexCount;
		int32_t L_3 = ___5_srcIndexCount;
		*((int32_t*)L_2) = (int32_t)L_3;
		int32_t* L_4 = ___11_dstVertexCount;
		int32_t L_5 = ___9_srcVertexCount;
		*((int32_t*)L_4) = (int32_t)L_5;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_6 = ___0_srcEdges;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_7 = ___2_dstEdges;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_8 = (*(NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)L_7);
		int32_t L_9 = ___1_srcEdgeCount;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C(L_6, L_8, L_9, ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C_RuntimeMethod_var);
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_10 = ___4_srcIndices;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_11 = ___6_dstIndices;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_12 = (*(NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C*)L_11);
		int32_t L_13 = ___5_srcIndexCount;
		ModuleHandle_Copy_TisInt32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_m08EAF9EE4BD7B3611121EEBB1CA1AC40D9C29874(L_10, L_12, L_13, ModuleHandle_Copy_TisInt32_t680FF22E76F6EFAD4375103CBBFFA0421349384C_m08EAF9EE4BD7B3611121EEBB1CA1AC40D9C29874_RuntimeMethod_var);
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_14 = ___8_srcVertices;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_15 = ___10_dstVertices;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_16 = (*(NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*)L_15);
		int32_t L_17 = ___9_srcVertexCount;
		ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F(L_14, L_16, L_17, ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F_RuntimeMethod_var);
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_GraphConditioner_m7C685F797F7096123ABD62F4932FFC0177FDE3CF (NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___0_points, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___1_pgPoints, int32_t* ___2_pgPointCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___3_pgEdges, int32_t* ___4_pgEdgeCount, bool ___5_resetTopology, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_0;
	memset((&V_0), 0, sizeof(V_0));
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_1;
	memset((&V_1), 0, sizeof(V_1));
	float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA V_2;
	memset((&V_2), 0, sizeof(V_2));
	float V_3 = 0.0f;
	int32_t V_4 = 0;
	int32_t V_5 = 0;
	int32_t V_6 = 0;
	int32_t* G_B5_0 = NULL;
	int32_t* G_B4_0 = NULL;
	int32_t G_B6_0 = 0;
	int32_t* G_B6_1 = NULL;
	{
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&V_0), (std::numeric_limits<float>::infinity()), (std::numeric_limits<float>::infinity()), NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ((float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_StaticFields*)il2cpp_codegen_static_fields_for(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_il2cpp_TypeInfo_var))->___zero;
		V_1 = L_0;
		V_5 = 0;
		goto IL_0042;
	}

IL_001c:
	{
		int32_t L_1 = V_5;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2;
		L_2 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_1);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_3 = V_0;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4;
		L_4 = math_min_m68ED612C41E325FA3446050EA04D0AC0CD191558_inline(L_2, L_3, NULL);
		V_0 = L_4;
		int32_t L_5 = V_5;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6;
		L_6 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, ((&___0_points))->___m_Buffer, L_5);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_7 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_8;
		L_8 = math_max_mFD64D6399932C2D91018BA7895C06FD055E1361B_inline(L_6, L_7, NULL);
		V_1 = L_8;
		int32_t L_9 = V_5;
		V_5 = ((int32_t)il2cpp_codegen_add(L_9, 1));
	}

IL_0042:
	{
		int32_t L_10 = V_5;
		int32_t L_11;
		L_11 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___0_points))->___m_Length);
		if ((((int32_t)L_10) < ((int32_t)L_11)))
		{
			goto IL_001c;
		}
	}
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_12 = V_1;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_13 = V_0;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_14;
		L_14 = float2_op_Subtraction_m28172675A65BCFFBC8C9023BE815019E668B8380_inline(L_12, L_13, NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_15;
		L_15 = float2_op_Multiply_m34D03129CE0D7AD665A914DE83CB749585B2455F_inline(L_14, (0.5f), NULL);
		V_2 = L_15;
		V_3 = (9.99999975E-05f);
		int32_t* L_16 = ___2_pgPointCount;
		bool L_17 = ___5_resetTopology;
		if (L_17)
		{
			G_B5_0 = L_16;
			goto IL_006e;
		}
		G_B4_0 = L_16;
	}
	{
		int32_t* L_18 = ___2_pgPointCount;
		int32_t L_19 = *((int32_t*)L_18);
		G_B6_0 = L_19;
		G_B6_1 = G_B4_0;
		goto IL_006f;
	}

IL_006e:
	{
		G_B6_0 = 0;
		G_B6_1 = G_B5_0;
	}

IL_006f:
	{
		*((int32_t*)G_B6_1) = (int32_t)G_B6_0;
		int32_t* L_20 = ___2_pgPointCount;
		int32_t L_21 = *((int32_t*)L_20);
		V_4 = L_21;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_22 = ___1_pgPoints;
		int32_t* L_23 = ___2_pgPointCount;
		int32_t* L_24 = ___2_pgPointCount;
		int32_t L_25 = *((int32_t*)L_24);
		V_6 = L_25;
		int32_t L_26 = V_6;
		*((int32_t*)L_23) = (int32_t)((int32_t)il2cpp_codegen_add(L_26, 1));
		int32_t L_27 = V_6;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_28 = V_0;
		float L_29 = L_28.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_30 = V_0;
		float L_31 = L_30.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_32;
		memset((&L_32), 0, sizeof(L_32));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_32), L_29, L_31, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_22)->___m_Buffer, L_27, (L_32));
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_33 = ___1_pgPoints;
		int32_t* L_34 = ___2_pgPointCount;
		int32_t* L_35 = ___2_pgPointCount;
		int32_t L_36 = *((int32_t*)L_35);
		V_6 = L_36;
		int32_t L_37 = V_6;
		*((int32_t*)L_34) = (int32_t)((int32_t)il2cpp_codegen_add(L_37, 1));
		int32_t L_38 = V_6;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_39 = V_0;
		float L_40 = L_39.___x;
		float L_41 = V_3;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_42 = V_0;
		float L_43 = L_42.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_44 = V_2;
		float L_45 = L_44.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_46;
		memset((&L_46), 0, sizeof(L_46));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_46), ((float)il2cpp_codegen_subtract(L_40, L_41)), ((float)il2cpp_codegen_add(L_43, L_45)), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_33)->___m_Buffer, L_38, (L_46));
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_47 = ___1_pgPoints;
		int32_t* L_48 = ___2_pgPointCount;
		int32_t* L_49 = ___2_pgPointCount;
		int32_t L_50 = *((int32_t*)L_49);
		V_6 = L_50;
		int32_t L_51 = V_6;
		*((int32_t*)L_48) = (int32_t)((int32_t)il2cpp_codegen_add(L_51, 1));
		int32_t L_52 = V_6;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_53 = V_0;
		float L_54 = L_53.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_55 = V_1;
		float L_56 = L_55.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_57;
		memset((&L_57), 0, sizeof(L_57));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_57), L_54, L_56, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_47)->___m_Buffer, L_52, (L_57));
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_58 = ___1_pgPoints;
		int32_t* L_59 = ___2_pgPointCount;
		int32_t* L_60 = ___2_pgPointCount;
		int32_t L_61 = *((int32_t*)L_60);
		V_6 = L_61;
		int32_t L_62 = V_6;
		*((int32_t*)L_59) = (int32_t)((int32_t)il2cpp_codegen_add(L_62, 1));
		int32_t L_63 = V_6;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_64 = V_0;
		float L_65 = L_64.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_66 = V_2;
		float L_67 = L_66.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_68 = V_1;
		float L_69 = L_68.___y;
		float L_70 = V_3;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_71;
		memset((&L_71), 0, sizeof(L_71));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_71), ((float)il2cpp_codegen_add(L_65, L_67)), ((float)il2cpp_codegen_add(L_69, L_70)), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_58)->___m_Buffer, L_63, (L_71));
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_72 = ___1_pgPoints;
		int32_t* L_73 = ___2_pgPointCount;
		int32_t* L_74 = ___2_pgPointCount;
		int32_t L_75 = *((int32_t*)L_74);
		V_6 = L_75;
		int32_t L_76 = V_6;
		*((int32_t*)L_73) = (int32_t)((int32_t)il2cpp_codegen_add(L_76, 1));
		int32_t L_77 = V_6;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_78 = V_1;
		float L_79 = L_78.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_80 = V_1;
		float L_81 = L_80.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_82;
		memset((&L_82), 0, sizeof(L_82));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_82), L_79, L_81, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_72)->___m_Buffer, L_77, (L_82));
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_83 = ___1_pgPoints;
		int32_t* L_84 = ___2_pgPointCount;
		int32_t* L_85 = ___2_pgPointCount;
		int32_t L_86 = *((int32_t*)L_85);
		V_6 = L_86;
		int32_t L_87 = V_6;
		*((int32_t*)L_84) = (int32_t)((int32_t)il2cpp_codegen_add(L_87, 1));
		int32_t L_88 = V_6;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_89 = V_1;
		float L_90 = L_89.___x;
		float L_91 = V_3;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_92 = V_0;
		float L_93 = L_92.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_94 = V_2;
		float L_95 = L_94.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_96;
		memset((&L_96), 0, sizeof(L_96));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_96), ((float)il2cpp_codegen_add(L_90, L_91)), ((float)il2cpp_codegen_add(L_93, L_95)), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_83)->___m_Buffer, L_88, (L_96));
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_97 = ___1_pgPoints;
		int32_t* L_98 = ___2_pgPointCount;
		int32_t* L_99 = ___2_pgPointCount;
		int32_t L_100 = *((int32_t*)L_99);
		V_6 = L_100;
		int32_t L_101 = V_6;
		*((int32_t*)L_98) = (int32_t)((int32_t)il2cpp_codegen_add(L_101, 1));
		int32_t L_102 = V_6;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_103 = V_1;
		float L_104 = L_103.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_105 = V_0;
		float L_106 = L_105.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_107;
		memset((&L_107), 0, sizeof(L_107));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_107), L_104, L_106, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_97)->___m_Buffer, L_102, (L_107));
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_108 = ___1_pgPoints;
		int32_t* L_109 = ___2_pgPointCount;
		int32_t* L_110 = ___2_pgPointCount;
		int32_t L_111 = *((int32_t*)L_110);
		V_6 = L_111;
		int32_t L_112 = V_6;
		*((int32_t*)L_109) = (int32_t)((int32_t)il2cpp_codegen_add(L_112, 1));
		int32_t L_113 = V_6;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_114 = V_0;
		float L_115 = L_114.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_116 = V_2;
		float L_117 = L_116.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_118 = V_0;
		float L_119 = L_118.___y;
		float L_120 = V_3;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_121;
		memset((&L_121), 0, sizeof(L_121));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_121), ((float)il2cpp_codegen_add(L_115, L_117)), ((float)il2cpp_codegen_subtract(L_119, L_120)), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_108)->___m_Buffer, L_113, (L_121));
		int32_t* L_122 = ___4_pgEdgeCount;
		*((int32_t*)L_122) = (int32_t)8;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_123 = ___3_pgEdges;
		int32_t L_124 = V_4;
		int32_t L_125 = V_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_126;
		memset((&L_126), 0, sizeof(L_126));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_126), L_124, ((int32_t)il2cpp_codegen_add(L_125, 1)), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_123)->___m_Buffer, 0, (L_126));
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_127 = ___3_pgEdges;
		int32_t L_128 = V_4;
		int32_t L_129 = V_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_130;
		memset((&L_130), 0, sizeof(L_130));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_130), ((int32_t)il2cpp_codegen_add(L_128, 1)), ((int32_t)il2cpp_codegen_add(L_129, 2)), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_127)->___m_Buffer, 1, (L_130));
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_131 = ___3_pgEdges;
		int32_t L_132 = V_4;
		int32_t L_133 = V_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_134;
		memset((&L_134), 0, sizeof(L_134));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_134), ((int32_t)il2cpp_codegen_add(L_132, 2)), ((int32_t)il2cpp_codegen_add(L_133, 3)), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_131)->___m_Buffer, 2, (L_134));
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_135 = ___3_pgEdges;
		int32_t L_136 = V_4;
		int32_t L_137 = V_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_138;
		memset((&L_138), 0, sizeof(L_138));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_138), ((int32_t)il2cpp_codegen_add(L_136, 3)), ((int32_t)il2cpp_codegen_add(L_137, 4)), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_135)->___m_Buffer, 3, (L_138));
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_139 = ___3_pgEdges;
		int32_t L_140 = V_4;
		int32_t L_141 = V_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_142;
		memset((&L_142), 0, sizeof(L_142));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_142), ((int32_t)il2cpp_codegen_add(L_140, 4)), ((int32_t)il2cpp_codegen_add(L_141, 5)), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_139)->___m_Buffer, 4, (L_142));
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_143 = ___3_pgEdges;
		int32_t L_144 = V_4;
		int32_t L_145 = V_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_146;
		memset((&L_146), 0, sizeof(L_146));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_146), ((int32_t)il2cpp_codegen_add(L_144, 5)), ((int32_t)il2cpp_codegen_add(L_145, 6)), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_143)->___m_Buffer, 5, (L_146));
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_147 = ___3_pgEdges;
		int32_t L_148 = V_4;
		int32_t L_149 = V_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_150;
		memset((&L_150), 0, sizeof(L_150));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_150), ((int32_t)il2cpp_codegen_add(L_148, 6)), ((int32_t)il2cpp_codegen_add(L_149, 7)), NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_147)->___m_Buffer, 6, (L_150));
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_151 = ___3_pgEdges;
		int32_t L_152 = V_4;
		int32_t L_153 = V_4;
		int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A L_154;
		memset((&L_154), 0, sizeof(L_154));
		int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline((&L_154), ((int32_t)il2cpp_codegen_add(L_152, 7)), L_153, NULL);
		IL2CPP_NATIVEARRAY_SET_ITEM(int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A, (L_151)->___m_Buffer, 7, (L_154));
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_Reorder_mC37CEAA08AE5E9B432106F95C633908AE0ABD600 (int32_t ___0_startVertexCount, int32_t ___1_index, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___2_indices, int32_t* ___3_indexCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___4_vertices, int32_t* ___5_vertexCount, const RuntimeMethod* method) 
{
	bool V_0 = false;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	{
		V_0 = (bool)0;
		V_1 = 0;
		goto IL_0018;
	}

IL_0006:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_0 = ___2_indices;
		int32_t L_1 = V_1;
		int32_t L_2;
		L_2 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_0)->___m_Buffer, L_1);
		int32_t L_3 = ___1_index;
		if ((!(((uint32_t)L_2) == ((uint32_t)L_3))))
		{
			goto IL_0014;
		}
	}
	{
		V_0 = (bool)1;
		goto IL_001d;
	}

IL_0014:
	{
		int32_t L_4 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add(L_4, 1));
	}

IL_0018:
	{
		int32_t L_5 = V_1;
		int32_t* L_6 = ___3_indexCount;
		int32_t L_7 = *((int32_t*)L_6);
		if ((((int32_t)L_5) < ((int32_t)L_7)))
		{
			goto IL_0006;
		}
	}

IL_001d:
	{
		bool L_8 = V_0;
		if (L_8)
		{
			goto IL_005b;
		}
	}
	{
		int32_t* L_9 = ___5_vertexCount;
		int32_t* L_10 = ___5_vertexCount;
		int32_t L_11 = *((int32_t*)L_10);
		*((int32_t*)L_9) = (int32_t)((int32_t)il2cpp_codegen_subtract(L_11, 1));
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_12 = ___4_vertices;
		int32_t L_13 = ___1_index;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_14 = ___4_vertices;
		int32_t* L_15 = ___5_vertexCount;
		int32_t L_16 = *((int32_t*)L_15);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_17;
		L_17 = IL2CPP_NATIVEARRAY_GET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_14)->___m_Buffer, L_16);
		IL2CPP_NATIVEARRAY_SET_ITEM(float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA, (L_12)->___m_Buffer, L_13, (L_17));
		V_2 = 0;
		goto IL_0056;
	}

IL_003e:
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_18 = ___2_indices;
		int32_t L_19 = V_2;
		int32_t L_20;
		L_20 = IL2CPP_NATIVEARRAY_GET_ITEM(int32_t, (L_18)->___m_Buffer, L_19);
		int32_t* L_21 = ___5_vertexCount;
		int32_t L_22 = *((int32_t*)L_21);
		if ((!(((uint32_t)L_20) == ((uint32_t)L_22))))
		{
			goto IL_0052;
		}
	}
	{
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_23 = ___2_indices;
		int32_t L_24 = V_2;
		int32_t L_25 = ___1_index;
		IL2CPP_NATIVEARRAY_SET_ITEM(int32_t, (L_23)->___m_Buffer, L_24, (L_25));
	}

IL_0052:
	{
		int32_t L_26 = V_2;
		V_2 = ((int32_t)il2cpp_codegen_add(L_26, 1));
	}

IL_0056:
	{
		int32_t L_27 = V_2;
		int32_t* L_28 = ___3_indexCount;
		int32_t L_29 = *((int32_t*)L_28);
		if ((((int32_t)L_27) < ((int32_t)L_29)))
		{
			goto IL_003e;
		}
	}

IL_005b:
	{
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle_VertexCleanupConditioner_m53303FF76EFACCC24EB5C389780B9533FBD50D5A (int32_t ___0_startVertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___1_indices, int32_t* ___2_indexCount, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___3_vertices, int32_t* ___4_vertexCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		int32_t L_0 = ___0_startVertexCount;
		V_0 = L_0;
		goto IL_0014;
	}

IL_0004:
	{
		int32_t L_1 = ___0_startVertexCount;
		int32_t L_2 = V_0;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_3 = ___1_indices;
		int32_t* L_4 = ___2_indexCount;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_5 = ___3_vertices;
		int32_t* L_6 = ___4_vertexCount;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_Reorder_mC37CEAA08AE5E9B432106F95C633908AE0ABD600(L_1, L_2, L_3, L_4, L_5, L_6, NULL);
		int32_t L_7 = V_0;
		V_0 = ((int32_t)il2cpp_codegen_add(L_7, 1));
	}

IL_0014:
	{
		int32_t L_8 = V_0;
		int32_t* L_9 = ___4_vertexCount;
		int32_t L_10 = *((int32_t*)L_9);
		if ((((int32_t)L_8) < ((int32_t)L_10)))
		{
			goto IL_0004;
		}
	}
	{
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float4_t89D9A294E7A79BD81BFBDD18654508532958555E ModuleHandle_ConvexQuad_m11A1141C87F3A85C30DD2C1891CE0A418B9C33F0 (int32_t ___0_allocator, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___1_points, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___2_edges, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___3_outVertices, int32_t* ___4_outVertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___5_outIndices, int32_t* ___6_outIndexCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___7_outEdges, int32_t* ___8_outEdgeCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&float4_t89D9A294E7A79BD81BFBDD18654508532958555E_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 V_3;
	memset((&V_3), 0, sizeof(V_3));
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E V_4;
	memset((&V_4), 0, sizeof(V_4));
	{
		float4_t89D9A294E7A79BD81BFBDD18654508532958555E L_0 = ((float4_t89D9A294E7A79BD81BFBDD18654508532958555E_StaticFields*)il2cpp_codegen_static_fields_for(float4_t89D9A294E7A79BD81BFBDD18654508532958555E_il2cpp_TypeInfo_var))->___zero;
		V_0 = L_0;
		int32_t* L_1 = ___8_outEdgeCount;
		*((int32_t*)L_1) = (int32_t)0;
		int32_t* L_2 = ___6_outIndexCount;
		*((int32_t*)L_2) = (int32_t)0;
		int32_t* L_3 = ___4_outVertexCount;
		*((int32_t*)L_3) = (int32_t)0;
		int32_t L_4;
		L_4 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___1_points))->___m_Length);
		if ((((int32_t)L_4) < ((int32_t)3)))
		{
			goto IL_002a;
		}
	}
	{
		int32_t L_5;
		L_5 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___1_points))->___m_Length);
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_6 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxVertexCount;
		if ((((int32_t)L_5) < ((int32_t)L_6)))
		{
			goto IL_002c;
		}
	}

IL_002a:
	{
		float4_t89D9A294E7A79BD81BFBDD18654508532958555E L_7 = V_0;
		return L_7;
	}

IL_002c:
	{
		V_1 = 0;
		V_2 = 0;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_8 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxEdgeCount;
		int32_t L_9 = ___0_allocator;
		NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13((&V_3), L_8, L_9, 1, NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		int32_t L_10 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxVertexCount;
		int32_t L_11 = ___0_allocator;
		NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A((&V_4), L_10, L_11, 1, NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var);
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_12 = ___1_points;
		ModuleHandle_GraphConditioner_m7C685F797F7096123ABD62F4932FFC0177FDE3CF(L_12, (&V_4), (&V_2), (&V_3), (&V_1), (bool)1, NULL);
		int32_t L_13 = ___0_allocator;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_14 = V_4;
		int32_t L_15 = V_2;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_16 = V_3;
		int32_t L_17 = V_1;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_18 = ___3_outVertices;
		int32_t* L_19 = ___4_outVertexCount;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_20 = ___5_outIndices;
		int32_t* L_21 = ___6_outIndexCount;
		bool L_22;
		L_22 = Tessellator_Tessellate_m84DB7B38E7EC9AB5155F7EEDBC3382CF1092EC5E(L_13, L_14, L_15, L_16, L_17, L_18, L_19, L_20, L_21, NULL);
		NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F((&V_4), NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var);
		NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2((&V_3), NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		float4_t89D9A294E7A79BD81BFBDD18654508532958555E L_23 = V_0;
		return L_23;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float4_t89D9A294E7A79BD81BFBDD18654508532958555E ModuleHandle_Tessellate_mA1E9CDB4B4F5A347C6A1E3BFDB106B2BC3301EE0 (int32_t ___0_allocator, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___1_points, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___2_edges, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___3_outVertices, int32_t* ___4_outVertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___5_outIndices, int32_t* ___6_outIndexCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___7_outEdges, int32_t* ___8_outEdgeCount, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&float4_t89D9A294E7A79BD81BFBDD18654508532958555E_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E V_0;
	memset((&V_0), 0, sizeof(V_0));
	bool V_1 = false;
	bool V_2 = false;
	int32_t V_3 = 0;
	int32_t V_4 = 0;
	NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 V_5;
	memset((&V_5), 0, sizeof(V_5));
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E V_6;
	memset((&V_6), 0, sizeof(V_6));
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C V_7;
	memset((&V_7), 0, sizeof(V_7));
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E V_8;
	memset((&V_8), 0, sizeof(V_8));
	int32_t V_9 = 0;
	int32_t V_10 = 0;
	{
		float4_t89D9A294E7A79BD81BFBDD18654508532958555E L_0 = ((float4_t89D9A294E7A79BD81BFBDD18654508532958555E_StaticFields*)il2cpp_codegen_static_fields_for(float4_t89D9A294E7A79BD81BFBDD18654508532958555E_il2cpp_TypeInfo_var))->___zero;
		V_0 = L_0;
		int32_t* L_1 = ___8_outEdgeCount;
		*((int32_t*)L_1) = (int32_t)0;
		int32_t* L_2 = ___6_outIndexCount;
		*((int32_t*)L_2) = (int32_t)0;
		int32_t* L_3 = ___4_outVertexCount;
		*((int32_t*)L_3) = (int32_t)0;
		int32_t L_4;
		L_4 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___1_points))->___m_Length);
		if ((((int32_t)L_4) < ((int32_t)3)))
		{
			goto IL_002a;
		}
	}
	{
		int32_t L_5;
		L_5 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___1_points))->___m_Length);
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_6 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxVertexCount;
		if ((((int32_t)L_5) < ((int32_t)L_6)))
		{
			goto IL_002c;
		}
	}

IL_002a:
	{
		float4_t89D9A294E7A79BD81BFBDD18654508532958555E L_7 = V_0;
		return L_7;
	}

IL_002c:
	{
		V_1 = (bool)0;
		V_2 = (bool)0;
		V_3 = 0;
		V_4 = 0;
		int32_t L_8;
		L_8 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___2_edges))->___m_Length);
		int32_t L_9 = ___0_allocator;
		NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13((&V_5), ((int32_t)il2cpp_codegen_multiply(L_8, 8)), L_9, 1, NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		int32_t L_10;
		L_10 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___1_points))->___m_Length);
		int32_t L_11 = ___0_allocator;
		NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A((&V_6), ((int32_t)il2cpp_codegen_multiply(L_10, 4)), L_11, 1, NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var);
		int32_t L_12;
		L_12 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___2_edges))->___m_Length);
		if (!L_12)
		{
			goto IL_0081;
		}
	}
	{
		int32_t L_13 = ___0_allocator;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_14 = ___1_points;
		int32_t L_15;
		L_15 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___1_points))->___m_Length);
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_16 = ___2_edges;
		int32_t L_17;
		L_17 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___2_edges))->___m_Length);
		il2cpp_codegen_runtime_class_init_inline(PlanarGraph_t53936E128A9BC16439B53E0E845693E21A31B761_il2cpp_TypeInfo_var);
		bool L_18;
		L_18 = PlanarGraph_Validate_mD6F5B2173F4C2C298986E926D9C372B88B0ED39D(L_13, L_14, L_15, L_16, L_17, (&V_6), (&V_4), (&V_5), (&V_3), NULL);
		V_1 = L_18;
	}

IL_0081:
	{
		bool L_19 = V_1;
		if (L_19)
		{
			goto IL_00bf;
		}
	}
	{
		int32_t* L_20 = ___8_outEdgeCount;
		int32_t L_21;
		L_21 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___2_edges))->___m_Length);
		*((int32_t*)L_20) = (int32_t)L_21;
		int32_t* L_22 = ___4_outVertexCount;
		int32_t L_23;
		L_23 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___1_points))->___m_Length);
		*((int32_t*)L_22) = (int32_t)L_23;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_24 = ___2_edges;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_25 = ___7_outEdges;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_26 = (*(NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2*)L_25);
		int32_t L_27;
		L_27 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___2_edges))->___m_Length);
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C(L_24, L_26, L_27, ModuleHandle_Copy_Tisint2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A_mBFF6B1AB4AB8B44E22265CE0FC194BEAF466399C_RuntimeMethod_var);
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_28 = ___1_points;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_29 = ___3_outVertices;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_30 = (*(NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E*)L_29);
		int32_t L_31;
		L_31 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___1_points))->___m_Length);
		ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F(L_28, L_30, L_31, ModuleHandle_Copy_Tisfloat2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA_m07543F135AF3627179553F55ED1804459CFCE11F_RuntimeMethod_var);
	}

IL_00bf:
	{
		int32_t L_32 = V_4;
		if ((((int32_t)L_32) <= ((int32_t)2)))
		{
			goto IL_0131;
		}
	}
	{
		int32_t L_33 = V_3;
		if ((((int32_t)L_33) <= ((int32_t)2)))
		{
			goto IL_0131;
		}
	}
	{
		int32_t L_34 = V_4;
		int32_t L_35 = ___0_allocator;
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&V_7), ((int32_t)il2cpp_codegen_multiply(L_34, 8)), L_35, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		int32_t L_36 = V_4;
		int32_t L_37 = ___0_allocator;
		NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A((&V_8), ((int32_t)il2cpp_codegen_multiply(L_36, 4)), L_37, 1, NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var);
		V_9 = 0;
		V_10 = 0;
		int32_t L_38 = ___0_allocator;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_39 = V_6;
		int32_t L_40 = V_4;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_41 = V_5;
		int32_t L_42 = V_3;
		bool L_43;
		L_43 = Tessellator_Tessellate_m84DB7B38E7EC9AB5155F7EEDBC3382CF1092EC5E(L_38, L_39, L_40, L_41, L_42, (&V_8), (&V_10), (&V_7), (&V_9), NULL);
		V_1 = L_43;
		bool L_44 = V_1;
		if (!L_44)
		{
			goto IL_0123;
		}
	}
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_45 = V_5;
		int32_t L_46 = V_3;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_47 = ___7_outEdges;
		int32_t* L_48 = ___8_outEdgeCount;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_49 = V_7;
		int32_t L_50 = V_9;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_51 = ___5_outIndices;
		int32_t* L_52 = ___6_outIndexCount;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_53 = V_8;
		int32_t L_54 = V_10;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_55 = ___3_outVertices;
		int32_t* L_56 = ___4_outVertexCount;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_TransferOutput_mE69BFB90D12C2CA71E368EC00347F5C1DA21BDAD(L_45, L_46, L_47, L_48, L_49, L_50, L_51, L_52, L_53, L_54, L_55, L_56, NULL);
		bool L_57 = V_2;
		if (!L_57)
		{
			goto IL_0123;
		}
	}
	{
		int32_t* L_58 = ___8_outEdgeCount;
		*((int32_t*)L_58) = (int32_t)0;
	}

IL_0123:
	{
		NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F((&V_8), NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E((&V_7), NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
	}

IL_0131:
	{
		NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F((&V_6), NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var);
		NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2((&V_5), NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		float4_t89D9A294E7A79BD81BFBDD18654508532958555E L_59 = V_0;
		return L_59;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR float4_t89D9A294E7A79BD81BFBDD18654508532958555E ModuleHandle_Subdivide_m29840DF7AE9A6487B3B997FF917951EE25A41408 (int32_t ___0_allocator, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E ___1_points, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 ___2_edges, NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* ___3_outVertices, int32_t* ___4_outVertexCount, NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* ___5_outIndices, int32_t* ___6_outIndexCount, NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* ___7_outEdges, int32_t* ___8_outEdgeCount, float ___9_areaFactor, float ___10_targetArea, int32_t ___11_refineIterations, int32_t ___12_smoothenIterations, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&float4_t89D9A294E7A79BD81BFBDD18654508532958555E_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	float4_t89D9A294E7A79BD81BFBDD18654508532958555E V_0;
	memset((&V_0), 0, sizeof(V_0));
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C V_3;
	memset((&V_3), 0, sizeof(V_3));
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E V_4;
	memset((&V_4), 0, sizeof(V_4));
	bool V_5 = false;
	bool V_6 = false;
	bool V_7 = false;
	float V_8 = 0.0f;
	float V_9 = 0.0f;
	int32_t V_10 = 0;
	int32_t V_11 = 0;
	int32_t V_12 = 0;
	int32_t V_13 = 0;
	NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 V_14;
	memset((&V_14), 0, sizeof(V_14));
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E V_15;
	memset((&V_15), 0, sizeof(V_15));
	NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C V_16;
	memset((&V_16), 0, sizeof(V_16));
	NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E V_17;
	memset((&V_17), 0, sizeof(V_17));
	int32_t G_B7_0 = 0;
	{
		float4_t89D9A294E7A79BD81BFBDD18654508532958555E L_0 = ((float4_t89D9A294E7A79BD81BFBDD18654508532958555E_StaticFields*)il2cpp_codegen_static_fields_for(float4_t89D9A294E7A79BD81BFBDD18654508532958555E_il2cpp_TypeInfo_var))->___zero;
		V_0 = L_0;
		int32_t* L_1 = ___8_outEdgeCount;
		*((int32_t*)L_1) = (int32_t)0;
		int32_t* L_2 = ___6_outIndexCount;
		*((int32_t*)L_2) = (int32_t)0;
		int32_t* L_3 = ___4_outVertexCount;
		*((int32_t*)L_3) = (int32_t)0;
		int32_t L_4;
		L_4 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___1_points))->___m_Length);
		if ((((int32_t)L_4) < ((int32_t)3)))
		{
			goto IL_0033;
		}
	}
	{
		int32_t L_5;
		L_5 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___1_points))->___m_Length);
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_6 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxVertexCount;
		if ((((int32_t)L_5) >= ((int32_t)L_6)))
		{
			goto IL_0033;
		}
	}
	{
		int32_t L_7;
		L_7 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___2_edges))->___m_Length);
		if (L_7)
		{
			goto IL_0035;
		}
	}

IL_0033:
	{
		float4_t89D9A294E7A79BD81BFBDD18654508532958555E L_8 = V_0;
		return L_8;
	}

IL_0035:
	{
		V_1 = 0;
		V_2 = 0;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_9 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxIndexCount;
		int32_t L_10 = ___0_allocator;
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&V_3), L_9, L_10, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		int32_t L_11 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxVertexCount;
		int32_t L_12 = ___0_allocator;
		NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A((&V_4), L_11, L_12, 1, NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var);
		int32_t L_13 = ___0_allocator;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_14 = ___1_points;
		int32_t L_15;
		L_15 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___1_points))->___m_Length);
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_16 = ___2_edges;
		int32_t L_17;
		L_17 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___2_edges))->___m_Length);
		bool L_18;
		L_18 = Tessellator_Tessellate_m84DB7B38E7EC9AB5155F7EEDBC3382CF1092EC5E(L_13, L_14, L_15, L_16, L_17, (&V_4), (&V_2), (&V_3), (&V_1), NULL);
		V_5 = L_18;
		V_6 = (bool)0;
		float L_19 = ___10_targetArea;
		if ((!(((float)L_19) == ((float)(0.0f)))))
		{
			goto IL_008f;
		}
	}
	{
		float L_20 = ___9_areaFactor;
		G_B7_0 = ((((int32_t)((((float)L_20) == ((float)(0.0f)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
		goto IL_0090;
	}

IL_008f:
	{
		G_B7_0 = 1;
	}

IL_0090:
	{
		V_7 = (bool)G_B7_0;
		bool L_21 = V_5;
		bool L_22 = V_7;
		if (!((int32_t)((int32_t)L_21&(int32_t)L_22)))
		{
			goto IL_0365;
		}
	}
	{
		V_8 = (0.0f);
		V_9 = (0.0f);
		V_10 = 0;
		V_11 = 0;
		V_12 = 0;
		V_13 = 0;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_23 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxEdgeCount;
		int32_t L_24 = ___0_allocator;
		NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13((&V_14), L_23, L_24, 1, NativeArray_1__ctor_m3CB679B1B77F99FC5CF890F75C914E22555A1F13_RuntimeMethod_var);
		int32_t L_25 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxVertexCount;
		int32_t L_26 = ___0_allocator;
		NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A((&V_15), L_25, L_26, 1, NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var);
		int32_t L_27 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxIndexCount;
		int32_t L_28 = ___0_allocator;
		NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D((&V_16), L_27, L_28, 1, NativeArray_1__ctor_mB7BB23924A114599D399A5EC6C00B2B6407CF66D_RuntimeMethod_var);
		int32_t L_29 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxVertexCount;
		int32_t L_30 = ___0_allocator;
		NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A((&V_17), L_29, L_30, 1, NativeArray_1__ctor_mAF9D0A865FBFFE6364C3073A253711B4C109C67A_RuntimeMethod_var);
		(&V_0)->___x = (0.0f);
		int32_t L_31 = ___11_refineIterations;
		int32_t L_32 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxRefineIterations;
		il2cpp_codegen_runtime_class_init_inline(Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		int32_t L_33;
		L_33 = Math_Min_m53C488772A34D53917BCA2A491E79A0A5356ED52(L_31, L_32, NULL);
		___11_refineIterations = L_33;
		float L_34 = ___10_targetArea;
		if ((((float)L_34) == ((float)(0.0f))))
		{
			goto IL_01ce;
		}
	}
	{
		float L_35 = ___10_targetArea;
		V_9 = ((float)(L_35/(10.0f)));
		goto IL_01b4;
	}

IL_0123:
	{
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_36 = ___1_points;
		int32_t L_37;
		L_37 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___1_points))->___m_Length);
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_38 = ___2_edges;
		int32_t L_39;
		L_39 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___2_edges))->___m_Length);
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_CopyGraph_mD198F917465F876C1D09639EED8A2C2600ADF7EB(L_36, L_37, (&V_15), (&V_11), L_38, L_39, (&V_14), (&V_10), NULL);
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_40 = V_3;
		int32_t L_41 = V_1;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_42 = V_4;
		int32_t L_43 = V_2;
		ModuleHandle_CopyGeometry_m41B14E71387642F5CDDA4F2C8C2C173FA9FF5E3C(L_40, L_41, (&V_16), (&V_12), L_42, L_43, (&V_17), (&V_13), NULL);
		int32_t L_44 = ___0_allocator;
		float L_45 = ___9_areaFactor;
		float L_46 = ___10_targetArea;
		il2cpp_codegen_runtime_class_init_inline(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var);
		bool L_47;
		L_47 = Refinery_Condition_m75ECBF8D82871AEB1D046E61F20DD3700E18D214(L_44, L_45, L_46, (&V_15), (&V_11), (&V_14), (&V_10), (&V_17), (&V_13), (&V_16), (&V_12), (&V_8), NULL);
		V_6 = L_47;
		bool L_48 = V_6;
		if (!L_48)
		{
			goto IL_01a4;
		}
	}
	{
		int32_t L_49 = V_12;
		int32_t L_50 = V_11;
		if ((((int32_t)L_49) <= ((int32_t)L_50)))
		{
			goto IL_01a4;
		}
	}
	{
		float L_51 = ___9_areaFactor;
		(&V_0)->___x = L_51;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_52 = V_14;
		int32_t L_53 = V_10;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_54 = ___7_outEdges;
		int32_t* L_55 = ___8_outEdgeCount;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_56 = V_16;
		int32_t L_57 = V_12;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_58 = ___5_outIndices;
		int32_t* L_59 = ___6_outIndexCount;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_60 = V_17;
		int32_t L_61 = V_13;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_62 = ___3_outVertices;
		int32_t* L_63 = ___4_outVertexCount;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_TransferOutput_mE69BFB90D12C2CA71E368EC00347F5C1DA21BDAD(L_52, L_53, L_54, L_55, L_56, L_57, L_58, L_59, L_60, L_61, L_62, L_63, NULL);
		goto IL_02a7;
	}

IL_01a4:
	{
		V_6 = (bool)0;
		float L_64 = ___10_targetArea;
		float L_65 = V_9;
		___10_targetArea = ((float)il2cpp_codegen_add(L_64, L_65));
		int32_t L_66 = ___11_refineIterations;
		___11_refineIterations = ((int32_t)il2cpp_codegen_subtract(L_66, 1));
	}

IL_01b4:
	{
		float L_67 = ___10_targetArea;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_68 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxArea;
		if ((!(((float)L_67) < ((float)((float)L_68)))))
		{
			goto IL_02a7;
		}
	}
	{
		int32_t L_69 = ___11_refineIterations;
		if ((((int32_t)L_69) > ((int32_t)0)))
		{
			goto IL_0123;
		}
	}
	{
		goto IL_02a7;
	}

IL_01ce:
	{
		float L_70 = ___9_areaFactor;
		if ((((float)L_70) == ((float)(0.0f))))
		{
			goto IL_02a7;
		}
	}
	{
		float L_71 = ___9_areaFactor;
		float L_72;
		L_72 = math_lerp_m58A82DB48BBA11871FFA81583C700875B3A9BC84_inline((0.100000001f), (0.540000021f), ((float)(((float)il2cpp_codegen_subtract(L_71, (0.0500000007f)))/(0.449999988f))), NULL);
		___9_areaFactor = L_72;
		float L_73 = ___9_areaFactor;
		V_9 = ((float)(L_73/(10.0f)));
		goto IL_0296;
	}

IL_0208:
	{
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_74 = ___1_points;
		int32_t L_75;
		L_75 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___1_points))->___m_Length);
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_76 = ___2_edges;
		int32_t L_77;
		L_77 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___2_edges))->___m_Length);
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_CopyGraph_mD198F917465F876C1D09639EED8A2C2600ADF7EB(L_74, L_75, (&V_15), (&V_11), L_76, L_77, (&V_14), (&V_10), NULL);
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_78 = V_3;
		int32_t L_79 = V_1;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_80 = V_4;
		int32_t L_81 = V_2;
		ModuleHandle_CopyGeometry_m41B14E71387642F5CDDA4F2C8C2C173FA9FF5E3C(L_78, L_79, (&V_16), (&V_12), L_80, L_81, (&V_17), (&V_13), NULL);
		int32_t L_82 = ___0_allocator;
		float L_83 = ___9_areaFactor;
		float L_84 = ___10_targetArea;
		il2cpp_codegen_runtime_class_init_inline(Refinery_t7AB9DFA0E0468A03A75D525BE59E9B17FFC270F9_il2cpp_TypeInfo_var);
		bool L_85;
		L_85 = Refinery_Condition_m75ECBF8D82871AEB1D046E61F20DD3700E18D214(L_82, L_83, L_84, (&V_15), (&V_11), (&V_14), (&V_10), (&V_17), (&V_13), (&V_16), (&V_12), (&V_8), NULL);
		V_6 = L_85;
		bool L_86 = V_6;
		if (!L_86)
		{
			goto IL_0286;
		}
	}
	{
		int32_t L_87 = V_12;
		int32_t L_88 = V_11;
		if ((((int32_t)L_87) <= ((int32_t)L_88)))
		{
			goto IL_0286;
		}
	}
	{
		float L_89 = ___9_areaFactor;
		(&V_0)->___x = L_89;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_90 = V_14;
		int32_t L_91 = V_10;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_92 = ___7_outEdges;
		int32_t* L_93 = ___8_outEdgeCount;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_94 = V_16;
		int32_t L_95 = V_12;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_96 = ___5_outIndices;
		int32_t* L_97 = ___6_outIndexCount;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_98 = V_17;
		int32_t L_99 = V_13;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_100 = ___3_outVertices;
		int32_t* L_101 = ___4_outVertexCount;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_TransferOutput_mE69BFB90D12C2CA71E368EC00347F5C1DA21BDAD(L_90, L_91, L_92, L_93, L_94, L_95, L_96, L_97, L_98, L_99, L_100, L_101, NULL);
		goto IL_02a7;
	}

IL_0286:
	{
		V_6 = (bool)0;
		float L_102 = ___9_areaFactor;
		float L_103 = V_9;
		___9_areaFactor = ((float)il2cpp_codegen_add(L_102, L_103));
		int32_t L_104 = ___11_refineIterations;
		___11_refineIterations = ((int32_t)il2cpp_codegen_subtract(L_104, 1));
	}

IL_0296:
	{
		float L_105 = ___9_areaFactor;
		if ((!(((float)L_105) < ((float)(0.800000012f)))))
		{
			goto IL_02a7;
		}
	}
	{
		int32_t L_106 = ___11_refineIterations;
		if ((((int32_t)L_106) > ((int32_t)0)))
		{
			goto IL_0208;
		}
	}

IL_02a7:
	{
		bool L_107 = V_6;
		if (!L_107)
		{
			goto IL_0349;
		}
	}
	{
		float4_t89D9A294E7A79BD81BFBDD18654508532958555E L_108 = V_0;
		float L_109 = L_108.___x;
		if ((((float)L_109) == ((float)(0.0f))))
		{
			goto IL_02c9;
		}
	}
	{
		int32_t L_110 = V_2;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_VertexCleanupConditioner_m53303FF76EFACCC24EB5C389780B9533FBD50D5A(L_110, (&V_16), (&V_12), (&V_17), (&V_13), NULL);
	}

IL_02c9:
	{
		(&V_0)->___y = (0.0f);
		int32_t L_111 = ___12_smoothenIterations;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		int32_t L_112 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxSmoothenIterations;
		int32_t L_113;
		L_113 = math_clamp_m9EABD008C8EAD9D150062ABE724D96FA2121EE1C_inline(L_111, 0, L_112, NULL);
		___12_smoothenIterations = L_113;
		goto IL_032a;
	}

IL_02e6:
	{
		int32_t L_114 = ___0_allocator;
		int32_t L_115 = V_11;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_116 = V_14;
		int32_t L_117 = V_10;
		il2cpp_codegen_runtime_class_init_inline(Smoothen_t66451B46E8AA634F6F80536137F061EC45767822_il2cpp_TypeInfo_var);
		bool L_118;
		L_118 = Smoothen_Condition_m831A479BB846A668D896E06A2737129629F3DFC2(L_114, (&V_15), L_115, L_116, L_117, (&V_17), (&V_13), (&V_16), (&V_12), NULL);
		if (!L_118)
		{
			goto IL_032f;
		}
	}
	{
		int32_t L_119 = ___12_smoothenIterations;
		(&V_0)->___y = ((float)L_119);
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_120 = V_14;
		int32_t L_121 = V_10;
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_122 = ___7_outEdges;
		int32_t* L_123 = ___8_outEdgeCount;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_124 = V_16;
		int32_t L_125 = V_12;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_126 = ___5_outIndices;
		int32_t* L_127 = ___6_outIndexCount;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_128 = V_17;
		int32_t L_129 = V_13;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_130 = ___3_outVertices;
		int32_t* L_131 = ___4_outVertexCount;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_TransferOutput_mE69BFB90D12C2CA71E368EC00347F5C1DA21BDAD(L_120, L_121, L_122, L_123, L_124, L_125, L_126, L_127, L_128, L_129, L_130, L_131, NULL);
		int32_t L_132 = ___12_smoothenIterations;
		___12_smoothenIterations = ((int32_t)il2cpp_codegen_subtract(L_132, 1));
	}

IL_032a:
	{
		int32_t L_133 = ___12_smoothenIterations;
		if ((((int32_t)L_133) > ((int32_t)0)))
		{
			goto IL_02e6;
		}
	}

IL_032f:
	{
		float4_t89D9A294E7A79BD81BFBDD18654508532958555E L_134 = V_0;
		float L_135 = L_134.___y;
		if ((((float)L_135) == ((float)(0.0f))))
		{
			goto IL_0349;
		}
	}
	{
		int32_t L_136 = V_2;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_137 = ___5_outIndices;
		int32_t* L_138 = ___6_outIndexCount;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_139 = ___3_outVertices;
		int32_t* L_140 = ___4_outVertexCount;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_VertexCleanupConditioner_m53303FF76EFACCC24EB5C389780B9533FBD50D5A(L_136, L_137, L_138, L_139, L_140, NULL);
	}

IL_0349:
	{
		NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F((&V_17), NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E((&V_16), NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F((&V_15), NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var);
		NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2((&V_14), NativeArray_1_Dispose_m3135DCFBA5DDC3D2CAA20FB2666F3A996856F2F2_RuntimeMethod_var);
	}

IL_0365:
	{
		bool L_141 = V_5;
		if (!L_141)
		{
			goto IL_038a;
		}
	}
	{
		bool L_142 = V_6;
		if (L_142)
		{
			goto IL_038a;
		}
	}
	{
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2 L_143 = ___2_edges;
		int32_t L_144;
		L_144 = IL2CPP_NATIVEARRAY_GET_LENGTH(((&___2_edges))->___m_Length);
		NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* L_145 = ___7_outEdges;
		int32_t* L_146 = ___8_outEdgeCount;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C L_147 = V_3;
		int32_t L_148 = V_1;
		NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* L_149 = ___5_outIndices;
		int32_t* L_150 = ___6_outIndexCount;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E L_151 = V_4;
		int32_t L_152 = V_2;
		NativeArray_1_t46D43179C2B71BAB34958401E08B5C5DA4488E9E* L_153 = ___3_outVertices;
		int32_t* L_154 = ___4_outVertexCount;
		il2cpp_codegen_runtime_class_init_inline(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		ModuleHandle_TransferOutput_mE69BFB90D12C2CA71E368EC00347F5C1DA21BDAD(L_143, L_144, L_145, L_146, L_147, L_148, L_149, L_150, L_151, L_152, L_153, L_154, NULL);
	}

IL_038a:
	{
		NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F((&V_4), NativeArray_1_Dispose_mAD3B69E4B23316C46AF8C35D7E1E81206323F16F_RuntimeMethod_var);
		NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E((&V_3), NativeArray_1_Dispose_m05C674E687B921C37722A6A1FF938FD56574642E_RuntimeMethod_var);
		float4_t89D9A294E7A79BD81BFBDD18654508532958555E L_155 = V_0;
		return L_155;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void ModuleHandle__cctor_m31191B19D351568AAFC535285B715AA49285D4E4 (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxArea = ((int32_t)65536);
		((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxEdgeCount = ((int32_t)65536);
		((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxIndexCount = ((int32_t)65536);
		((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxVertexCount = ((int32_t)65536);
		int32_t L_0 = ((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxIndexCount;
		((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxTriangleCount = ((int32_t)(L_0/3));
		((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxRefineIterations = ((int32_t)48);
		((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kMaxSmoothenIterations = ((int32_t)256);
		((ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_StaticFields*)il2cpp_codegen_static_fields_for(ModuleHandle_tF45CBC10412074A0AAEF63CBDAA5F92A4F7A9978_il2cpp_TypeInfo_var))->___kIncrementAreaFactor = (1.20000005f);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void __JobReflectionRegistrationOutput__1843744399_CreateJobReflectionData_mB127811C289BF66B9FCFCBA4D17814336677687A (const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IJobExtensions_EarlyJobInit_TisDrawCallJob_t3EA2ABC822AD5DF50675A5B437DAB927DB95215D_m8175192716D38C9C006D2C98D5B36A7CC75E33AD_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IJobForExtensions_EarlyJobInit_TisLightMinMaxZJob_tB4FE0854445DAADF46E5511EAAF54EA1E4B611C4_m6D407EF2FD72EE5C26BA1C843C9932ABCB9C16DA_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IJobForExtensions_EarlyJobInit_TisReflectionProbeMinMaxZJob_tB55272F39D5B8B189F5DF7212CDA3FFF1EC0C71C_mE2595D2099394DF551AC793D9874D90167904DF2_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IJobForExtensions_EarlyJobInit_TisTileRangeExpansionJob_t8342AD91DCB87CA5DBDB463981EE24D47408C876_m7F3455814736950B257AF91E4AE26136F7D2D588_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IJobForExtensions_EarlyJobInit_TisTilingJob_t4506E6F62C95A90210A474DE43C83AF5EB8D3352_m4C05E9D5B6CBBFDCFF690B0C60C83CC47D299593_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IJobForExtensions_EarlyJobInit_TisZBinningJob_t9BC217C31924E66E667568C1B51EA2F44FA0A08E_mA5B015BCBE9BD211FDEFDAE5347DCBE7E91D1970_RuntimeMethod_var);
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&IJobParallelForTransformExtensions_EarlyJobInit_TisUpdateTransformsJob_t7CF957169E8C6560084F48A51BC15A447F3002C7_mA2F79749E27788E6B6B0DA93086B08A0C553480E_RuntimeMethod_var);
		s_Il2CppMethodInitialized = true;
	}
	il2cpp::utils::ExceptionSupportStack<RuntimeObject*, 1> __active_exceptions;
	try
	{
		IJobExtensions_EarlyJobInit_TisDrawCallJob_t3EA2ABC822AD5DF50675A5B437DAB927DB95215D_m8175192716D38C9C006D2C98D5B36A7CC75E33AD(IJobExtensions_EarlyJobInit_TisDrawCallJob_t3EA2ABC822AD5DF50675A5B437DAB927DB95215D_m8175192716D38C9C006D2C98D5B36A7CC75E33AD_RuntimeMethod_var);
		IJobParallelForTransformExtensions_EarlyJobInit_TisUpdateTransformsJob_t7CF957169E8C6560084F48A51BC15A447F3002C7_mA2F79749E27788E6B6B0DA93086B08A0C553480E(IJobParallelForTransformExtensions_EarlyJobInit_TisUpdateTransformsJob_t7CF957169E8C6560084F48A51BC15A447F3002C7_mA2F79749E27788E6B6B0DA93086B08A0C553480E_RuntimeMethod_var);
		IJobForExtensions_EarlyJobInit_TisLightMinMaxZJob_tB4FE0854445DAADF46E5511EAAF54EA1E4B611C4_m6D407EF2FD72EE5C26BA1C843C9932ABCB9C16DA(IJobForExtensions_EarlyJobInit_TisLightMinMaxZJob_tB4FE0854445DAADF46E5511EAAF54EA1E4B611C4_m6D407EF2FD72EE5C26BA1C843C9932ABCB9C16DA_RuntimeMethod_var);
		IJobForExtensions_EarlyJobInit_TisReflectionProbeMinMaxZJob_tB55272F39D5B8B189F5DF7212CDA3FFF1EC0C71C_mE2595D2099394DF551AC793D9874D90167904DF2(IJobForExtensions_EarlyJobInit_TisReflectionProbeMinMaxZJob_tB55272F39D5B8B189F5DF7212CDA3FFF1EC0C71C_mE2595D2099394DF551AC793D9874D90167904DF2_RuntimeMethod_var);
		IJobForExtensions_EarlyJobInit_TisTileRangeExpansionJob_t8342AD91DCB87CA5DBDB463981EE24D47408C876_m7F3455814736950B257AF91E4AE26136F7D2D588(IJobForExtensions_EarlyJobInit_TisTileRangeExpansionJob_t8342AD91DCB87CA5DBDB463981EE24D47408C876_m7F3455814736950B257AF91E4AE26136F7D2D588_RuntimeMethod_var);
		IJobForExtensions_EarlyJobInit_TisTilingJob_t4506E6F62C95A90210A474DE43C83AF5EB8D3352_m4C05E9D5B6CBBFDCFF690B0C60C83CC47D299593(IJobForExtensions_EarlyJobInit_TisTilingJob_t4506E6F62C95A90210A474DE43C83AF5EB8D3352_m4C05E9D5B6CBBFDCFF690B0C60C83CC47D299593_RuntimeMethod_var);
		IJobForExtensions_EarlyJobInit_TisZBinningJob_t9BC217C31924E66E667568C1B51EA2F44FA0A08E_mA5B015BCBE9BD211FDEFDAE5347DCBE7E91D1970(IJobForExtensions_EarlyJobInit_TisZBinningJob_t9BC217C31924E66E667568C1B51EA2F44FA0A08E_mA5B015BCBE9BD211FDEFDAE5347DCBE7E91D1970_RuntimeMethod_var);
		goto IL_0034;
	}
	catch(Il2CppExceptionWrapper& e)
	{
		if(il2cpp_codegen_class_is_assignable_from (((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&Exception_t_il2cpp_TypeInfo_var)), il2cpp_codegen_object_class(e.ex)))
		{
			IL2CPP_PUSH_ACTIVE_EXCEPTION(e.ex);
			goto CATCH_0029;
		}
		throw e;
	}

CATCH_0029:
	{
		il2cpp_codegen_runtime_class_init_inline(((RuntimeClass*)il2cpp_codegen_initialize_runtime_metadata_inline((uintptr_t*)&EarlyInitHelpers_tA67F29CEEF85CD33340F1A46E13686C44F97695A_il2cpp_TypeInfo_var)));
		EarlyInitHelpers_JobReflectionDataCreationFailed_mD6AB08D5BB411CCE38A87793C3C7062EC91FD1EC(((Exception_t*)IL2CPP_GET_ACTIVE_EXCEPTION(Exception_t*)), NULL);
		IL2CPP_POP_ACTIVE_EXCEPTION();
		goto IL_0034;
	}

IL_0034:
	{
		return;
	}
}
IL2CPP_EXTERN_C IL2CPP_METHOD_ATTR void __JobReflectionRegistrationOutput__1843744399_EarlyInit_m03C9448C33EA468FC8AFA9CC9B1D09EE7E9848EE (const RuntimeMethod* method) 
{
	{
		__JobReflectionRegistrationOutput__1843744399_CreateJobReflectionData_mB127811C289BF66B9FCFCBA4D17814336677687A(NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR RenderGraphDefaultResources_t9911A2DC8A2C28E3A1F7F2D48B03AFBCEF1F499B* RenderGraph_get_defaultResources_mAF14CF66D8EEB8E7BE53241437E9D7005C662E17_inline (RenderGraph_t5AA201AC80DFD885B4FFB147432366185AE489BB* __this, const RuntimeMethod* method) 
{
	{
		RenderGraphDefaultResources_t9911A2DC8A2C28E3A1F7F2D48B03AFBCEF1F499B* L_0 = __this->___m_DefaultResources;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 RenderGraphDefaultResources_get_defaultShadowTexture_m4EA8FB8D0893BC33315B9FE9339E1C37DE050F50_inline (RenderGraphDefaultResources_t9911A2DC8A2C28E3A1F7F2D48B03AFBCEF1F499B* __this, const RuntimeMethod* method) 
{
	{
		TextureHandle_t87D7D063E5E22E38632961AB2B6F89978942BE09 L_0 = __this->___U3CdefaultShadowTextureU3Ek__BackingField;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void RenderTextureDescriptor_set_msaaSamples_m6910E09489372746391B14FBAF59A7237539D6C4_inline (RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46* __this, int32_t ___0_value, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = ___0_value;
		__this->___U3CmsaaSamplesU3Ek__BackingField = L_0;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t RenderTextureDescriptor_get_msaaSamples_mFCC33643AFF2265C8305DCFD79ED8774A1A8FA22_inline (RenderTextureDescriptor_t69845881CE6437E4E61F92074F2F84079F23FA46* __this, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = __this->___U3CmsaaSamplesU3Ek__BackingField;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_min_m02D43DF516544C279AF660EA4731449C82991849_inline (int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = ___0_x;
		int32_t L_1 = ___1_y;
		if ((((int32_t)L_0) < ((int32_t)L_1)))
		{
			goto IL_0006;
		}
	}
	{
		int32_t L_2 = ___1_y;
		return L_2;
	}

IL_0006:
	{
		int32_t L_3 = ___0_x;
		return L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline (int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = ___0_x;
		int32_t L_1 = ___1_y;
		if ((((int32_t)L_0) > ((int32_t)L_1)))
		{
			goto IL_0006;
		}
	}
	{
		int32_t L_2 = ___1_y;
		return L_2;
	}

IL_0006:
	{
		int32_t L_3 = ___0_x;
		return L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool math_isinf_m4901864832BAA489A01E23F560733ACEF6E3ED60_inline (double ___0_x, const RuntimeMethod* method) 
{
	{
		double L_0 = ___0_x;
		double L_1;
		L_1 = math_abs_mDF669CF3AF2C60713E8E118578461CDA050DAFD0_inline(L_0, NULL);
		return (bool)((((double)L_1) == ((double)(std::numeric_limits<double>::infinity())))? 1 : 0);
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_abs_mDF669CF3AF2C60713E8E118578461CDA050DAFD0_inline (double ___0_x, const RuntimeMethod* method) 
{
	{
		double L_0 = ___0_x;
		uint64_t L_1;
		L_1 = math_asulong_m2CF160E23B5FF618A85C3C29B2FB1C000E40290F_inline(L_0, NULL);
		double L_2;
		L_2 = math_asdouble_m3E7BC790C743E67EA45476AECD6D2D9A9E62E4F2_inline(((int64_t)((int64_t)L_1&((int64_t)(std::numeric_limits<int64_t>::max)()))), NULL);
		return L_2;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void int2__ctor_m452D21510717D0961119C89A72BBB8D84DCD49F4_inline (int2_tF4AC25F87943DC0B2BB3456B0B919B3B42A9432A* __this, int32_t ___0_x, int32_t ___1_y, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = ___0_x;
		__this->___x = L_0;
		int32_t L_1 = ___1_y;
		__this->___y = L_1;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_distance_m72BEFBAADFC4404FADD3AD81F7EDD40E32624F4D_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_x, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_y, const RuntimeMethod* method) 
{
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_0 = ___1_y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_1 = ___0_x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_2;
		L_2 = double2_op_Subtraction_mDAD1E402F52C548544D20D62D7FA098F4F858BC8_inline(L_0, L_1, NULL);
		double L_3;
		L_3 = math_length_mBC9788A14DDEC3FA5794F7F49EDD1516C5EDE4E3_inline(L_2, NULL);
		return L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA math_min_m1D64D6B67B27FD9738D14BCEE6298146CB05CE00_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_x, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_y, const RuntimeMethod* method) 
{
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_0 = ___0_x;
		double L_1 = L_0.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_2 = ___1_y;
		double L_3 = L_2.___x;
		double L_4;
		L_4 = math_min_m29A6A5FB36524D911D13DDB4866FF005C7BF00D5_inline(L_1, L_3, NULL);
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_5 = ___0_x;
		double L_6 = L_5.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_7 = ___1_y;
		double L_8 = L_7.___y;
		double L_9;
		L_9 = math_min_m29A6A5FB36524D911D13DDB4866FF005C7BF00D5_inline(L_6, L_8, NULL);
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_10;
		memset((&L_10), 0, sizeof(L_10));
		double2__ctor_m4026FE95F69FAEBD29D7092ADAA1CB845A8E859B_inline((&L_10), L_4, L_9, NULL);
		return L_10;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA float2_op_Multiply_m34D03129CE0D7AD665A914DE83CB749585B2455F_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_lhs, float ___1_rhs, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_lhs;
		float L_1 = L_0.___x;
		float L_2 = ___1_rhs;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_3 = ___0_lhs;
		float L_4 = L_3.___y;
		float L_5 = ___1_rhs;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6;
		memset((&L_6), 0, sizeof(L_6));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_6), ((float)il2cpp_codegen_multiply(L_1, L_2)), ((float)il2cpp_codegen_multiply(L_4, L_5)), NULL);
		return L_6;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA double2_op_Implicit_m168C031549D6C086B7C49ECA5B18C892B3112F17_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_v, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_v;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_1;
		memset((&L_1), 0, sizeof(L_1));
		double2__ctor_m3355A4008574AE2483EAD2841176C67734F10F33_inline((&L_1), L_0, NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA* __this, float ___0_x, float ___1_y, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		__this->___x = L_0;
		float L_1 = ___1_y;
		__this->___y = L_1;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA float2_op_Subtraction_m28172675A65BCFFBC8C9023BE815019E668B8380_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_lhs, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_rhs, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_lhs;
		float L_1 = L_0.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = ___1_rhs;
		float L_3 = L_2.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = ___0_lhs;
		float L_5 = L_4.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6 = ___1_rhs;
		float L_7 = L_6.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_8;
		memset((&L_8), 0, sizeof(L_8));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_8), ((float)il2cpp_codegen_subtract(L_1, L_3)), ((float)il2cpp_codegen_subtract(L_5, L_7)), NULL);
		return L_8;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool math_any_mCBBE4E2611B227A8AE1A4DA7F104D779203539F9_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_x, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_x;
		float L_1 = L_0.___x;
		if ((!(((float)L_1) == ((float)(0.0f)))))
		{
			goto IL_001e;
		}
	}
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = ___0_x;
		float L_3 = L_2.___y;
		return (bool)((((int32_t)((((float)L_3) == ((float)(0.0f)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}

IL_001e:
	{
		return (bool)1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA float2_op_Addition_m718974663A956F64D7C45D06C088550637F13693_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_lhs, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_rhs, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_lhs;
		float L_1 = L_0.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = ___1_rhs;
		float L_3 = L_2.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = ___0_lhs;
		float L_5 = L_4.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6 = ___1_rhs;
		float L_7 = L_6.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_8;
		memset((&L_8), 0, sizeof(L_8));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_8), ((float)il2cpp_codegen_add(L_1, L_3)), ((float)il2cpp_codegen_add(L_5, L_7)), NULL);
		return L_8;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_length_m3DB47D254C8544FBB740A892B4AE2143E8F45634_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_x, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_1 = ___0_x;
		float L_2;
		L_2 = math_dot_mF673D3E5B7D267C0A8569B678D05BDCCB667D04D_inline(L_0, L_1, NULL);
		float L_3;
		L_3 = math_sqrt_mEF31DE7BD0179009683C5D7B0C58E6571B30CF4A_inline(L_2, NULL);
		return L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_abs_mFF027629978A9039B059528ED3075D775AA0B0AB_inline (int32_t ___0_x, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = ___0_x;
		int32_t L_1 = ___0_x;
		int32_t L_2;
		L_2 = math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline(((-L_0)), L_1, NULL);
		return L_2;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_clamp_mB7233FC9D6C27522014C4E6D4E056D36CE82C97E_inline (float ___0_x, float ___1_a, float ___2_b, const RuntimeMethod* method) 
{
	{
		float L_0 = ___1_a;
		float L_1 = ___2_b;
		float L_2 = ___0_x;
		float L_3;
		L_3 = math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline(L_1, L_2, NULL);
		float L_4;
		L_4 = math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline(L_0, L_3, NULL);
		return L_4;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline (float ___0_x, float ___1_y, const RuntimeMethod* method) 
{
	{
		float L_0 = ___1_y;
		bool L_1;
		L_1 = Single_IsNaN_mFE637F6ECA9F7697CE8EFF56427858F4C5EDF75D_inline(L_0, NULL);
		if (L_1)
		{
			goto IL_000e;
		}
	}
	{
		float L_2 = ___0_x;
		float L_3 = ___1_y;
		if ((((float)L_2) > ((float)L_3)))
		{
			goto IL_000e;
		}
	}
	{
		float L_4 = ___1_y;
		return L_4;
	}

IL_000e:
	{
		float L_5 = ___0_x;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void int4__ctor_m4E8D71A09721E26F7FCCE82EA8AD699062EE6216_inline (int4_tBA77D4945786DE82C3A487B33955EA1004996052* __this, int32_t ___0_x, int32_t ___1_y, int32_t ___2_z, int32_t ___3_w, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = ___0_x;
		__this->___x = L_0;
		int32_t L_1 = ___1_y;
		__this->___y = L_1;
		int32_t L_2 = ___2_z;
		__this->___z = L_2;
		int32_t L_3 = ___3_w;
		__this->___w = L_3;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA float2_op_Division_m4AA175CD0895AA1A50F5A73B54722CA53876EE6A_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_lhs, float ___1_rhs, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_lhs;
		float L_1 = L_0.___x;
		float L_2 = ___1_rhs;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_3 = ___0_lhs;
		float L_4 = L_3.___y;
		float L_5 = ___1_rhs;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6;
		memset((&L_6), 0, sizeof(L_6));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_6), ((float)(L_1/L_2)), ((float)(L_4/L_5)), NULL);
		return L_6;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_distance_mE5E0FFDD103E710A4CB23360BFCAFD0AF2E1EFA9_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_x, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_y, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___1_y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_1 = ___0_x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2;
		L_2 = float2_op_Subtraction_m28172675A65BCFFBC8C9023BE815019E668B8380_inline(L_0, L_1, NULL);
		float L_3;
		L_3 = math_length_m3DB47D254C8544FBB740A892B4AE2143E8F45634_inline(L_2, NULL);
		return L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void Tessellator_SetAllocator_mC4F00FD3CD85AA582F89050F805A50236365B47A_inline (Tessellator_t8396AA2EF6C14EE2D2AD66CE79A754209E168239* __this, int32_t ___0_allocator, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = ___0_allocator;
		__this->___m_Allocator = L_0;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_abs_m3D9508B36B045BFE7B89C6C69AD34596264E4FE1_inline (float ___0_x, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		uint32_t L_1;
		L_1 = math_asuint_m503D1ABF19E4BA615FD8AE1BF1A2E103BBED6139_inline(L_0, NULL);
		float L_2;
		L_2 = math_asfloat_m20D259DAAB46464B59BD8BF5678F9D59800F70A9_inline(((int32_t)((int32_t)L_1&((int32_t)2147483647LL))), NULL);
		return L_2;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_pow_m2B2C611A37952CFB13BB0AE800A6A601A2E4A49B_inline (float ___0_x, float ___1_y, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		float L_0 = ___0_x;
		float L_1 = ___1_y;
		il2cpp_codegen_runtime_class_init_inline(Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		double L_2;
		L_2 = Math_Pow_mEAE651F0858203FBE12B72B6A53951BBD0FB5265(((double)((float)L_0)), ((double)((float)L_1)), NULL);
		return ((float)L_2);
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_sqrt_mEF31DE7BD0179009683C5D7B0C58E6571B30CF4A_inline (float ___0_x, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		float L_0 = ___0_x;
		il2cpp_codegen_runtime_class_init_inline(Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		double L_1;
		L_1 = sqrt(((double)((float)L_0)));
		return ((float)L_1);
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void float3__ctor_mC61002CD0EC13D7C37D846D021A78C028FB80DB9_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E* __this, float ___0_x, float ___1_y, float ___2_z, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		__this->___x = L_0;
		float L_1 = ___1_y;
		__this->___y = L_1;
		float L_2 = ___2_z;
		__this->___z = L_2;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E float3_op_Subtraction_mB6036E9849D95650D6E73DA0D179CD7B61E696F2_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_lhs, float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___1_rhs, const RuntimeMethod* method) 
{
	{
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_0 = ___0_lhs;
		float L_1 = L_0.___x;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_2 = ___1_rhs;
		float L_3 = L_2.___x;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_4 = ___0_lhs;
		float L_5 = L_4.___y;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_6 = ___1_rhs;
		float L_7 = L_6.___y;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_8 = ___0_lhs;
		float L_9 = L_8.___z;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_10 = ___1_rhs;
		float L_11 = L_10.___z;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_12;
		memset((&L_12), 0, sizeof(L_12));
		float3__ctor_mC61002CD0EC13D7C37D846D021A78C028FB80DB9_inline((&L_12), ((float)il2cpp_codegen_subtract(L_1, L_3)), ((float)il2cpp_codegen_subtract(L_5, L_7)), ((float)il2cpp_codegen_subtract(L_9, L_11)), NULL);
		return L_12;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E math_cross_m4CA2DAE150C6381B0D05E8AA9E48E88CF6157180_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_x, float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___1_y, const RuntimeMethod* method) 
{
	float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_0 = ___0_x;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_1;
		L_1 = float3_get_yzx_mDF6DE39B69C5DE384F74C0D1EC91AA0388E23535_inline((&___1_y), NULL);
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_2;
		L_2 = float3_op_Multiply_m05E57074FBD5FAB0E72940C9CC019C41915280D7_inline(L_0, L_1, NULL);
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_3;
		L_3 = float3_get_yzx_mDF6DE39B69C5DE384F74C0D1EC91AA0388E23535_inline((&___0_x), NULL);
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_4 = ___1_y;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_5;
		L_5 = float3_op_Multiply_m05E57074FBD5FAB0E72940C9CC019C41915280D7_inline(L_3, L_4, NULL);
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_6;
		L_6 = float3_op_Subtraction_mB6036E9849D95650D6E73DA0D179CD7B61E696F2_inline(L_2, L_5, NULL);
		V_0 = L_6;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_7;
		L_7 = float3_get_yzx_mDF6DE39B69C5DE384F74C0D1EC91AA0388E23535_inline((&V_0), NULL);
		return L_7;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_dot_mF673D3E5B7D267C0A8569B678D05BDCCB667D04D_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_x, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_y, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_x;
		float L_1 = L_0.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = ___1_y;
		float L_3 = L_2.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_4 = ___0_x;
		float L_5 = L_4.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_6 = ___1_y;
		float L_7 = L_6.___y;
		return ((float)il2cpp_codegen_add(((float)il2cpp_codegen_multiply(L_1, L_3)), ((float)il2cpp_codegen_multiply(L_5, L_7))));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline (float ___0_x, float ___1_y, const RuntimeMethod* method) 
{
	{
		float L_0 = ___1_y;
		bool L_1;
		L_1 = Single_IsNaN_mFE637F6ECA9F7697CE8EFF56427858F4C5EDF75D_inline(L_0, NULL);
		if (L_1)
		{
			goto IL_000e;
		}
	}
	{
		float L_2 = ___0_x;
		float L_3 = ___1_y;
		if ((((float)L_2) < ((float)L_3)))
		{
			goto IL_000e;
		}
	}
	{
		float L_4 = ___1_y;
		return L_4;
	}

IL_000e:
	{
		float L_5 = ___0_x;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void int3__ctor_mE478318DE4CA648614FEF2C1DD438C0455284BF2_inline (int3_t1D01D28AA6D32890A228297EBADD9BB1A960E2BF* __this, int32_t ___0_x, int32_t ___1_y, int32_t ___2_z, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = ___0_x;
		__this->___x = L_0;
		int32_t L_1 = ___1_y;
		__this->___y = L_1;
		int32_t L_2 = ___2_z;
		__this->___z = L_2;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA math_min_m68ED612C41E325FA3446050EA04D0AC0CD191558_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_x, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_y, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_x;
		float L_1 = L_0.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = ___1_y;
		float L_3 = L_2.___x;
		float L_4;
		L_4 = math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline(L_1, L_3, NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_5 = ___0_x;
		float L_6 = L_5.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_7 = ___1_y;
		float L_8 = L_7.___y;
		float L_9;
		L_9 = math_min_m54FD010BEF505D2BA1F79FC793BEB0723C329C3B_inline(L_6, L_8, NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_10;
		memset((&L_10), 0, sizeof(L_10));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_10), L_4, L_9, NULL);
		return L_10;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA math_max_mFD64D6399932C2D91018BA7895C06FD055E1361B_inline (float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_x, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___1_y, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_x;
		float L_1 = L_0.___x;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = ___1_y;
		float L_3 = L_2.___x;
		float L_4;
		L_4 = math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline(L_1, L_3, NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_5 = ___0_x;
		float L_6 = L_5.___y;
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_7 = ___1_y;
		float L_8 = L_7.___y;
		float L_9;
		L_9 = math_max_m4B454A91AE8827997609E74C4C24036BBD3CC496_inline(L_6, L_8, NULL);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_10;
		memset((&L_10), 0, sizeof(L_10));
		float2__ctor_m3D598E2C2D173DE852F3AB157502968261383C97_inline((&L_10), L_4, L_9, NULL);
		return L_10;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_lerp_m58A82DB48BBA11871FFA81583C700875B3A9BC84_inline (float ___0_x, float ___1_y, float ___2_s, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		float L_1 = ___2_s;
		float L_2 = ___1_y;
		float L_3 = ___0_x;
		return ((float)il2cpp_codegen_add(L_0, ((float)il2cpp_codegen_multiply(L_1, ((float)il2cpp_codegen_subtract(L_2, L_3))))));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_clamp_m9EABD008C8EAD9D150062ABE724D96FA2121EE1C_inline (int32_t ___0_x, int32_t ___1_a, int32_t ___2_b, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = ___1_a;
		int32_t L_1 = ___2_b;
		int32_t L_2 = ___0_x;
		int32_t L_3;
		L_3 = math_min_m02D43DF516544C279AF660EA4731449C82991849_inline(L_1, L_2, NULL);
		int32_t L_4;
		L_4 = math_max_m9083201D37A8ED0157B127B5878D9B7F3A2A40BE_inline(L_0, L_3, NULL);
		return L_4;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t ArraySlice_1_get_Length_m814A8881AF759049A308E6E04BE0451BFDA0076B_gshared_inline (ArraySlice_1_t38E85DAE9975597DC96B21D715F42183A9C5EF03* __this, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = __this->___m_Length;
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool NativeArray_1_get_IsCreated_m5BE85069615B49772C9DB202004FA2FD36F418F2_gshared_inline (NativeArray_1_tE86585F07CF10FCD01AA2652A104B149336F7EC2* __this, const RuntimeMethod* method) 
{
	{
		void* L_0 = __this->___m_Buffer;
		return (bool)((((int32_t)((((intptr_t)L_0) == ((intptr_t)((uintptr_t)0)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool NativeArray_1_get_IsCreated_mB43459BFDEF78038051D817E8A57FF1DF3C3D738_gshared_inline (NativeArray_1_t5CA30CFE8068A8BF6AAC417D6C911DA3620A8099* __this, const RuntimeMethod* method) 
{
	{
		void* L_0 = __this->___m_Buffer;
		return (bool)((((int32_t)((((intptr_t)L_0) == ((intptr_t)((uintptr_t)0)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool NativeArray_1_get_IsCreated_m547C5D2E203906703FFE7232167A21D2A03D54C0_gshared_inline (NativeArray_1_tA833EB7E3E1C9AF82C37976AD964B8D4BAC38B2C* __this, const RuntimeMethod* method) 
{
	{
		void* L_0 = __this->___m_Buffer;
		return (bool)((((int32_t)((((intptr_t)L_0) == ((intptr_t)((uintptr_t)0)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool NativeArray_1_get_IsCreated_m448EBF5E1AF8055E179079DE8883B7F449125BAB_gshared_inline (NativeArray_1_tA39D7DB71ADA458A72B67FD0C6E1FF021412BA57* __this, const RuntimeMethod* method) 
{
	{
		void* L_0 = __this->___m_Buffer;
		return (bool)((((int32_t)((((intptr_t)L_0) == ((intptr_t)((uintptr_t)0)))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint64_t math_asulong_m2CF160E23B5FF618A85C3C29B2FB1C000E40290F_inline (double ___0_x, const RuntimeMethod* method) 
{
	{
		double L_0 = ___0_x;
		int64_t L_1;
		L_1 = math_aslong_mCD3846AC0EFB4901B00A20D0960C80C8CBE66366_inline(L_0, NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_asdouble_m3E7BC790C743E67EA45476AECD6D2D9A9E62E4F2_inline (uint64_t ___0_x, const RuntimeMethod* method) 
{
	{
		uint64_t L_0 = ___0_x;
		double L_1;
		L_1 = math_asdouble_m4C4CC1B9299FE33530ED375768D67B00676C31C8_inline(L_0, NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA double2_op_Subtraction_mDAD1E402F52C548544D20D62D7FA098F4F858BC8_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_lhs, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_rhs, const RuntimeMethod* method) 
{
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_0 = ___0_lhs;
		double L_1 = L_0.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_2 = ___1_rhs;
		double L_3 = L_2.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_4 = ___0_lhs;
		double L_5 = L_4.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_6 = ___1_rhs;
		double L_7 = L_6.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_8;
		memset((&L_8), 0, sizeof(L_8));
		double2__ctor_m4026FE95F69FAEBD29D7092ADAA1CB845A8E859B_inline((&L_8), ((double)il2cpp_codegen_subtract(L_1, L_3)), ((double)il2cpp_codegen_subtract(L_5, L_7)), NULL);
		return L_8;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_length_mBC9788A14DDEC3FA5794F7F49EDD1516C5EDE4E3_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_x, const RuntimeMethod* method) 
{
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_0 = ___0_x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_1 = ___0_x;
		double L_2;
		L_2 = math_dot_mA992F4ADC67180A7EB3850222857193CD0F6B21E_inline(L_0, L_1, NULL);
		double L_3;
		L_3 = math_sqrt_mA3A9D5DFDF6841F8836E3ECD5D83555842383F36_inline(L_2, NULL);
		return L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_min_m29A6A5FB36524D911D13DDB4866FF005C7BF00D5_inline (double ___0_x, double ___1_y, const RuntimeMethod* method) 
{
	{
		double L_0 = ___1_y;
		bool L_1;
		L_1 = Double_IsNaN_mF2BC6D1FD4813179B2CAE58D29770E42830D0883_inline(L_0, NULL);
		if (L_1)
		{
			goto IL_000e;
		}
	}
	{
		double L_2 = ___0_x;
		double L_3 = ___1_y;
		if ((((double)L_2) < ((double)L_3)))
		{
			goto IL_000e;
		}
	}
	{
		double L_4 = ___1_y;
		return L_4;
	}

IL_000e:
	{
		double L_5 = ___0_x;
		return L_5;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void double2__ctor_m4026FE95F69FAEBD29D7092ADAA1CB845A8E859B_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA* __this, double ___0_x, double ___1_y, const RuntimeMethod* method) 
{
	{
		double L_0 = ___0_x;
		__this->___x = L_0;
		double L_1 = ___1_y;
		__this->___y = L_1;
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR void double2__ctor_m3355A4008574AE2483EAD2841176C67734F10F33_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA* __this, float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA ___0_v, const RuntimeMethod* method) 
{
	{
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_0 = ___0_v;
		float L_1 = L_0.___x;
		__this->___x = ((double)L_1);
		float2_t24AA5C0F612B0672315EDAFEC9D9E7F1C4A5B0BA L_2 = ___0_v;
		float L_3 = L_2.___y;
		__this->___y = ((double)L_3);
		return;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Single_IsNaN_mFE637F6ECA9F7697CE8EFF56427858F4C5EDF75D_inline (float ___0_f, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_f;
		int32_t L_1;
		L_1 = BitConverter_SingleToInt32Bits_mC760C7CFC89725E3CF68DC45BE3A9A42A7E7DA73_inline(L_0, NULL);
		return (bool)((((int32_t)((int32_t)(L_1&((int32_t)2147483647LL)))) > ((int32_t)((int32_t)2139095040)))? 1 : 0);
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR uint32_t math_asuint_m503D1ABF19E4BA615FD8AE1BF1A2E103BBED6139_inline (float ___0_x, const RuntimeMethod* method) 
{
	{
		float L_0 = ___0_x;
		int32_t L_1;
		L_1 = math_asint_mBDED7FE966CA65F6A8ACEAEF8FD779B1B8998288_inline(L_0, NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_asfloat_m20D259DAAB46464B59BD8BF5678F9D59800F70A9_inline (uint32_t ___0_x, const RuntimeMethod* method) 
{
	{
		uint32_t L_0 = ___0_x;
		float L_1;
		L_1 = math_asfloat_m9FA56DE5C61FCEF3DCD0675252D40DFD9C9B712F_inline(L_0, NULL);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E float3_get_yzx_mDF6DE39B69C5DE384F74C0D1EC91AA0388E23535_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E* __this, const RuntimeMethod* method) 
{
	{
		float L_0 = __this->___y;
		float L_1 = __this->___z;
		float L_2 = __this->___x;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_3;
		memset((&L_3), 0, sizeof(L_3));
		float3__ctor_mC61002CD0EC13D7C37D846D021A78C028FB80DB9_inline((&L_3), L_0, L_1, L_2, NULL);
		return L_3;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E float3_op_Multiply_m05E57074FBD5FAB0E72940C9CC019C41915280D7_inline (float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___0_lhs, float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E ___1_rhs, const RuntimeMethod* method) 
{
	{
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_0 = ___0_lhs;
		float L_1 = L_0.___x;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_2 = ___1_rhs;
		float L_3 = L_2.___x;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_4 = ___0_lhs;
		float L_5 = L_4.___y;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_6 = ___1_rhs;
		float L_7 = L_6.___y;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_8 = ___0_lhs;
		float L_9 = L_8.___z;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_10 = ___1_rhs;
		float L_11 = L_10.___z;
		float3_t4AB5D88249ADB24F69FFD0793E8ED25E1CC3745E L_12;
		memset((&L_12), 0, sizeof(L_12));
		float3__ctor_mC61002CD0EC13D7C37D846D021A78C028FB80DB9_inline((&L_12), ((float)il2cpp_codegen_multiply(L_1, L_3)), ((float)il2cpp_codegen_multiply(L_5, L_7)), ((float)il2cpp_codegen_multiply(L_9, L_11)), NULL);
		return L_12;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int64_t math_aslong_mCD3846AC0EFB4901B00A20D0960C80C8CBE66366_inline (double ___0_x, const RuntimeMethod* method) 
{
	LongDoubleUnion_tD71C400B6C4CD1A7F13CE8125AC6BBC7A22791CA V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		(&V_0)->___longValue = ((int64_t)0);
		double L_0 = ___0_x;
		(&V_0)->___doubleValue = L_0;
		LongDoubleUnion_tD71C400B6C4CD1A7F13CE8125AC6BBC7A22791CA L_1 = V_0;
		int64_t L_2 = L_1.___longValue;
		return L_2;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_asdouble_m4C4CC1B9299FE33530ED375768D67B00676C31C8_inline (int64_t ___0_x, const RuntimeMethod* method) 
{
	LongDoubleUnion_tD71C400B6C4CD1A7F13CE8125AC6BBC7A22791CA V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		(&V_0)->___doubleValue = (0.0);
		int64_t L_0 = ___0_x;
		(&V_0)->___longValue = L_0;
		LongDoubleUnion_tD71C400B6C4CD1A7F13CE8125AC6BBC7A22791CA L_1 = V_0;
		double L_2 = L_1.___doubleValue;
		return L_2;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_dot_mA992F4ADC67180A7EB3850222857193CD0F6B21E_inline (double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___0_x, double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA ___1_y, const RuntimeMethod* method) 
{
	{
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_0 = ___0_x;
		double L_1 = L_0.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_2 = ___1_y;
		double L_3 = L_2.___x;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_4 = ___0_x;
		double L_5 = L_4.___y;
		double2_t0A9854C934D0BBE9DD41F2B318B64F830D7253FA L_6 = ___1_y;
		double L_7 = L_6.___y;
		return ((double)il2cpp_codegen_add(((double)il2cpp_codegen_multiply(L_1, L_3)), ((double)il2cpp_codegen_multiply(L_5, L_7))));
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR double math_sqrt_mA3A9D5DFDF6841F8836E3ECD5D83555842383F36_inline (double ___0_x, const RuntimeMethod* method) 
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_runtime_metadata((uintptr_t*)&Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		s_Il2CppMethodInitialized = true;
	}
	{
		double L_0 = ___0_x;
		il2cpp_codegen_runtime_class_init_inline(Math_tEB65DE7CA8B083C412C969C92981C030865486CE_il2cpp_TypeInfo_var);
		double L_1;
		L_1 = sqrt(L_0);
		return L_1;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR bool Double_IsNaN_mF2BC6D1FD4813179B2CAE58D29770E42830D0883_inline (double ___0_d, const RuntimeMethod* method) 
{
	{
		double L_0 = ___0_d;
		int64_t L_1;
		L_1 = BitConverter_DoubleToInt64Bits_m4F42741818550F9956B5FBAF88C051F4DE5B0AE6_inline(L_0, NULL);
		return (bool)((((int64_t)((int64_t)(L_1&((int64_t)(std::numeric_limits<int64_t>::max)())))) > ((int64_t)((int64_t)9218868437227405312LL)))? 1 : 0);
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t BitConverter_SingleToInt32Bits_mC760C7CFC89725E3CF68DC45BE3A9A42A7E7DA73_inline (float ___0_value, const RuntimeMethod* method) 
{
	{
		int32_t L_0 = *((int32_t*)((uintptr_t)(&___0_value)));
		return L_0;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int32_t math_asint_mBDED7FE966CA65F6A8ACEAEF8FD779B1B8998288_inline (float ___0_x, const RuntimeMethod* method) 
{
	IntFloatUnion_t549256A9DD754252DD18383D9CE7EA55EBBD6D96 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		(&V_0)->___intValue = 0;
		float L_0 = ___0_x;
		(&V_0)->___floatValue = L_0;
		IntFloatUnion_t549256A9DD754252DD18383D9CE7EA55EBBD6D96 L_1 = V_0;
		int32_t L_2 = L_1.___intValue;
		return L_2;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR float math_asfloat_m9FA56DE5C61FCEF3DCD0675252D40DFD9C9B712F_inline (int32_t ___0_x, const RuntimeMethod* method) 
{
	IntFloatUnion_t549256A9DD754252DD18383D9CE7EA55EBBD6D96 V_0;
	memset((&V_0), 0, sizeof(V_0));
	{
		(&V_0)->___floatValue = (0.0f);
		int32_t L_0 = ___0_x;
		(&V_0)->___intValue = L_0;
		IntFloatUnion_t549256A9DD754252DD18383D9CE7EA55EBBD6D96 L_1 = V_0;
		float L_2 = L_1.___floatValue;
		return L_2;
	}
}
IL2CPP_MANAGED_FORCE_INLINE IL2CPP_METHOD_ATTR int64_t BitConverter_DoubleToInt64Bits_m4F42741818550F9956B5FBAF88C051F4DE5B0AE6_inline (double ___0_value, const RuntimeMethod* method) 
{
	{
		int64_t L_0 = *((int64_t*)((uintptr_t)(&___0_value)));
		return L_0;
	}
}
