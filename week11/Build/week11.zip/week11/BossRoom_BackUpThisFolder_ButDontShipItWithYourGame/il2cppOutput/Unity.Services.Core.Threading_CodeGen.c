﻿#include "pch-c.h"
#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include "codegen/il2cpp-codegen-metadata.h"





extern void UnityThreadUtilsInternal_PostAsync_m324667C9E5B9E25D01ED8F00E68330130F3B435A (void);
extern void UnityThreadUtilsInternal_PostAsync_mC858E8A5C829E4053E13566318F03866AA7A171F (void);
extern void UnityThreadUtilsInternal_Send_m91B4D5F642779F7886B18FDBB6ACAAB3CAE65DB6 (void);
extern void UnityThreadUtilsInternal_Send_m701390E8B2BC62F04BFC284B5A6A60C3CA8278E9 (void);
extern void UnityThreadUtilsInternal_Unity_Services_Core_Threading_Internal_IUnityThreadUtils_get_IsRunningOnUnityThread_m264DB20EE6404E1C396E078FADE78F0C91CC7E1A (void);
extern void UnityThreadUtilsInternal_Unity_Services_Core_Threading_Internal_IUnityThreadUtils_PostAsync_mB7F687F4632DE34A0AF82D911BD507987CD59356 (void);
extern void UnityThreadUtilsInternal_Unity_Services_Core_Threading_Internal_IUnityThreadUtils_PostAsync_m2A06D795FE85F4D5B5E0492FF45E0BD3379B2F46 (void);
extern void UnityThreadUtilsInternal_Unity_Services_Core_Threading_Internal_IUnityThreadUtils_Send_m6A90E8351E6FD33374C3D7EAF7C7D74872E0A1B8 (void);
extern void UnityThreadUtilsInternal_Unity_Services_Core_Threading_Internal_IUnityThreadUtils_Send_m8918510A7586D876A98DC733B90FB534B228BE3F (void);
extern void UnityThreadUtilsInternal__ctor_m9430BA50989685AA40935124D40A44F29156A3A2 (void);
static Il2CppMethodPointer s_methodPointers[18] = 
{
	UnityThreadUtilsInternal_PostAsync_m324667C9E5B9E25D01ED8F00E68330130F3B435A,
	UnityThreadUtilsInternal_PostAsync_mC858E8A5C829E4053E13566318F03866AA7A171F,
	NULL,
	NULL,
	UnityThreadUtilsInternal_Send_m91B4D5F642779F7886B18FDBB6ACAAB3CAE65DB6,
	UnityThreadUtilsInternal_Send_m701390E8B2BC62F04BFC284B5A6A60C3CA8278E9,
	NULL,
	NULL,
	UnityThreadUtilsInternal_Unity_Services_Core_Threading_Internal_IUnityThreadUtils_get_IsRunningOnUnityThread_m264DB20EE6404E1C396E078FADE78F0C91CC7E1A,
	UnityThreadUtilsInternal_Unity_Services_Core_Threading_Internal_IUnityThreadUtils_PostAsync_mB7F687F4632DE34A0AF82D911BD507987CD59356,
	UnityThreadUtilsInternal_Unity_Services_Core_Threading_Internal_IUnityThreadUtils_PostAsync_m2A06D795FE85F4D5B5E0492FF45E0BD3379B2F46,
	NULL,
	NULL,
	UnityThreadUtilsInternal_Unity_Services_Core_Threading_Internal_IUnityThreadUtils_Send_m6A90E8351E6FD33374C3D7EAF7C7D74872E0A1B8,
	UnityThreadUtilsInternal_Unity_Services_Core_Threading_Internal_IUnityThreadUtils_Send_m8918510A7586D876A98DC733B90FB534B228BE3F,
	NULL,
	NULL,
	UnityThreadUtilsInternal__ctor_m9430BA50989685AA40935124D40A44F29156A3A2,
};
static const int32_t s_InvokerIndices[18] = 
{
	18812,
	16653,
	0,
	0,
	19213,
	17392,
	0,
	0,
	11464,
	8061,
	3925,
	0,
	0,
	9162,
	5064,
	0,
	0,
	11805,
};
static const Il2CppTokenRangePair s_rgctxIndices[8] = 
{
	{ 0x06000003, { 0, 6 } },
	{ 0x06000004, { 6, 6 } },
	{ 0x06000007, { 12, 6 } },
	{ 0x06000008, { 18, 6 } },
	{ 0x0600000C, { 24, 3 } },
	{ 0x0600000D, { 27, 3 } },
	{ 0x06000010, { 30, 3 } },
	{ 0x06000011, { 33, 3 } },
};
extern const uint32_t g_rgctx_Task_1_get_Factory_m71899FE1F646A68F51084DFA99991FD3785F748B;
extern const uint32_t g_rgctx_Task_1_tE27F07AE9055372A0C95248050CC4C63C00E83C6;
extern const uint32_t g_rgctx_TaskFactory_1_t916F4FBD1F73265F682FDA52E2752850889E7932;
extern const uint32_t g_rgctx_Func_1_t0BF50AD245F3793B4D4165B1D33D956E4F1B158C;
extern const uint32_t g_rgctx_TaskFactory_1_StartNew_m45D4EAA610DD96CB4AED643D1E5F3F047492C73D;
extern const uint32_t g_rgctx_Task_1_tE27F07AE9055372A0C95248050CC4C63C00E83C6;
extern const uint32_t g_rgctx_Task_1_get_Factory_mF7B4F4DC0E34F63381321BD7C5BACBC05A75EF0D;
extern const uint32_t g_rgctx_Task_1_tDD89253E78E8ED51801D8FC598FC53A8FD351F16;
extern const uint32_t g_rgctx_TaskFactory_1_t9A7EC835D12C5F13CF794B826E456BB64C708374;
extern const uint32_t g_rgctx_Func_2_t7389122DFE2E01024370336FCB3F449BF6526733;
extern const uint32_t g_rgctx_TaskFactory_1_StartNew_m4E00EB6619933A3D86C82E52987C5984E47B6117;
extern const uint32_t g_rgctx_Task_1_tDD89253E78E8ED51801D8FC598FC53A8FD351F16;
extern const uint32_t g_rgctx_Func_1_tA717EC9E5B90B4255777A93436EAA20022474739;
extern const uint32_t g_rgctx_Func_1_Invoke_m197A76A274A9A1BA1E88E82726A1C86B8FAD3427;
extern const uint32_t g_rgctx_T_t509EE0931E180CF371EC5CA2BE75C55F07040419;
extern const uint32_t g_rgctx_UnityThreadUtilsInternal_PostAsync_TisT_t509EE0931E180CF371EC5CA2BE75C55F07040419_mFD660176B041DADFA06CCFDB0CD5237B2F201C26;
extern const uint32_t g_rgctx_Task_1_t355A79B13770900F781E0ECB3B3605FCD83BDCD5;
extern const uint32_t g_rgctx_Task_1_get_Result_m6F57824DE192C8F1B20C4697F5CBE034636D0056;
extern const uint32_t g_rgctx_Func_2_tE2AB9CE85659FEADFC9F4BCACF9E72FF177D04D5;
extern const uint32_t g_rgctx_Func_2_Invoke_m73BF2F2AF964BEC891C19A0F985205A06D87F345;
extern const uint32_t g_rgctx_T_tF0E30047DE6202147B417D3D2BCB1A577C11A560;
extern const uint32_t g_rgctx_UnityThreadUtilsInternal_PostAsync_TisT_tF0E30047DE6202147B417D3D2BCB1A577C11A560_m46C373D5EA30A95C636E08011B9793750C0F5B53;
extern const uint32_t g_rgctx_Task_1_tBD6F46A308D89E6B682FEE4216EE0BD7333BC21F;
extern const uint32_t g_rgctx_Task_1_get_Result_m34197BD8796A783F7646BA7DCE8ADC518DD5C4BD;
extern const uint32_t g_rgctx_Func_1_t476EA9018F882F1323216B649343E9908D12C1DC;
extern const uint32_t g_rgctx_UnityThreadUtilsInternal_PostAsync_TisT_tA130F458D552431348C70F8C04045D70E4D7D227_m4ED1B0E1F5A862DB9558EA71F568F568A11071E1;
extern const uint32_t g_rgctx_Task_1_t1BCE6D85A93F4D28E2D42C1306A6B9C48246D597;
extern const uint32_t g_rgctx_Func_2_tCFB64F7627AC6697E820C44951BA58F4D0706E7F;
extern const uint32_t g_rgctx_UnityThreadUtilsInternal_PostAsync_TisT_t6E41AF25DE03F6E7B1B0A7DDA61A077394C589C7_m1B756389B6C92D5A337E30F4064F13DE3806EFBC;
extern const uint32_t g_rgctx_Task_1_t9DC44E4CD52B6717C82C938DDE42A2A29C48ACF0;
extern const uint32_t g_rgctx_Func_1_t8688D0584613FB8BD0105DC522C4A09BDAB7B469;
extern const uint32_t g_rgctx_UnityThreadUtilsInternal_Send_TisT_t83373C80546D61CE79D118D1F5D461CEDF68908B_mD40B6C09E3E923BC05ED6F52AADB62C4E3FFE5F8;
extern const uint32_t g_rgctx_T_t83373C80546D61CE79D118D1F5D461CEDF68908B;
extern const uint32_t g_rgctx_Func_2_t5238F4F286B774A031AEF9ED54F38329FC80ECB6;
extern const uint32_t g_rgctx_UnityThreadUtilsInternal_Send_TisT_t225D1751A6B44A7A651D5AEADDE6F91130FB44D6_mC88F84B38AB7FC8DC8E6CD22BC9DA885090BE5EB;
extern const uint32_t g_rgctx_T_t225D1751A6B44A7A651D5AEADDE6F91130FB44D6;
static const Il2CppRGCTXDefinition s_rgctxValues[36] = 
{
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Task_1_get_Factory_m71899FE1F646A68F51084DFA99991FD3785F748B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Task_1_tE27F07AE9055372A0C95248050CC4C63C00E83C6 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TaskFactory_1_t916F4FBD1F73265F682FDA52E2752850889E7932 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Func_1_t0BF50AD245F3793B4D4165B1D33D956E4F1B158C },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_TaskFactory_1_StartNew_m45D4EAA610DD96CB4AED643D1E5F3F047492C73D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Task_1_tE27F07AE9055372A0C95248050CC4C63C00E83C6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Task_1_get_Factory_mF7B4F4DC0E34F63381321BD7C5BACBC05A75EF0D },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Task_1_tDD89253E78E8ED51801D8FC598FC53A8FD351F16 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_TaskFactory_1_t9A7EC835D12C5F13CF794B826E456BB64C708374 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Func_2_t7389122DFE2E01024370336FCB3F449BF6526733 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_TaskFactory_1_StartNew_m4E00EB6619933A3D86C82E52987C5984E47B6117 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Task_1_tDD89253E78E8ED51801D8FC598FC53A8FD351F16 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Func_1_tA717EC9E5B90B4255777A93436EAA20022474739 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Func_1_Invoke_m197A76A274A9A1BA1E88E82726A1C86B8FAD3427 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t509EE0931E180CF371EC5CA2BE75C55F07040419 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnityThreadUtilsInternal_PostAsync_TisT_t509EE0931E180CF371EC5CA2BE75C55F07040419_mFD660176B041DADFA06CCFDB0CD5237B2F201C26 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Task_1_t355A79B13770900F781E0ECB3B3605FCD83BDCD5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Task_1_get_Result_m6F57824DE192C8F1B20C4697F5CBE034636D0056 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Func_2_tE2AB9CE85659FEADFC9F4BCACF9E72FF177D04D5 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Func_2_Invoke_m73BF2F2AF964BEC891C19A0F985205A06D87F345 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_tF0E30047DE6202147B417D3D2BCB1A577C11A560 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnityThreadUtilsInternal_PostAsync_TisT_tF0E30047DE6202147B417D3D2BCB1A577C11A560_m46C373D5EA30A95C636E08011B9793750C0F5B53 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Task_1_tBD6F46A308D89E6B682FEE4216EE0BD7333BC21F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_Task_1_get_Result_m34197BD8796A783F7646BA7DCE8ADC518DD5C4BD },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Func_1_t476EA9018F882F1323216B649343E9908D12C1DC },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnityThreadUtilsInternal_PostAsync_TisT_tA130F458D552431348C70F8C04045D70E4D7D227_m4ED1B0E1F5A862DB9558EA71F568F568A11071E1 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Task_1_t1BCE6D85A93F4D28E2D42C1306A6B9C48246D597 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Func_2_tCFB64F7627AC6697E820C44951BA58F4D0706E7F },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnityThreadUtilsInternal_PostAsync_TisT_t6E41AF25DE03F6E7B1B0A7DDA61A077394C589C7_m1B756389B6C92D5A337E30F4064F13DE3806EFBC },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Task_1_t9DC44E4CD52B6717C82C938DDE42A2A29C48ACF0 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Func_1_t8688D0584613FB8BD0105DC522C4A09BDAB7B469 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnityThreadUtilsInternal_Send_TisT_t83373C80546D61CE79D118D1F5D461CEDF68908B_mD40B6C09E3E923BC05ED6F52AADB62C4E3FFE5F8 },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t83373C80546D61CE79D118D1F5D461CEDF68908B },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_Func_2_t5238F4F286B774A031AEF9ED54F38329FC80ECB6 },
	{ (Il2CppRGCTXDataType)3, (const void *)&g_rgctx_UnityThreadUtilsInternal_Send_TisT_t225D1751A6B44A7A651D5AEADDE6F91130FB44D6_mC88F84B38AB7FC8DC8E6CD22BC9DA885090BE5EB },
	{ (Il2CppRGCTXDataType)2, (const void *)&g_rgctx_T_t225D1751A6B44A7A651D5AEADDE6F91130FB44D6 },
};
IL2CPP_EXTERN_C const Il2CppCodeGenModule g_Unity_Services_Core_Threading_CodeGenModule;
const Il2CppCodeGenModule g_Unity_Services_Core_Threading_CodeGenModule = 
{
	"Unity.Services.Core.Threading.dll",
	18,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	8,
	s_rgctxIndices,
	36,
	s_rgctxValues,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
};
